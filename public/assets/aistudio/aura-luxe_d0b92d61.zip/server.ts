import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '10mb' }));

// -------------------------------------------------------------
// File-backed Persistence Store
// -------------------------------------------------------------
const DATA_FILE = path.resolve(__dirname, 'server-data.json');

interface AuditLog {
  id: string;
  timestamp: string;
  type: 'auth' | 'escrow' | 'security' | 'slot' | 'onboarding';
  severity: 'info' | 'warning' | 'critical';
  titleFa: string;
  titleEn: string;
  details: string;
  ip: string;
}

interface ServerState {
  slots: any[];
  escrowTransactions: any[];
  applications: any[];
  tickets: any[];
  bookingRequests: any[];
  auditLogs: AuditLog[];
}

const defaultInitialState: ServerState = {
  slots: [
    {
      id: 'slot-1',
      venueId: 'v1',
      titleFa: 'یونیت جراحی پوست شماره ۱',
      titleEn: 'Aesthetic Surgical Suite 1',
      roomName: 'Suite 101',
      status: 'available',
      hourlyRateToman: 950000,
      equipment: ['Fotona 4D TimeWalker', 'Cryotherapy', 'HEPA Filtration'],
      lastSanitizedMinutesAgo: 14,
    },
    {
      id: 'slot-2',
      venueId: 'v1',
      titleFa: 'تخت لیزر و اندولیفت شماره ۲',
      titleEn: 'Endolift & Laser Bed 2',
      roomName: 'Suite 102',
      status: 'in_procedure',
      currentDoctorFa: 'دکتر علیرضا رستمی',
      currentDoctorEn: 'Dr. Alireza Rostami',
      hourlyRateToman: 850000,
      equipment: ['Eufoton Aton 1470nm', 'Zimmer Cryo 6'],
      lastSanitizedMinutesAgo: 45,
    },
    {
      id: 'slot-3',
      venueId: 'v1',
      titleFa: 'اتاق هایفوتراپی و تزریقات VIP',
      titleEn: 'VIP HIFU & Injectables Atelier',
      roomName: 'VIP Room A',
      status: 'sanitizing',
      hourlyRateToman: 1100000,
      equipment: ['Ultraformer III', 'UV-C Sterilizer Tower'],
      lastSanitizedMinutesAgo: 2,
    },
    {
      id: 'slot-4',
      venueId: 'v3',
      titleFa: 'یونیت دندانپزشکی لمینت سرامیکی شماره ۱',
      titleEn: 'Porcelain Laminate Operatory 1',
      roomName: 'Smile Lab 1',
      status: 'available',
      hourlyRateToman: 1450000,
      equipment: ['KaVo ESTETICA E80', 'Carl Zeiss Extaro 300 Microscope', 'Medit i700'],
      lastSanitizedMinutesAgo: 8,
    },
    {
      id: 'slot-5',
      venueId: 'v3',
      titleFa: 'یونیت کامپوزیت ونیر و ایزولاسیون شماره ۲',
      titleEn: 'Composite Veneer Suite 2',
      roomName: 'Smile Lab 2',
      status: 'reserved',
      currentDoctorFa: 'دکتر صبا افشار',
      currentDoctorEn: 'Dr. Saba Afshar',
      hourlyRateToman: 1250000,
      equipment: ['Belmont Cleo II', 'Waterlase iPlus Er,Cr:YSGG'],
      lastSanitizedMinutesAgo: 22,
    },
    {
      id: 'slot-6',
      venueId: 'v2',
      titleFa: 'استودیو کالر و اکستنشن VIP شماره ۱',
      titleEn: 'VIP Master Color & Styling Pod 1',
      roomName: 'Studio Suite 1',
      status: 'available',
      hourlyRateToman: 650000,
      equipment: ['Maletti Steam Basin', 'Dyson Supersonic Pro', 'Takara Belmont Chair'],
      lastSanitizedMinutesAgo: 10,
    },
  ],
  escrowTransactions: [
    {
      id: 'esc-901',
      bookingId: 'bk-5541',
      venueId: 'v1',
      venueNameFa: 'کلینیک پوست و لیزر رویال سعادت‌آباد',
      venueNameEn: 'Royal Aesthetic Clinic Saadat Abad',
      doctorNameFa: 'دکتر نیلوفر مهدوی',
      doctorNameEn: 'Dr. Niloofar Mahdavi',
      patientNameFa: 'سحر تهرانی',
      patientNameEn: 'Sahar Tehrani',
      patientNationalId: '0019283741',
      serviceTitleFa: 'پکیج لیزر فوتونا ۴ بعدی جوانسازی',
      serviceTitleEn: 'Fotona 4D Skin Tightening & Resurfacing',
      totalAmountToman: 18500000,
      platformCommissionToman: 1480000, // 8%
      clinicNetToman: 17020000,
      commissionRate: 0.08,
      status: 'held_in_escrow',
      createdAt: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
      heldAt: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
      shaparakTrackingCode: 'SHP-8923419082',
      shaparakRRN: '908213847291',
      shebaNumber: 'IR820120000000001829304192',
      guaranteeWindowMinutes: 120,
      isGuaranteeExpired: false,
    },
    {
      id: 'esc-902',
      bookingId: 'bk-5542',
      venueId: 'v1',
      venueNameFa: 'کلینیک پوست و لیزر رویال سعادت‌آباد',
      venueNameEn: 'Royal Aesthetic Clinic Saadat Abad',
      doctorNameFa: 'دکتر علیرضا رستمی',
      doctorNameEn: 'Dr. Alireza Rostami',
      patientNameFa: 'محمدرضا سلیمانی',
      patientNameEn: 'M. Reza Soleimani',
      patientNationalId: '0074829103',
      serviceTitleFa: 'اندولیفت غبغب و زاویه‌سازی فک',
      serviceTitleEn: 'Endolift Lower Face Contour',
      totalAmountToman: 24000000,
      platformCommissionToman: 1920000,
      clinicNetToman: 22080000,
      commissionRate: 0.08,
      status: 'patient_arrived',
      createdAt: new Date(Date.now() - 80 * 60 * 1000).toISOString(),
      heldAt: new Date(Date.now() - 80 * 60 * 1000).toISOString(),
      patientArrivedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
      patientVerifiedBy: 'مسئول پذیرش: خانم حیدری',
      shaparakTrackingCode: 'SHP-4478129304',
      shaparakRRN: '447812930488',
      shebaNumber: 'IR820120000000001829304192',
      guaranteeWindowMinutes: 120,
      isGuaranteeExpired: false,
    },
    {
      id: 'esc-903',
      bookingId: 'bk-5543',
      venueId: 'v3',
      venueNameFa: 'مرکز طراحی لبخند دکتر کیان الهیه',
      venueNameEn: 'Kian Dental Smile Atelier Elahieh',
      doctorNameFa: 'دکتر صبا افشار',
      doctorNameEn: 'Dr. Saba Afshar',
      patientNameFa: 'فرناز جلالی',
      patientNameEn: 'Farnaz Jalali',
      patientNationalId: '0061928374',
      serviceTitleFa: 'کامپوزیت ونیر لایه‌ای ۱۰ واحد قدامی فک بالا',
      serviceTitleEn: '10-Unit Layered Composite Veneer Maxillary',
      totalAmountToman: 42000000,
      platformCommissionToman: 3360000,
      clinicNetToman: 38640000,
      commissionRate: 0.08,
      status: 'procedure_done',
      createdAt: new Date(Date.now() - 150 * 60 * 1000).toISOString(),
      heldAt: new Date(Date.now() - 150 * 60 * 1000).toISOString(),
      patientArrivedAt: new Date(Date.now() - 110 * 60 * 1000).toISOString(),
      patientVerifiedBy: 'پذیرش: آقای کیانی',
      procedureDoneAt: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
      doctorSignOffNotes: 'کلیه ۱۰ واحد ونیر با بیلدآپ لایه‌ای و پولیش سوپرااسنپ تکمیل شد. عاری از اینترفیرنس اکلوزال.',
      shaparakTrackingCode: 'SHP-9921827364',
      shaparakRRN: '992182736412',
      shebaNumber: 'IR490170000000009928172635',
      guaranteeWindowMinutes: 120,
      isGuaranteeExpired: false,
    },
    {
      id: 'esc-904',
      bookingId: 'bk-5539',
      venueId: 'v2',
      venueNameFa: 'لانژ تخصصی زیبایی و مو زعفرانیه',
      venueNameEn: 'Zafaraniyeh Master Hair Lounge',
      doctorNameFa: 'مهسا نوری',
      doctorNameEn: 'Mahsa Noori',
      patientNameFa: 'بهناز فراهانی',
      patientNameEn: 'Behnaz Farahani',
      patientNationalId: '0451829482',
      serviceTitleFa: 'پروتئین‌تراپی و بالیاژ روسی لوکس',
      serviceTitleEn: 'Russian Balayage & Protein Fusion',
      totalAmountToman: 14000000,
      platformCommissionToman: 1120000,
      clinicNetToman: 12880000,
      commissionRate: 0.08,
      status: 'released',
      createdAt: new Date(Date.now() - 360 * 60 * 1000).toISOString(),
      heldAt: new Date(Date.now() - 360 * 60 * 1000).toISOString(),
      patientArrivedAt: new Date(Date.now() - 310 * 60 * 1000).toISOString(),
      procedureDoneAt: new Date(Date.now() - 210 * 60 * 1000).toISOString(),
      releasedAt: new Date(Date.now() - 80 * 60 * 1000).toISOString(),
      payoutReferenceCode: 'PAY-SATNA-9021884',
      shaparakTrackingCode: 'SHP-1284729102',
      shaparakRRN: '128472910233',
      shebaNumber: 'IR150560000000008827162534',
      guaranteeWindowMinutes: 120,
      isGuaranteeExpired: true,
    },
  ],
  applications: [
    {
      id: 'app-1',
      brandNameFa: 'کلینیک دندانپزشکی دیجیتال مهرشهر',
      brandNameEn: 'Mehrshahr Digital Dentistry',
      type: 'clinic',
      cityId: 'karaj',
      districtNameFa: 'مهرشهر، فاز ۱',
      districtNameEn: 'Mehrshahr Phase 1',
      licenseId: 'MED-KRJ-84920',
      contactPerson: 'دکتر حمید شایسته',
      phone: '09123456789',
      sheba: 'IR490170000000009827162534',
      chairCount: 4,
      primaryEquipment: ['CBCT 3D Sirona', 'Planmeca PlanMill 30 S'],
      submittedAt: new Date(Date.now() - 2 * 86400 * 1000).toISOString(),
      status: 'pending',
    },
    {
      id: 'app-2',
      brandNameFa: 'مرکز تریکولوژی و مراقبت مو نیاوران',
      brandNameEn: 'Niavaran Trichology Center',
      type: 'salon',
      cityId: 'tehran',
      districtNameFa: 'نیاوران',
      districtNameEn: 'Niavaran',
      licenseId: 'GUILD-THR-19284',
      contactPerson: 'پگاه کاظمی',
      phone: '09129876543',
      sheba: 'IR820120000000007728192837',
      chairCount: 6,
      primaryEquipment: ['Dermatoscope Hair Metrix', 'Micro Mist Basin'],
      submittedAt: new Date(Date.now() - 5 * 86400 * 1000).toISOString(),
      status: 'approved',
    },
  ],
  tickets: [
    {
      id: 't-101',
      senderVenueFa: 'کلینیک پوست و لیزر رویال سعادت‌آباد',
      senderVenueEn: 'Royal Aesthetic Clinic Saadat Abad',
      category: 'financial',
      subject: 'استعلام زمان‌بندی تسویه پایا برای تراکنش‌های آخر هفته',
      createdAt: 'امروز، ساعت ۱۰:۳۰',
      status: 'answered',
      priority: 'high',
      messages: [
        {
          id: 'm-1',
          sender: 'venue',
          senderName: 'مدیر کلینیک رویال',
          text: 'با سلام، تراکنش‌های روز جمعه پس از اتمام مهلت تضمین دو ساعته، در چه سیکلی از پایا/ساتنا به شماره شبای ثبت‌شده واریز خواهند شد؟',
          timestamp: '۱۰:۳۰',
        },
        {
          id: 'm-2',
          sender: 'support',
          senderName: 'پشتیبانی مالی اورا لوکس',
          text: 'درود بر شما. به استحضار می‌رساند پس از انقضای مهلت ۲ ساعته تضمین خدمات و تایید پزشک، تسویه‌ها به صورت خودکار در نزدیک‌ترین سیکل تسویه شاپرک (ساعت ۱۳:۴۵ یا ۱۸:۴۵) واریز می‌گردد.',
          timestamp: '۱۰:۴۲',
        },
      ],
    },
    {
      id: 't-102',
      senderVenueFa: 'مرکز طراحی لبخند دکتر کیان الهیه',
      senderVenueEn: 'Kian Dental Smile Atelier Elahieh',
      category: 'equipment',
      subject: 'درخواست کالیبراسیون و افزودن اسکنر داخل‌دهانی تری‌شیپ به لیست یونیت ۲',
      createdAt: 'دیروز، ساعت ۱۶:۱۵',
      status: 'pending',
      priority: 'medium',
      messages: [
        {
          id: 'm-3',
          sender: 'venue',
          senderName: 'سرپرست اتاق عمل دندانپزشکی',
          text: 'یک دستگاه 3Shape TRIOS 5 جدید به تجهیزات یونیت شماره ۲ اضافه شده است. لطفاً نشان کالیبراسیون رسمی را برای این یونیت در کاتالوگ فعال فرمایید.',
          timestamp: '۱۶:۱۵',
        },
      ],
    },
  ],
  auditLogs: [
    {
      id: 'log-1',
      timestamp: new Date(Date.now() - 120 * 60 * 1000).toISOString(),
      type: 'auth',
      severity: 'info',
      titleFa: 'ورود موفق به پنل مدیریت کلینیک',
      titleEn: 'Clinic Manager Authorized Login',
      details: 'Venue: Royal Aesthetic Clinic Saadat Abad (v1). Session issued with TTL 8h.',
      ip: '185.192.112.4',
    },
    {
      id: 'log-2',
      timestamp: new Date(Date.now() - 80 * 60 * 1000).toISOString(),
      type: 'escrow',
      severity: 'info',
      titleFa: 'ثبت حضور و احراز هویت بیمار',
      titleEn: 'Patient Arrival & National ID Verification',
      details: 'Escrow esc-902, National ID 0074829103 verified by Receptionist.',
      ip: '185.192.112.4',
    },
    {
      id: 'log-3',
      timestamp: new Date(Date.now() - 40 * 60 * 1000).toISOString(),
      type: 'security',
      severity: 'info',
      titleFa: 'استعلام حساب امانی و تطبیق شاپرک',
      titleEn: 'Shaparak RRN Reconciliation',
      details: 'All held escrows checked against central settlement gateway.',
      ip: '10.0.0.1',
    },
  ],
  bookingRequests: [
    {
      id: 'req-101',
      trackingCode: 'REQ-2026-8941',
      fullName: 'نیلوفر صادقی',
      phoneNumber: '09123456789',
      desiredService: 'تزریق فیلر لب روسی و مادلینگ فک',
      suggestedDate: '2026-11-05',
      suggestedTime: '۱۶:۰۰ - ۱۸:۰۰ (شیفت عصر)',
      venueId: 'v_saadat_aesthetic',
      venueNameFa: 'کلینیک تخصصی درماتولوژی هورفر (سعادت‌آباد)',
      venueNameEn: 'Hourfar Aesthetic Dermatology Clinic',
      slotId: 'slot-1',
      slotNameFa: 'یونیت جراحی پوست شماره ۱',
      slotNameEn: 'Aesthetic Surgical Suite 1',
      notes: 'مشاوره اولیه انجام شده، تمایل به استفاده از فیلر ژوویدرم با ماندگاری بالا دارم.',
      status: 'pending_confirmation',
      createdAt: 'امروز، ساعت ۱۰:۱۵',
    },
    {
      id: 'req-102',
      trackingCode: 'REQ-2026-7819',
      fullName: 'مهرداد ارجمند',
      phoneNumber: '09121112233',
      desiredService: 'جوانسازی صورت با لیزر اندولیفت و کرایوتراپی',
      suggestedDate: '2026-11-05',
      suggestedTime: '۱۱:۳۰ - ۱۳:۰۰ (شیفت ظهر)',
      venueId: 'v_saadat_aesthetic',
      venueNameFa: 'کلینیک تخصصی درماتولوژی هورفر (سعادت‌آباد)',
      venueNameEn: 'Hourfar Aesthetic Dermatology Clinic',
      slotId: 'slot-2',
      slotNameFa: 'تخت لیزر و اندولیفت شماره ۲',
      slotNameEn: 'Endolift & Laser Bed 2',
      notes: 'جلسه اول درمان لیفت غبغب و خط خنده',
      status: 'pending_confirmation',
      createdAt: 'امروز، ساعت ۱۱:۴۰',
    },
    {
      id: 'req-103',
      trackingCode: 'REQ-2026-6502',
      fullName: 'دکتر صبا افشار',
      phoneNumber: '09358889900',
      desiredService: 'لیفت صورت با نخ کلاژن‌ساز و اولترافورمر ۳',
      suggestedDate: '2026-11-04',
      suggestedTime: '۱۵:۰۰ - ۱۸:۰۰ (شیفت عصر)',
      venueId: 'v_saadat_aesthetic',
      venueNameFa: 'کلینیک تخصصی درماتولوژی هورفر (سعادت‌آباد)',
      venueNameEn: 'Hourfar Aesthetic Dermatology Clinic',
      slotId: 'slot-3',
      slotNameFa: 'اتاق هایفوتراپی و تزریقات VIP',
      slotNameEn: 'VIP Room A',
      notes: 'نوبت توسط منشی کلینیک هماهنگ و تأیید شد.',
      status: 'confirmed',
      createdAt: 'امروز، ساعت ۰۸:۳۰',
    },
  ],
};

function loadState(): ServerState {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const raw = fs.readFileSync(DATA_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (!parsed.bookingRequests) {
        parsed.bookingRequests = defaultInitialState.bookingRequests;
      }
      return parsed;
    }
  } catch (err) {
    console.error('Error loading server data file, using default state:', err);
  }
  return defaultInitialState;
}

let serverState: ServerState = loadState();

function saveState() {
  try {
    fs.writeFileSync(DATA_FILE, JSON.stringify(serverState, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving server data file:', err);
  }
}

// -------------------------------------------------------------
// Security: In-Memory Rate Limiting & Session Tokens
// -------------------------------------------------------------
interface FailedAttemptTracker {
  count: number;
  lockoutUntil: number | null;
}

const loginAttempts = new Map<string, FailedAttemptTracker>();

interface SessionData {
  token: string;
  role: 'clinic_admin' | 'super_admin';
  venueId?: string;
  createdAt: number;
  expiresAt: number;
}

const activeSessions = new Map<string, SessionData>();

function generateToken(): string {
  return 'aura_sec_' + Math.random().toString(36).substring(2) + Date.now().toString(36) + Math.random().toString(36).substring(2);
}

function recordAudit(log: Omit<AuditLog, 'id' | 'timestamp'>) {
  const newLog: AuditLog = {
    id: 'log-' + Date.now() + '-' + Math.floor(Math.random() * 1000),
    timestamp: new Date().toISOString(),
    ...log,
  };
  serverState.auditLogs.unshift(newLog);
  if (serverState.auditLogs.length > 200) {
    serverState.auditLogs.pop();
  }
  saveState();
}

// -------------------------------------------------------------
// Authentication Endpoints
// -------------------------------------------------------------
app.post('/api/auth/login', (req: Request, res: Response) => {
  const { mode, pin, venueId } = req.body;
  const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
  const trackerKey = `${clientIp}_${mode}`;

  // Check rate limiting / lockout
  const tracker = loginAttempts.get(trackerKey) || { count: 0, lockoutUntil: null };
  const now = Date.now();

  if (tracker.lockoutUntil && tracker.lockoutUntil > now) {
    const remainingSec = Math.ceil((tracker.lockoutUntil - now) / 1000);
    recordAudit({
      type: 'security',
      severity: 'warning',
      titleFa: 'تلاش برای ورود در زمان قفل امنیتی',
      titleEn: 'Login Attempt During Security Lockout',
      details: `IP ${clientIp} attempted login while locked out. ${remainingSec}s remaining.`,
      ip: clientIp,
    });
    return res.status(429).json({
      success: false,
      isLockedOut: true,
      remainingSeconds: remainingSec,
      messageFa: `به دلیل ۳ بار تلاش ناموفق، دسترسی شما به مدت ${remainingSec} ثانیه مسدود است.`,
      messageEn: `Too many failed attempts. Security lockout active for ${remainingSec}s.`,
    });
  }

  const cleanPin = String(pin || '').trim();

  // Validate credentials
  let isValid = false;
  let targetRole: 'clinic_admin' | 'super_admin' = 'clinic_admin';

  if (cleanPin === '7890' || (mode === 'super_admin' && cleanPin === '7890')) {
    isValid = true;
    targetRole = 'super_admin';
  } else if (cleanPin === '2026' || (mode === 'clinic_manager' && cleanPin === '2026')) {
    isValid = true;
    targetRole = 'clinic_admin';
  }

  if (!isValid) {
    tracker.count += 1;
    if (tracker.count >= 3) {
      tracker.lockoutUntil = now + 60 * 1000; // 60 seconds lockout
      loginAttempts.set(trackerKey, tracker);
      recordAudit({
        type: 'security',
        severity: 'critical',
        titleFa: 'قفل امنیتی فعال شد (۳ تلاش ناموفق)',
        titleEn: 'Security Lockout Triggered (3 Failed Attempts)',
        details: `Brute force protection triggered for IP ${clientIp} on ${mode}. Locked for 60s.`,
        ip: clientIp,
      });
      return res.status(429).json({
        success: false,
        isLockedOut: true,
        remainingSeconds: 60,
        messageFa: 'رمز عبور اشتباه است. به دلیل ۳ بار تلاش ناموفق، دسترسی به مدت ۶۰ ثانیه مسدود شد.',
        messageEn: 'Invalid credentials. 3 failed attempts: access locked for 60 seconds.',
      });
    }

    loginAttempts.set(trackerKey, tracker);
    recordAudit({
      type: 'auth',
      severity: 'warning',
      titleFa: 'تلاش ناموفق برای ورود به سیستم',
      titleEn: 'Failed Login Attempt',
      details: `Failed credentials attempt on ${mode} from IP ${clientIp}. Attempt ${tracker.count}/3.`,
      ip: clientIp,
    });

    return res.status(401).json({
      success: false,
      isLockedOut: false,
      remainingAttempts: 3 - tracker.count,
      messageFa: `رمز عبور نادرست است. (${3 - tracker.count} تلاش دیگر باقی‌مانده است)`,
      messageEn: `Invalid PIN/password. (${3 - tracker.count} attempts left)`,
    });
  }

  // Reset tracker on success
  loginAttempts.delete(trackerKey);

  // Create active session
  const token = generateToken();
  const session: SessionData = {
    token,
    role: targetRole,
    venueId: targetRole === 'clinic_admin' ? (venueId || 'v1') : undefined,
    createdAt: now,
    expiresAt: now + 8 * 3600 * 1000, // 8 hours
  };
  activeSessions.set(token, session);

  recordAudit({
    type: 'auth',
    severity: 'info',
    titleFa: targetRole === 'super_admin' ? 'ورود موفق سوپرادمین به کنسول کلان' : 'ورود موفق مدیر کلینیک',
    titleEn: targetRole === 'super_admin' ? 'SuperAdmin Authorized Login' : 'Clinic Director Authorized Login',
    details: `Session generated with token prefix ${token.substring(0, 14)}...`,
    ip: clientIp,
  });

  return res.json({
    success: true,
    token,
    role: targetRole,
    venueId: session.venueId,
    expiresAt: session.expiresAt,
  });
});

app.get('/api/auth/session', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ valid: false });
  }
  const token = authHeader.split(' ')[1];
  const session = activeSessions.get(token);
  if (!session || session.expiresAt < Date.now()) {
    if (session) activeSessions.delete(token);
    return res.status(401).json({ valid: false });
  }
  return res.json({
    valid: true,
    role: session.role,
    venueId: session.venueId,
    expiresAt: session.expiresAt,
  });
});

app.post('/api/auth/logout', (req: Request, res: Response) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith('Bearer ')) {
    const token = authHeader.split(' ')[1];
    activeSessions.delete(token);
  }
  return res.json({ success: true });
});

// -------------------------------------------------------------
// Realtime Slots API
// -------------------------------------------------------------
app.get('/api/slots', (_req: Request, res: Response) => {
  res.json({ slots: serverState.slots });
});

app.patch('/api/slots/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, doctorFa, doctorEn } = req.body;
  const clientIp = req.ip || '10.0.0.1';

  const slotIndex = serverState.slots.findIndex((s) => s.id === id);
  if (slotIndex === -1) {
    return res.status(404).json({ error: 'Slot not found' });
  }

  const prevStatus = serverState.slots[slotIndex].status;
  serverState.slots[slotIndex].status = status;
  if (status === 'sanitizing') {
    serverState.slots[slotIndex].lastSanitizedMinutesAgo = 0;
  }
  if (doctorFa) serverState.slots[slotIndex].currentDoctorFa = doctorFa;
  if (doctorEn) serverState.slots[slotIndex].currentDoctorEn = doctorEn;

  saveState();

  recordAudit({
    type: 'slot',
    severity: 'info',
    titleFa: `تغییر وضعیت یونیت/تخت: ${serverState.slots[slotIndex].titleFa}`,
    titleEn: `Slot Status Transition: ${serverState.slots[slotIndex].titleEn}`,
    details: `Status altered from '${prevStatus}' to '${status}'.`,
    ip: clientIp,
  });

  res.json({ success: true, slot: serverState.slots[slotIndex] });
});

// -------------------------------------------------------------
// Booking Requests API (Replaces Payment Gateway with Request Workflow)
// -------------------------------------------------------------
app.get('/api/booking-requests', (req: Request, res: Response) => {
  const { venueId } = req.query;
  let list = serverState.bookingRequests || [];
  if (venueId && typeof venueId === 'string') {
    list = list.filter((r) => r.venueId === venueId);
  }
  res.json({ requests: list });
});

app.post('/api/booking-requests', (req: Request, res: Response) => {
  const data = req.body;
  const clientIp = req.ip || '10.0.0.1';

  const trackingCode = `REQ-2026-${Math.floor(1000 + Math.random() * 9000)}`;
  const newRequest = {
    id: 'req-' + Date.now().toString().slice(-6),
    trackingCode,
    fullName: data.fullName || 'متقاضی محترم',
    phoneNumber: data.phoneNumber || '09120000000',
    desiredService: data.desiredService || 'خدمات تخصصی زیبایی و درمانی',
    suggestedDate: data.suggestedDate || new Date().toISOString().split('T')[0],
    suggestedTime: data.suggestedTime || 'شیفت عصر (۱۶:۰۰ الی ۱۸:۰۰)',
    venueId: data.venueId || 'v_saadat_aesthetic',
    venueNameFa: data.venueNameFa || 'کلینیک همکار اورا لوکس',
    venueNameEn: data.venueNameEn || 'Aura Luxe Partner Clinic',
    slotId: data.slotId,
    slotNameFa: data.slotNameFa || 'یونیت درخواستی',
    slotNameEn: data.slotNameEn || 'Requested Unit',
    notes: data.notes || '',
    status: 'pending_confirmation',
    createdAt: 'امروز ' + new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
  };

  if (!serverState.bookingRequests) {
    serverState.bookingRequests = [];
  }
  serverState.bookingRequests.unshift(newRequest);
  saveState();

  recordAudit({
    type: 'slot',
    severity: 'info',
    titleFa: `درخواست نوبت جدید: ${newRequest.fullName} (${newRequest.trackingCode})`,
    titleEn: `New Booking Request: ${newRequest.fullName} (${newRequest.trackingCode})`,
    details: `Venue: ${newRequest.venueNameFa}, Service: ${newRequest.desiredService}, Status: pending_confirmation`,
    ip: clientIp,
  });

  res.json({ success: true, request: newRequest });
});

app.patch('/api/booking-requests/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, reviewedBy } = req.body;
  const clientIp = req.ip || '10.0.0.1';

  if (!serverState.bookingRequests) {
    return res.status(404).json({ error: 'Request not found' });
  }

  const reqIndex = serverState.bookingRequests.findIndex((r) => r.id === id || r.trackingCode === id);
  if (reqIndex === -1) {
    return res.status(404).json({ error: 'Request not found' });
  }

  const targetReq = serverState.bookingRequests[reqIndex];
  targetReq.status = status;
  targetReq.updatedAt = new Date().toISOString();
  if (reviewedBy) targetReq.reviewedBy = reviewedBy;

  // If approved and has slotId, lock slot as reserved
  if (status === 'confirmed' && targetReq.slotId) {
    const slotIdx = serverState.slots.findIndex((s) => s.id === targetReq.slotId);
    if (slotIdx !== -1) {
      serverState.slots[slotIdx].status = 'reserved';
    }
  }

  saveState();

  recordAudit({
    type: 'slot',
    severity: 'info',
    titleFa: `بروزرسانی وضعیت نوبت ${targetReq.trackingCode} به «${status === 'confirmed' ? 'تأیید شده' : 'رد شده'}»`,
    titleEn: `Booking Request ${targetReq.trackingCode} updated to ${status}`,
    details: `Patient: ${targetReq.fullName}, Venue: ${targetReq.venueNameFa}`,
    ip: clientIp,
  });

  res.json({ success: true, request: targetReq });
});

// -------------------------------------------------------------
// Escrow State Machine API
// -------------------------------------------------------------
app.get('/api/escrow', (_req: Request, res: Response) => {
  // Update guarantee status based on current server clock
  const now = Date.now();
  const updated = serverState.escrowTransactions.map((tx) => {
    if (tx.status === 'procedure_done' && tx.procedureDoneAt) {
      const elapsedMinutes = (now - new Date(tx.procedureDoneAt).getTime()) / (60 * 1000);
      const isExpired = elapsedMinutes >= (tx.guaranteeWindowMinutes || 120);
      return { ...tx, isGuaranteeExpired: isExpired, elapsedMinutes: Math.floor(elapsedMinutes) };
    }
    return tx;
  });
  res.json({ transactions: updated });
});

app.post('/api/escrow/create', (req: Request, res: Response) => {
  const data = req.body;
  const clientIp = req.ip || '10.0.0.1';

  const totalAmount = Number(data.totalAmountToman) || 10000000;
  const commissionRate = 0.08;
  const platformCommission = Math.round(totalAmount * commissionRate);
  const clinicNet = totalAmount - platformCommission;

  const newTx = {
    id: 'esc-' + Date.now().toString().slice(-6),
    bookingId: data.bookingId || 'bk-' + Math.floor(1000 + Math.random() * 9000),
    venueId: data.venueId || 'v1',
    venueNameFa: data.venueNameFa || 'کلینیک همکار اورا لوکس',
    venueNameEn: data.venueNameEn || 'Aura Luxe Partner Venue',
    doctorNameFa: data.doctorNameFa || 'پزشک متقاضی',
    doctorNameEn: data.doctorNameEn || 'Specialist Practitioner',
    patientNameFa: data.patientNameFa || 'بیمار محترم',
    patientNameEn: data.patientNameEn || 'Patient Client',
    patientNationalId: data.patientNationalId || '0019283741',
    serviceTitleFa: data.serviceTitleFa || 'رزرو یونیت و خدمات تخصصی',
    serviceTitleEn: data.serviceTitleEn || 'Specialized Operatory Booking',
    totalAmountToman: totalAmount,
    platformCommissionToman: platformCommission,
    clinicNetToman: clinicNet,
    commissionRate: commissionRate,
    status: 'held_in_escrow',
    createdAt: new Date().toISOString(),
    heldAt: new Date().toISOString(),
    shaparakTrackingCode: data.shaparakTrackingCode || 'SHP-' + Math.floor(1000000000 + Math.random() * 9000000000),
    shaparakRRN: data.shaparakRRN || Math.floor(100000000000 + Math.random() * 900000000000).toString(),
    shebaNumber: data.shebaNumber || 'IR820120000000001829304192',
    guaranteeWindowMinutes: 120,
    isGuaranteeExpired: false,
  };

  serverState.escrowTransactions.unshift(newTx);
  saveState();

  recordAudit({
    type: 'escrow',
    severity: 'info',
    titleFa: 'ایجاد حساب امانی و واریز امن وجه (مرحله ۱)',
    titleEn: 'Escrow Initiated & Funds Blocked (Step 1)',
    details: `Tracking: ${newTx.shaparakTrackingCode}, Amount: ${totalAmount.toLocaleString()} Toman. Commission: ${platformCommission.toLocaleString()} Toman.`,
    ip: clientIp,
  });

  res.json({ success: true, transaction: newTx });
});

// Step 2: Patient Check-In Verification
app.post('/api/escrow/:id/arrive', (req: Request, res: Response) => {
  const { id } = req.params;
  const { verifiedBy, nationalIdCheck } = req.body;
  const clientIp = req.ip || '10.0.0.1';

  const tx = serverState.escrowTransactions.find((t) => t.id === id);
  if (!tx) return res.status(404).json({ error: 'Transaction not found' });
  if (tx.status !== 'held_in_escrow') {
    return res.status(400).json({ error: 'Transaction is not in held_in_escrow state' });
  }

  tx.status = 'patient_arrived';
  tx.patientArrivedAt = new Date().toISOString();
  tx.patientVerifiedBy = verifiedBy || 'مسئول پذیرش و تریاژ';
  tx.nationalIdConfirmed = !!nationalIdCheck;

  saveState();

  recordAudit({
    type: 'escrow',
    severity: 'info',
    titleFa: `تایید ورود و احراز هویت بیمار: ${tx.patientNameFa}`,
    titleEn: `Patient Check-in Verified: ${tx.patientNameEn}`,
    details: `Escrow ${tx.id}. Verified by ${tx.patientVerifiedBy}. National ID check passed.`,
    ip: clientIp,
  });

  res.json({ success: true, transaction: tx });
});

// Step 3: Procedure Completion & Electronic Signature
app.post('/api/escrow/:id/procedure-done', (req: Request, res: Response) => {
  const { id } = req.params;
  const { signOffNotes, doctorSignatureSvg, patientSignatureSvg, disposalConfirmed } = req.body;
  const clientIp = req.ip || '10.0.0.1';

  const tx = serverState.escrowTransactions.find((t) => t.id === id);
  if (!tx) return res.status(404).json({ error: 'Transaction not found' });
  if (tx.status !== 'patient_arrived') {
    return res.status(400).json({ error: 'Patient must have arrived before marking procedure done' });
  }

  tx.status = 'procedure_done';
  tx.procedureDoneAt = new Date().toISOString();
  tx.doctorSignOffNotes = signOffNotes || 'پایان موفقیت‌آمیز پروسیجر طبق پروتکل‌های بهداشتی و بالینی';
  tx.doctorSignatureSvg = doctorSignatureSvg;
  tx.patientSignatureSvg = patientSignatureSvg;
  tx.disposalConfirmed = !!disposalConfirmed;
  tx.guaranteeWindowMinutes = 120;
  tx.isGuaranteeExpired = false;

  saveState();

  recordAudit({
    type: 'escrow',
    severity: 'info',
    titleFa: `امضای دیجیتال و ثبت پایان پروسیجر: ${tx.serviceTitleFa}`,
    titleEn: `Clinical Sign-Off & Electronic Signature: ${tx.serviceTitleEn}`,
    details: `Doctor signed off with digital pad. 120-minute guarantee window started for Escrow ${tx.id}.`,
    ip: clientIp,
  });

  res.json({ success: true, transaction: tx });
});

// Step 4: Disburse Funds to Sheba
app.post('/api/escrow/:id/release', (req: Request, res: Response) => {
  const { id } = req.params;
  const { bypassTimerForDemo } = req.body;
  const clientIp = req.ip || '10.0.0.1';

  const tx = serverState.escrowTransactions.find((t) => t.id === id);
  if (!tx) return res.status(404).json({ error: 'Transaction not found' });
  if (tx.status !== 'procedure_done') {
    return res.status(400).json({ error: 'Procedure must be completed before releasing funds' });
  }

  const elapsedMinutes = (Date.now() - new Date(tx.procedureDoneAt!).getTime()) / (60 * 1000);
  const isExpired = elapsedMinutes >= (tx.guaranteeWindowMinutes || 120);

  if (!isExpired && !bypassTimerForDemo) {
    return res.status(403).json({
      error: 'Guarantee window has not expired yet. 120 minutes required.',
      remainingMinutes: Math.ceil(120 - elapsedMinutes),
    });
  }

  tx.status = 'released';
  tx.releasedAt = new Date().toISOString();
  tx.payoutReferenceCode = 'SATNA-' + Math.floor(1000000 + Math.random() * 9000000);
  tx.isGuaranteeExpired = true;

  saveState();

  recordAudit({
    type: 'escrow',
    severity: 'info',
    titleFa: `آزادسازی خودکار وجه اسکرو و واریز به شبای پزشک: ${tx.payoutReferenceCode}`,
    titleEn: `Escrow Released & Disbursed to Sheba IBAN: ${tx.payoutReferenceCode}`,
    details: `Net amount ${tx.clinicNetToman.toLocaleString()} Toman transferred to ${tx.shebaNumber}.`,
    ip: clientIp,
  });

  res.json({ success: true, transaction: tx });
});

// -------------------------------------------------------------
// Onboarding & Support APIs
// -------------------------------------------------------------
app.get('/api/onboarding', (_req: Request, res: Response) => {
  res.json({ applications: serverState.applications });
});

app.post('/api/onboarding', (req: Request, res: Response) => {
  const data = req.body;
  const newApp = {
    id: 'app-' + Date.now().toString().slice(-5),
    brandNameFa: data.brandNameFa || data.businessName || 'مرکز همکار اورا لوکس',
    brandNameEn: data.brandNameEn || data.businessName || 'Aura Luxe Partner',
    businessName: data.brandNameFa || data.businessName || 'مرکز همکار اورا لوکس',
    applicantName: data.contactPerson || data.applicantName || 'متقاضی محترم',
    type: data.type || 'clinic',
    applicantType: data.type === 'doctor' ? 'doctor' : data.type === 'salon' ? 'salon' : 'clinic',
    cityId: data.cityId || 'tehran',
    districtNameFa: data.districtNameFa || 'سعادت‌آباد',
    district: data.districtNameFa || 'سعادت‌آباد',
    cityAndDistrict: data.districtNameFa || 'تهران - سعادت‌آباد',
    districtNameEn: data.districtNameEn || 'Saadat Abad',
    licenseId: data.licenseId || 'REG-PENDING',
    contactPerson: data.contactPerson || data.applicantName || 'متقاضی محترم',
    phone: data.phone || data.phoneNumber,
    phoneNumber: data.phone || data.phoneNumber,
    sheba: data.sheba || 'IR000000000000000000000000',
    chairCount: Number(data.chairCount) || 2,
    chairsOrBedsCount: Number(data.chairCount) || 2,
    primaryEquipment: Array.isArray(data.primaryEquipment) ? data.primaryEquipment.join(', ') : (data.primaryEquipment || ''),
    shortDescription: Array.isArray(data.primaryEquipment) ? data.primaryEquipment.join(', ') : (data.primaryEquipment || ''),
    submittedAt: new Date().toISOString(),
    status: 'pending',
  };

  serverState.applications.unshift(newApp);
  saveState();

  recordAudit({
    type: 'onboarding',
    severity: 'info',
    titleFa: `درخواست ثبت‌نام جدید: ${newApp.brandNameFa}`,
    titleEn: `New Partner Application: ${newApp.brandNameEn}`,
    details: `License ID: ${newApp.licenseId}, Chairs: ${newApp.chairCount}. Status: Pending SuperAdmin verification.`,
    ip: req.ip || '10.0.0.1',
  });

  res.json({ success: true, application: newApp });
});

app.patch('/api/onboarding/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const { status } = req.body;
  const appItem = serverState.applications.find((a) => a.id === id);
  if (!appItem) return res.status(404).json({ error: 'Application not found' });
  appItem.status = status;
  saveState();

  recordAudit({
    type: 'onboarding',
    severity: 'info',
    titleFa: `تغییر وضعیت درخواست همکار: ${appItem.brandNameFa} (${status === 'approved' ? 'تایید' : 'رد'})`,
    titleEn: `Partner Application Status Updated: ${appItem.brandNameEn} (${status})`,
    details: `Status set to ${status} by SuperAdmin.`,
    ip: req.ip || '10.0.0.1',
  });

  res.json({ success: true, application: appItem });
});

app.get('/api/tickets', (_req: Request, res: Response) => {
  res.json({ tickets: serverState.tickets });
});

app.post('/api/tickets', (req: Request, res: Response) => {
  const { senderVenueFa, senderVenueEn, category, subject, message } = req.body;
  const newTicket = {
    id: 't-' + Math.floor(100 + Math.random() * 900),
    senderVenueFa: senderVenueFa || 'کلینیک عضو اورا لوکس',
    senderVenueEn: senderVenueEn || 'Aura Luxe Member Clinic',
    category: category || 'general',
    subject,
    createdAt: 'هم‌اکنون',
    status: 'pending',
    priority: 'high',
    messages: [
      {
        id: 'm-' + Date.now(),
        sender: 'venue',
        senderName: 'مدیریت کلینیک',
        text: message,
        timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
      },
    ],
  };
  serverState.tickets.unshift(newTicket);
  saveState();
  res.json({ success: true, ticket: newTicket });
});

app.post('/api/tickets/:id/reply', (req: Request, res: Response) => {
  const { id } = req.params;
  const { text, sender } = req.body;
  const ticket = serverState.tickets.find((t) => t.id === id);
  if (!ticket) return res.status(404).json({ error: 'Ticket not found' });

  ticket.messages.push({
    id: 'm-' + Date.now(),
    sender: sender || 'support',
    senderName: sender === 'venue' ? 'مدیریت کلینیک' : 'پشتیبانی ارشد اورا لوکس',
    text,
    timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
  });
  ticket.status = sender === 'venue' ? 'pending' : 'answered';
  saveState();
  res.json({ success: true, ticket });
});

app.get('/api/audit-logs', (_req: Request, res: Response) => {
  res.json({ logs: serverState.auditLogs });
});

// -------------------------------------------------------------
// Vite Middleware / Static Serving Setup
// -------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`AURA LUXE Full-Stack Engine running on port ${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup failure:', err);
  process.exit(1);
});
