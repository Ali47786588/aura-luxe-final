import { Language } from '../types';

export const t = (lang: Language) => {
  const isFa = lang === 'fa';

  return {
    isFa,
    // Brand
    brandName: isFa ? 'آورا لوکس' : 'AURA LUXE',
    brandBadge: isFa ? 'مارکت‌پلیس B2B سلامت و زیبایی' : 'B2B Aesthetic & Dental Marketplace',
    tagline: isFa
      ? 'پلتفرم اشتراک هوشمند و اجاره ساعتی یونیت‌های دندانپزشکی، تخت‌های پوست و استیشن‌های زیبایی در تهران و کرج'
      : 'The ultra-minimalist B2B marketplace for luxury clinic operatories, aesthetic beds & master salon suites in Tehran and Karaj',

    // Nav
    navAll: isFa ? 'همه بخش‌ها' : 'All Verticals',
    navAesthetics: isFa ? 'پوست و لیزر' : 'Skin & Aesthetics',
    navSalons: isFa ? 'سالن‌های زیبایی' : 'Luxury Salons',
    navDental: isFa ? 'دندانپزشکی و لبخند' : 'Dental & Smile Design',
    navSlots: isFa ? 'مدیریت آنی یونیت‌ها' : 'Live Slot Matrix',
    navBeforeAfter: isFa ? 'نتایج قبل و بعد' : 'Cinematic Results',
    navEscrow: isFa ? 'داشبورد مالی و امانی' : 'Escrow & Commission',

    // Header actions
    locationSelector: isFa ? 'انتخاب موقعیت مکانی' : 'Select Location',
    bookSlotBtn: isFa ? 'رزرو سریع برای پزشک' : 'Book a Clinical Suite',
    ownerConsoleBtn: isFa ? 'پنل مدیران کلینیک' : 'Clinic Owner Panel',
    registerPartnerBtn: isFa ? 'ثبت‌نام مرکز یا پزشک' : 'Register Center or Doctor',
    registerPartnerSuccessMsg: isFa ? 'درخواست شما ثبت شد و در حال بررسی است' : 'Your application has been received and is under review.',
    switchLang: isFa ? 'English' : 'فارسی',

    // Location Switcher
    locationModalTitle: isFa ? 'محدوده‌های لوکس تهران و کرج' : 'Premier Districts (Tehran & Karaj)',
    locationModalSubtitle: isFa
      ? 'کلینیک‌های مجاز و معتبر دارای تاییدیه بهداشت با امکان رزرو ساعتی و شیفت'
      : 'Verified Grade-A facilities with instant hourly chair and bed reservation',
    tehranTab: isFa ? 'تهران (مناطق ۱ و ۲)' : 'Tehran (Districts 1 & 2)',
    karajTab: isFa ? 'کرج و البرز' : 'Karaj & Alborz',
    activeClinics: isFa ? 'کلینیک فعال' : 'Active Clinics',
    availableNow: isFa ? 'یونیت خالی هم‌اکنون' : 'Available Slots Now',
    avgRate: isFa ? 'میانگین هر ساعت:' : 'Avg. Hourly Rate:',
    allDistricts: isFa ? 'تمامی محدوده‌ها' : 'All Districts',
    selected: isFa ? 'انتخاب شده' : 'Active',

    // Hero Section
    heroPill: isFa ? 'رزرو آنلاین مراکز مجاز و معتبر زیبایی و دندانپزشکی' : 'Verified Luxury Aesthetic & Dental Centers',
    heroTitlePart1: isFa ? 'برترین کلینیک‌ها و استودیوهای' : 'Curated Luxury Sanctuaries for',
    heroTitlePart2: isFa ? 'زیبایی، پوست و اصلاح لبخند' : 'Aesthetics, Skin & Smile Design',
    heroDescription: isFa
      ? 'دسترسی سریع، بررسی تخصصی و رزرو آنلاین برترین کلینیک‌های پوست و لیزر، سالن‌های زیبایی و مراکز طراحی لبخند در سعادت‌آباد، الهیه، گوهردشت و فردیس با بالاترین استاندارد بهداشتی و رضایت مراجعین.'
      : 'Explore and instantly reserve premier skin and aesthetic clinics, luxury salons, and smile design ateliers across Tehran and Karaj with verified medical accreditations.',
    exploreClinics: isFa ? 'مشاهده مراکز و رزرو' : 'Explore Facilities',
    openSlotPanel: isFa ? 'مشاهده یونیت‌های خالی هم‌اکنون' : 'Available Operatories Now',

    // Stats Bar (Public doctor & client facing)
    stat1Label: isFa ? 'مراکز لوکس تایید شده' : 'Verified Luxury Centers',
    stat1Value: isFa ? '۷۴+' : '74+',
    stat2Label: isFa ? 'یونیت و تخت فعال' : 'Clinical Operatories & Beds',
    stat2Value: isFa ? '۳۲۰+' : '320+',
    stat3Label: isFa ? 'نوبت‌های موفق ثبت شده' : 'Successful Appointments Booked',
    stat3Value: isFa ? '۴٬۸۵۰+' : '4,850+',
    stat4Label: isFa ? 'میانگین رضایت مراجعین' : 'Patient Satisfaction',
    stat4Value: isFa ? '۴٫۹۶ / ۵' : '4.96 / 5.0',

    // Role-Based Navigation & Access
    rolePublicBadge: isFa ? 'سامانه رزرو مشتریان' : 'Client Reservation Portal',
    roleAdminBadge: isFa ? 'پنل اختصاصی مدیریت' : 'Clinic Manager Portal',
    loginAsManagerBtn: isFa ? 'ورود مدیران' : 'Manager Sign-In',
    switchToManagerView: isFa ? 'ورود به پنل مدیریت کلینیک' : 'Switch to Clinic Management',
    switchToPublicView: isFa ? 'بازگشت به سایت اصلی' : 'Return to Home',
    securityNotice: isFa
      ? 'اطلاعات مالی، موجودی حساب امانی و کارمزدها منحصراً با ورود رمز عبور معتبر مدیریت قابل رویت است.'
      : 'Financial balances and management tools are restricted to authorized directors.',

    // Admin Auth Modal
    loginModalTitle: isFa ? 'ورود اختصاصی مدیریت' : 'Executive Management Access',
    loginModalSubtitle: isFa
      ? 'لطفاً رمز عبور اختصاصی خود را وارد نمایید.'
      : 'Please enter your security password to proceed.',
    selectVenueToManage: isFa ? 'انتخاب کلینیک تحت مدیریت:' : 'Select Facility:',
    pinCodeLabel: isFa ? 'رمز عبور مدیریت:' : 'Security Password:',
    enterPortalBtn: isFa ? 'ورود به پنل' : 'Sign In',
    oneClickDemoBtn: isFa ? 'ورود مستقیم' : 'Sign In',

    // Categories
    catAll: isFa ? 'همه دسته‌بندی‌ها' : 'All Categories',
    catAestheticsTitle: isFa ? 'کلینیک‌های تخصصی پوست، لیزر و زیبایی' : 'Advanced Aesthetics & Skin Clinics',
    catAestheticsSub: isFa ? 'سوئیت‌های جراحی سرپایی، کندلا ۲۰۲۵، مورفئوس۸ و اتاق تزریقات VIP' : 'Outpatient suites, Candela 2025, Morpheus8 & VIP injectables',
    catSalonsTitle: isFa ? 'سالن‌های مجلل و مستر استایلینگ' : 'Luxury Hair & Beauty Salons',
    catSalonsSub: isFa ? 'یونیت‌های VIP رنگ و لایت، صندلی‌های تاکارا بلمونت و هد اسپا ژاپنی' : 'Master colorist chairs, Takara Belmont & Japanese head spas',
    catDentalTitle: isFa ? 'کلینیک‌های دندانپزشکی و اصلاح طرح لبخند' : 'Premium Dental & Smile Design',
    catDentalSub: isFa ? 'یونیت‌های کاستلینی و زیرونا، اسکنرهای ۳Shape تریوس ۵ و میکروسکوپ زایس' : 'Castellini & Sirona units, 3Shape Trios 5 intraoral scanners & Zeiss optics',

    // Real-Time Slot Panel
    slotPanelTitle: isFa ? 'مانیتورینگ و مدیریت آنی تخت‌ها و یونیت‌ها' : 'Real-Time Clinical Slot Management',
    slotPanelSubtitle: isFa
      ? 'مدیران کلینیک می‌توانند ظرفیت‌های خالی را در لحظه برای رزرو پزشکان مهمان فعال یا غیرفعال کنند'
      : 'Clinic directors can toggle vacant operatory chairs and beds instantly for guest practitioners',
    filterAllSlots: isFa ? 'همه تخت‌ها' : 'All Slots',
    filterAvailableOnly: isFa ? 'فقط آماده پذیرش (خالی)' : 'Available Now Only',
    filterByVenue: isFa ? 'فیلتر بر اساس مرکز' : 'Filter by Venue',
    statusAvailable: isFa ? 'خالی و آماده پذیرش' : 'Available',
    statusReserved: isFa ? 'رزرو شده' : 'Reserved',
    statusInProcedure: isFa ? 'در حال انجام پروسیجر' : 'In Procedure',
    statusSanitizing: isFa ? 'در حال ضدعفونی' : 'Sanitizing',
    toggleStatus: isFa ? 'تغییر وضعیت آنی' : 'Toggle Status',
    hourlyRate: isFa ? 'نرخ هر ساعت:' : 'Hourly Rate:',
    morningShift: isFa ? 'شیفت صبح (۴ ساعته):' : 'Morning Shift (4h):',
    eveningShift: isFa ? 'شیفت عصر (۴ ساعته):' : 'Evening Shift (4h):',
    assistantBadge: isFa ? 'همراه با دستیار بالینی' : 'Assistant Included',
    autoclaveBadge: isFa ? 'پک استریل کلاس B آماده' : 'Class-B Autoclave Ready',
    bookThisSlot: isFa ? 'رزرو این یونیت' : 'Book This Unit',
    lastSanitized: isFa ? 'آخرین استریلیزاسیون:' : 'Last Sanitized:',
    minutesAgo: isFa ? 'دقیقه قبل' : 'mins ago',

    // Before/After Cinematic Showcase
    beforeAfterTitle: isFa ? 'نتایج بالینی و نمایشگر سینمایی قبل و بعد' : 'Cinematic Clinical Transformations',
    beforeAfterSubtitle: isFa
      ? 'اسلایدر تعاملی تفکیک نتایج انجام شده توسط پزشکان همکار در یونیت‌های اورا لوکس'
      : 'Interactive split-view comparison of clinical outcomes performed in AURA LUXE operatories',
    beforeLabel: isFa ? 'قبل از درمان' : 'BEFORE',
    afterLabel: isFa ? 'نتیجه نهایی' : 'AFTER',
    dragHint: isFa ? 'اسلایدر را به چپ و راست بکشید' : 'Drag slider left/right to compare',
    clinicalMetrics: isFa ? 'شاخص‌های تخصصی کیس' : 'Clinical Case Metrics',
    performedAt: isFa ? 'انجام شده در:' : 'Performed At:',
    doctorInCharge: isFa ? 'پزشک معالج:' : 'Doctor / Specialist:',
    bookSimilarSuite: isFa ? 'رزرو یونیت مشابه این کیس' : 'Book Similar Operatory',

    // Financial Escrow & Commission Calculator
    escrowTitle: isFa ? 'سیستم امانی تضمین پرداخت و ماشین‌حساب کارمزد' : 'Secure Financial Escrow & Commission Hub',
    escrowSubtitle: isFa
      ? 'وجه رزرو پزشک تا زمان تایید اتمام کار بیمار در حساب امانی امن بلوکه شده و سپس به کلینیک پرداخت می‌شود'
      : 'Practitioner booking funds are held safely in escrow until patient procedure sign-off, then disbursed directly',
    totalEscrowBalance: isFa ? 'موجودی کل در حساب امانی' : 'Total Held in Escrow',
    releasedThisMonth: isFa ? 'تسویه شده به کلینیک‌ها این ماه' : 'Disbursed to Venues (MTD)',
    avgPlatformFee: isFa ? 'میانگین کارمزد پلتفرم' : 'Average Platform Fee',
    automatedPayoutSpeed: isFa ? 'سرعت انتقال پایا / ساتنا' : 'Payout Settlement Speed',
    instantReleaseDesc: isFa ? 'حداکثر ۲ ساعت پس از ثبت خروج بیمار' : 'Under 2 hours post procedure sign-off',
    
    // Calculator
    calcHeader: isFa ? 'ماشین‌حساب هوشمند درآمد و کارمزد کلینیک' : 'Automated Commission & Revenue Simulator',
    calcSub: isFa ? 'محاسبه شفاف سهم کلینیک، کارمزد پلتفرم و سپرده امانی' : 'Calculate gross booking, platform commission and net venue revenue',
    grossRentInput: isFa ? 'مبلغ ناخالص رزروهای ماهانه (تومان)' : 'Estimated Monthly Gross Bookings (Toman)',
    tierStandard: isFa ? 'پلن استاندارد (۱۲٪)' : 'Standard (12%)',
    tierPremium: isFa ? 'پلن پرمیوم (۱۰٪)' : 'Premium (10%)',
    tierHighVolume: isFa ? 'پلن حجم بالا VIP (۸٪)' : 'VIP High-Volume (8%)',
    netClinicRevenue: isFa ? 'درآمد خالص واریزی به کلینیک:' : 'Net Clinic Revenue (Disbursed):',
    platformCommissionFee: isFa ? 'کارمزد خدمات و پشتیبانی پلتفرم:' : 'Platform Fee & Technology:',
    escrowReserveHold: isFa ? 'ذخیره امانی تضمین کیفیت (آزادشونده):' : 'Quality Escrow Reserve (Released upon sign-off):',

    // Escrow Transactions
    txLedgerTitle: isFa ? 'دفتر کل تراکنش‌های حساب امانی (زنده)' : 'Live Escrow Ledger & Milestones',
    colContract: isFa ? 'کد قرارداد امانی' : 'Contract ID',
    colPractitioner: isFa ? 'پزشک / مستر' : 'Practitioner',
    colVenue: isFa ? 'کلینیک و یونیت' : 'Clinic & Slot',
    colGross: isFa ? 'مبلغ کل' : 'Gross Amount',
    colFee: isFa ? 'کارمزد' : 'Platform Fee',
    colNet: isFa ? 'سهم کلینیک' : 'Clinic Payout',
    colMilestone: isFa ? 'مرحله امانی' : 'Escrow Milestone',
    colAction: isFa ? 'عملیات' : 'Action',
    step1: isFa ? '۱. رزرو و بلوکه وجه' : '1. Escrow Held',
    step2: isFa ? '۲. ورود و پذیرش بیمار' : '2. Patient Arrived',
    step3: isFa ? '۳. اتمام پروسیجر' : '3. Procedure Done',
    step4: isFa ? '۴. تسویه به شبا' : '4. Released to Sheba',
    releaseEarlyBtn: isFa ? 'آزادسازی آنی' : 'Release Funds',
    viewInvoice: isFa ? 'فاکتور رسمی' : 'Tax Invoice',

    // Booking Modal
    bookingModalTitle: isFa ? 'رزرو قطعی یونیت با تضمین امانی' : 'Instant Clinical Suite Reservation',
    bookingModalSubtitle: isFa ? 'تایید آنی با استعلام کد نظام پزشکی و صدور قرارداد B2B' : 'Instant booking with Medical Council ID verification and B2B contract',
    selectDate: isFa ? 'تاریخ رزرو:' : 'Reservation Date:',
    selectDuration: isFa ? 'نوع رزرو:' : 'Duration Type:',
    duration2h: isFa ? '۲ ساعت (کیس سرپایی)' : '2 Hours (Outpatient)',
    duration4h: isFa ? 'شیفت نیمه‌روزه (۴ ساعت)' : 'Half-Day Shift (4h)',
    duration8h: isFa ? 'شیفت کامل روزانه (۸ ساعت)' : 'Full-Day Shift (8h)',
    practitionerNameInput: isFa ? 'نام و نام خانوادگی پزشک / مستر:' : 'Practitioner Full Name:',
    medicalIdInput: isFa ? 'شماره نظام پزشکی / شناسه صنفی:' : 'Medical Council ID / Guild License:',
    patientProcedureInput: isFa ? 'عنوان پروسیجر یا درمان:' : 'Procedure Description:',
    depositInEscrow: isFa ? 'مبلغ قابل واریز به حساب امانی:' : 'Amount to Hold in Escrow:',
    confirmAndHoldBtn: isFa ? 'پرداخت و انتقال امن به حساب امانی' : 'Confirm & Hold in Escrow',
    cancel: isFa ? 'انصراف' : 'Cancel',
    successBooking: isFa ? 'رزرو با موفقیت انجام شد و وجه در حساب امانی ثبت گردید.' : 'Booking confirmed and escrow safely locked.',

    // Venue details modal
    venueDetailsTitle: isFa ? 'مشخصات کامل مرکز و تجهیزات' : 'Facility & Equipment Dossier',
    amenitiesTitle: isFa ? 'امکانات رفاهی و خدمات پشتیبانی' : 'Amenities & Patient Hospitality',
    equipmentTitle: isFa ? 'تجهیزات و برندهای بالینی موجود' : 'Medical Equipment On-Site',
    certificationsTitle: isFa ? 'گواهینامه‌ها و استانداردهای بهداشتی' : 'Accreditations & Hygiene Certs',
    directorTitle: isFa ? 'مسئول فنی و مدیر بالینی مرکز:' : 'Clinical Director:',
    closeModal: isFa ? 'بستن' : 'Close',

    // Currencies & Numbers
    currency: isFa ? 'تومان' : 'Toman',
    perHour: isFa ? '/ ساعت' : '/ hour',
    chairsWord: isFa ? 'یونیت / تخت' : 'chairs/beds',
    emptyNotice: isFa ? 'موردی یافت نشد.' : 'No facilities match the selected criteria.',
  };
};

export const formatPrice = (val: number, lang: Language): string => {
  const isFa = lang === 'fa';
  const formatted = val.toLocaleString('en-US');
  if (!isFa) return `${formatted} Toman`;

  // Convert numbers to Persian numerals
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  const persianFormatted = formatted.replace(/\d/g, (d) => persianDigits[parseInt(d, 10)]);
  return `${persianFormatted} تومان`;
};

export const formatPersianNumber = (val: number | string, lang: Language): string => {
  if (lang !== 'fa') return String(val);
  const persianDigits = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  return String(val).replace(/\d/g, (d) => persianDigits[parseInt(d, 10)] ?? d);
};
