import React, { useState } from 'react';
import { 
  X, 
  Calendar, 
  Clock, 
  User, 
  Phone, 
  Sparkles, 
  CheckCircle2, 
  Hourglass, 
  Copy, 
  Check, 
  Printer, 
  Building2, 
  Stethoscope, 
  SlidersHorizontal,
  FileText,
  AlertCircle
} from 'lucide-react';
import { Venue, RealtimeSlot, Language, BookingRequest } from '../types';
import { VENUES } from '../data/mockData';
import { t, formatPersianNumber } from '../data/translations';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  preselectedVenue?: Venue | null;
  preselectedSlot?: RealtimeSlot | null;
  onSubmitBookingRequest: (requestData: Omit<BookingRequest, 'id' | 'trackingCode' | 'createdAt' | 'status'>) => void;
  submittedRequest?: BookingRequest | null;
}

export const BookingModal: React.FC<Props> = ({
  isOpen,
  onClose,
  lang,
  preselectedVenue,
  preselectedSlot,
  onSubmitBookingRequest,
  submittedRequest,
}) => {
  const strings = t(lang);
  const isFa = lang === 'fa';

  const defaultVenue = preselectedVenue ?? VENUES[0];
  const [selectedVenueId, setSelectedVenueId] = useState<string>(defaultVenue.id);
  const activeVenue = VENUES.find((v) => v.id === selectedVenueId) ?? defaultVenue;

  const [fullName, setFullName] = useState<string>('مریم سهرابی');
  const [phoneNumber, setPhoneNumber] = useState<string>('09123456789');
  const [desiredService, setDesiredService] = useState<string>('تزریق فیلر لب روسی و مادلینگ فک');
  const [suggestedDate, setSuggestedDate] = useState<string>('2026-11-05');
  const [suggestedTime, setSuggestedTime] = useState<string>('۱۶:۰۰ الی ۱۸:۰۰ (شیفت عصر)');
  const [notes, setNotes] = useState<string>('');
  const [copiedTracking, setCopiedTracking] = useState<boolean>(false);

  if (!isOpen) return null;

  // Common quick-pick aesthetic services
  const quickServices = isFa
    ? ['تزریق فیلر و ژل', 'لیزر اندولیفت و هایفو', 'لمینت سرامیکی دندان', 'کامپوزیت ونیر', 'فیشیال و پاکسازی VIP', 'استایل و بالیاژ مو']
    : ['Filler & Botox', 'Endolift Laser', 'Dental Laminate', 'Composite Veneer', 'VIP Facial', 'Hair Balayage'];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const slotLabelFa = preselectedSlot?.roomNameFa || 'یونیت درخواستی پزشک';
    const slotLabelEn = preselectedSlot?.roomNameEn || 'Requested Unit';

    onSubmitBookingRequest({
      fullName,
      phoneNumber,
      desiredService,
      suggestedDate,
      suggestedTime,
      venueId: activeVenue.id,
      venueNameFa: activeVenue.nameFa,
      venueNameEn: activeVenue.nameEn,
      slotId: preselectedSlot?.id,
      slotNameFa: slotLabelFa,
      slotNameEn: slotLabelEn,
      notes,
    });
  };

  const handleCopy = (code: string) => {
    navigator.clipboard?.writeText(code);
    setCopiedTracking(true);
    setTimeout(() => setCopiedTracking(false), 2000);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-neutral-950/85 backdrop-blur-xl transition-opacity"
        onClick={onClose}
      />

      {/* Main Window */}
      <div className="relative w-full max-w-2xl rounded-3xl bg-[#11131A] border border-[#E5C378]/30 p-5 sm:p-8 shadow-2xl text-neutral-100 z-10 my-6 overflow-hidden">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 rtl:left-auto rtl:right-5 p-2 rounded-full bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors cursor-pointer"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {!submittedRequest ? (
          <div>
            {/* Header: Request Mode */}
            <div className="pb-5 border-b border-white/10">
              <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-[#E5C378] mb-1">
                <Calendar className="w-4 h-4 text-[#E5C378]" />
                <span>{isFa ? 'سامانه ثبت درخواست نوبت و رزرو آنلاین' : 'APPOINTMENT BOOKING REQUEST'}</span>
                <span className="text-neutral-500">·</span>
                <span>{isFa ? 'بدون نیاز به پرداخت آنلاین' : 'Direct Clinic Scheduling'}</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                {isFa ? 'درخواست نوبت در کلینیک' : 'Request Clinic Appointment'}
              </h3>
              <p className="text-xs sm:text-sm text-neutral-400 mt-1">
                {isFa
                  ? 'اطلاعات نوبت درخواستی خود را تکمیل نمایید. درخواست شما با وضعیت «در انتظار تأیید» به کارتابل مدیر کلینیک ارسال خواهد شد.'
                  : 'Enter your preferred appointment details. Your request will be queued as "Pending Confirmation" for the clinic director.'}
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="mt-5 space-y-4">
              
              {/* Facility & Assigned Seat Row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                    {isFa ? 'مرکز و کلینیک منتخب:' : 'Selected Facility:'}
                  </label>
                  <select
                    value={selectedVenueId}
                    onChange={(e) => setSelectedVenueId(e.target.value)}
                    className="w-full p-3 rounded-xl bg-neutral-900 border border-[#2B303C] text-white text-xs sm:text-sm focus:outline-none focus:border-[#E5C378]"
                  >
                    {VENUES.map((v) => (
                      <option key={v.id} value={v.id} className="bg-neutral-900 text-white">
                        {isFa ? v.nameFa : v.nameEn} ({isFa ? v.districtNameFa : v.districtNameEn})
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                    {isFa ? 'یونیت یا صندلی درخواستی:' : 'Requested Unit / Chair:'}
                  </label>
                  <div className="w-full p-3 rounded-xl bg-neutral-900/60 border border-[#2B303C] text-neutral-300 text-xs sm:text-sm flex items-center justify-between">
                    <span>
                      {preselectedSlot 
                        ? (isFa ? preselectedSlot.roomNameFa : preselectedSlot.roomNameEn)
                        : (isFa ? 'یونیت تخصصی اصلی کلینیک' : 'Primary VIP Operatory')}
                    </span>
                    <span className="text-[10px] text-emerald-400 bg-emerald-500/15 px-2 py-0.5 rounded font-mono">
                      {isFa ? 'آماده پذیرش' : 'Available'}
                    </span>
                  </div>
                </div>
              </div>

              {/* Full Name & Phone Number */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                    <span className="flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-[#E5C378]" />
                      <span>{isFa ? 'نام و نام خانوادگی متقاضی:' : 'Full Name:'}</span>
                    </span>
                  </label>
                  <input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder={isFa ? 'مثال: مریم سهرابی' : 'e.g. Maryam Sohrabi'}
                    className="w-full p-3 rounded-xl bg-neutral-900 border border-[#2B303C] text-white text-xs sm:text-sm focus:outline-none focus:border-[#E5C378]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                    <span className="flex items-center gap-1.5">
                      <Phone className="w-3.5 h-3.5 text-[#E5C378]" />
                      <span>{isFa ? 'شماره تماس / موبایل جهت هماهنگی:' : 'Phone Number:'}</span>
                    </span>
                  </label>
                  <input
                    type="tel"
                    dir="ltr"
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="0912xxxxxxx"
                    className="w-full p-3 rounded-xl bg-neutral-900 border border-[#2B303C] text-white font-mono text-xs sm:text-sm focus:outline-none focus:border-[#E5C378]"
                    required
                  />
                </div>
              </div>

              {/* Desired Service / Procedure */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <Stethoscope className="w-3.5 h-3.5 text-[#E5C378]" />
                    <span>{isFa ? 'خدمت یا پروسیجر درمانی / زیبایی مورد نظر:' : 'Desired Service / Procedure:'}</span>
                  </span>
                </label>
                <input
                  type="text"
                  value={desiredService}
                  onChange={(e) => setDesiredService(e.target.value)}
                  placeholder={isFa ? 'مثال: تزریق ژل لب، لمینت دندان، هایفوتراپی...' : 'e.g. Lip Filler, Dental Veneers...'}
                  className="w-full p-3 rounded-xl bg-neutral-900 border border-[#2B303C] text-white text-xs sm:text-sm focus:outline-none focus:border-[#E5C378]"
                  required
                />

                {/* Quick Service Tags */}
                <div className="flex flex-wrap items-center gap-1.5 mt-2">
                  <span className="text-[10px] text-neutral-400">{isFa ? 'انتخاب سریع:' : 'Quick Select:'}</span>
                  {quickServices.map((srv, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => setDesiredService(srv)}
                      className="text-[10px] px-2.5 py-1 rounded-lg bg-white/5 hover:bg-[#E5C378]/15 hover:text-[#E5C378] text-neutral-300 border border-white/5 transition-colors cursor-pointer"
                    >
                      {srv}
                    </button>
                  ))}
                </div>
              </div>

              {/* Suggested Date & Time Range */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                    <span className="flex items-center gap-1.5">
                      <Calendar className="w-3.5 h-3.5 text-[#E5C378]" />
                      <span>{isFa ? 'تاریخ پیشنهادی نوبت:' : 'Suggested Date:'}</span>
                    </span>
                  </label>
                  <input
                    type="date"
                    value={suggestedDate}
                    onChange={(e) => setSuggestedDate(e.target.value)}
                    className="w-full p-3 rounded-xl bg-neutral-900 border border-[#2B303C] text-white text-xs sm:text-sm focus:outline-none focus:border-[#E5C378]"
                    required
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-[#E5C378]" />
                      <span>{isFa ? 'بازه زمانی پیشنهادی:' : 'Suggested Time Slot:'}</span>
                    </span>
                  </label>
                  <select
                    value={suggestedTime}
                    onChange={(e) => setSuggestedTime(e.target.value)}
                    className="w-full p-3 rounded-xl bg-neutral-900 border border-[#2B303C] text-white text-xs sm:text-sm focus:outline-none focus:border-[#E5C378]"
                  >
                    <option value="۱۰:۰۰ الی ۱۲:۰۰ (شیفت صبح)" className="bg-neutral-900 text-white">
                      {isFa ? '۱۰:۰۰ الی ۱۲:۰۰ (شیفت صبح)' : '10:00 - 12:00 (Morning)'}
                    </option>
                    <option value="۱۲:۰۰ الی ۱۵:۰۰ (شیفت ظهر)" className="bg-neutral-900 text-white">
                      {isFa ? '۱۲:۰۰ الی ۱۵:۰۰ (شیفت ظهر)' : '12:00 - 15:00 (Afternoon)'}
                    </option>
                    <option value="۱۶:۰۰ الی ۱۸:۰۰ (شیفت عصر)" className="bg-neutral-900 text-white">
                      {isFa ? '۱۶:۰۰ الی ۱۸:۰۰ (شیفت عصر)' : '16:00 - 18:00 (Evening)'}
                    </option>
                    <option value="۱۸:۰۰ الی ۲۱:۰۰ (شیفت شب)" className="bg-neutral-900 text-white">
                      {isFa ? '۱۸:۰۰ الی ۲۱:۰۰ (شیفت شب)' : '18:00 - 21:00 (Night)'}
                    </option>
                  </select>
                </div>
              </div>

              {/* Optional Notes */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-neutral-400" />
                    <span>{isFa ? 'توضیحات تکمیلی یا درخواست خاص (اختیاری):' : 'Additional Notes (Optional):'}</span>
                  </span>
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder={isFa ? 'در صورت داشتن حساسیت، سابقه یا درخواست پزشک خاص یادداشت نمایید...' : 'Add any specific requests or questions...'}
                  className="w-full p-3 rounded-xl bg-neutral-900 border border-[#2B303C] text-white text-xs sm:text-sm focus:outline-none focus:border-[#E5C378] resize-none"
                />
              </div>

              {/* Informational Notice */}
              <div className="p-3.5 rounded-2xl bg-[#E5C378]/10 border border-[#E5C378]/25 text-xs text-amber-200/90 flex items-start gap-2.5">
                <AlertCircle className="w-4 h-4 text-[#E5C378] shrink-0 mt-0.5" />
                <span className="leading-relaxed text-[11px]">
                  {isFa
                    ? 'پس از ثبت فرم، درخواست شما با وضعیت «در انتظار تأیید» در کارتابل مدیر کلینیک قرار می‌گیرد. مدیریت پس از تطبیق تایم صندلی، نوبت را تأیید و با شماره تماس شما تماس حاصل خواهد کرد.'
                    : 'Your request will be queued as Pending Confirmation. Clinic management will review and confirm your slot promptly.'}
                </span>
              </div>

              {/* Actions */}
              <div className="pt-2 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-3 rounded-xl text-xs font-semibold text-neutral-400 hover:text-white transition-colors cursor-pointer"
                >
                  {isFa ? 'انصراف' : 'Cancel'}
                </button>

                <button
                  type="submit"
                  className="flex-1 py-3.5 px-6 rounded-2xl text-xs sm:text-sm font-bold bg-[#E5C378] hover:bg-[#FFE58F] text-neutral-950 transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer font-sans"
                >
                  <Calendar className="w-4 h-4 text-neutral-950" />
                  <span>{isFa ? 'ثبت و ارسال درخواست نوبت (در انتظار تأیید)' : 'Submit Booking Request'}</span>
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* CONFIRMATION SLIP: STATUS = «در انتظار تأیید» */
          <div className="text-center py-4 space-y-5 animate-fadeIn">
            
            {/* Status Icon */}
            <div className="relative w-16 h-16 mx-auto">
              <div className="w-16 h-16 rounded-full bg-amber-500/20 text-[#E5C378] border border-[#E5C378]/40 flex items-center justify-center shadow-lg shadow-amber-500/20">
                <Hourglass className="w-8 h-8 animate-pulse text-[#E5C378]" />
              </div>
            </div>

            {/* Glowing Pending Confirmation Status Badge */}
            <div className="flex flex-col items-center justify-center space-y-2">
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/15 border border-amber-400/40 text-amber-300 font-bold text-sm sm:text-base shadow-sm">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400 animate-ping" />
                <span>{isFa ? 'وضعیت نوبت: «در انتظار تأیید»' : 'Status: «Pending Confirmation»'}</span>
              </div>

              <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                {isFa ? 'درخواست نوبت شما با موفقیت ثبت شد' : 'Appointment Request Queued'}
              </h3>
              <p className="text-xs text-neutral-400 max-w-md mx-auto leading-relaxed">
                {isFa
                  ? 'اطلاعات شما به کارتابل مدیریت کلینیک ارسال گردید. منشی کلینیک پس از بررسی صندلی خالی، با شماره شما تماس گرفته و نوبت به «تأیید شده» تغییر خواهد یافت.'
                  : 'Your request has been routed to the clinic director. Once reviewed, the status will update to Confirmed.'}
              </p>
            </div>

            {/* Prominent Tracking Code Spotlight Card */}
            <div className="max-w-lg mx-auto p-4 rounded-2xl bg-[#1A1D26] border border-[#E5C378]/30 shadow-lg text-left rtl:text-right">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <span className="text-[10px] text-amber-300/90 font-bold uppercase tracking-wider block">
                    {isFa ? 'کد پیگیری درخواست نوبت' : 'Request Tracking Code'}
                  </span>
                  <div className="text-xl sm:text-2xl font-mono font-black text-[#E5C378] tracking-wider mt-0.5 select-all">
                    {submittedRequest.trackingCode}
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => handleCopy(submittedRequest.trackingCode)}
                  className="px-3.5 py-2 rounded-xl bg-[#E5C378]/20 hover:bg-[#E5C378]/30 text-amber-200 text-xs font-bold border border-[#E5C378]/40 flex items-center justify-center gap-1.5 transition-all self-start sm:self-center cursor-pointer"
                >
                  {copiedTracking ? (
                    <>
                      <Check className="w-4 h-4 text-emerald-400" />
                      <span className="text-emerald-400">{isFa ? 'کپی شد! ✓' : 'Copied! ✓'}</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-4 h-4 text-[#E5C378]" />
                      <span>{isFa ? 'کپی کد پیگیری' : 'Copy Code'}</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Request Summary Receipt */}
            <div className="max-w-lg mx-auto p-5 rounded-2xl bg-neutral-900 border border-neutral-800 text-left rtl:text-right space-y-3 text-xs text-neutral-300 shadow-xl">
              <div className="flex items-center justify-between border-b border-neutral-800 pb-3">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-white/5 flex items-center justify-center text-[#E5C378]">
                    <Building2 className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[10px] text-neutral-400">{isFa ? 'مرکز درمانی:' : 'Facility:'}</div>
                    <div className="text-sm font-bold text-white">{submittedRequest.venueNameFa}</div>
                  </div>
                </div>

                <span className="text-[10px] font-mono text-amber-400 bg-amber-500/10 px-2.5 py-1 rounded-full border border-amber-500/20 font-bold">
                  {isFa ? 'در انتظار بررسی مدیر' : 'Pending Review'}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-1">
                <div>
                  <span className="text-neutral-500 text-[11px] block">{isFa ? 'نام متقاضی:' : 'Applicant:'}</span>
                  <span className="font-semibold text-white text-xs sm:text-sm">{submittedRequest.fullName}</span>
                </div>

                <div>
                  <span className="text-neutral-500 text-[11px] block">{isFa ? 'شماره تماس:' : 'Phone:'}</span>
                  <span className="font-mono text-white text-xs sm:text-sm">{submittedRequest.phoneNumber}</span>
                </div>

                <div>
                  <span className="text-neutral-500 text-[11px] block">{isFa ? 'خدمت مورد نظر:' : 'Service:'}</span>
                  <span className="font-semibold text-[#E5C378] text-xs sm:text-sm">{submittedRequest.desiredService}</span>
                </div>

                <div>
                  <span className="text-neutral-500 text-[11px] block">{isFa ? 'زمان پیشنهادی:' : 'Suggested Time:'}</span>
                  <span className="font-semibold text-white text-xs">{submittedRequest.suggestedDate} ({submittedRequest.suggestedTime})</span>
                </div>
              </div>

              {submittedRequest.slotNameFa && (
                <div className="border-t border-neutral-800 pt-2 flex justify-between text-[11px]">
                  <span className="text-neutral-400">{isFa ? 'صندلی / یونیت درخواستی:' : 'Requested Slot:'}</span>
                  <span className="text-neutral-200 font-semibold">{submittedRequest.slotNameFa}</span>
                </div>
              )}
            </div>

            {/* Actions: Print and Return */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              <button
                type="button"
                onClick={handlePrint}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/15 text-white border border-white/10 transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Printer className="w-4 h-4 text-[#E5C378]" />
                <span>{isFa ? 'چاپ رسید درخواست' : 'Print Slip'}</span>
              </button>

              <button
                type="button"
                onClick={onClose}
                className="px-6 py-2.5 rounded-xl text-xs font-semibold bg-white text-neutral-950 hover:bg-neutral-100 transition-colors shadow-md cursor-pointer"
              >
                {isFa ? 'بستن و بازگشت به سایت' : 'Close & Return'}
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
