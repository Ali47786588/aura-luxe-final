import React, { useState, useRef, useCallback } from 'react';
import { Sparkles, Smile, ArrowLeftRight, CheckCircle2, ChevronRight, ChevronLeft } from 'lucide-react';
import { BeforeAfterCase, Language } from '../types';
import { BEFORE_AFTER_CASES } from '../data/mockData';
import { t } from '../data/translations';

interface Props {
  lang: Language;
  onBookSimilarSuite: (caseItem: BeforeAfterCase) => void;
}

export const BeforeAfterSlider: React.FC<Props> = ({
  lang,
  onBookSimilarSuite,
}) => {
  const [selectedCaseId, setSelectedCaseId] = useState<string>(BEFORE_AFTER_CASES[0].id);
  const [sliderPosition, setSliderPosition] = useState<number>(50); // percentage 0 - 100
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const containerRef = useRef<HTMLDivElement>(null);

  const strings = t(lang);
  const isFa = lang === 'fa';
  const ChevronIcon = isFa ? ChevronLeft : ChevronRight;

  const activeCase = BEFORE_AFTER_CASES.find((c) => c.id === selectedCaseId) ?? BEFORE_AFTER_CASES[0];

  const handleMove = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    let percentage = (x / rect.width) * 100;
    if (percentage < 0) percentage = 0;
    if (percentage > 100) percentage = 100;
    setSliderPosition(percentage);
  }, []);

  const handleTouchMove = (e: React.TouchEvent) => {
    handleMove(e.touches[0].clientX);
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    handleMove(e.clientX);
  };

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    handleMove(e.clientX);
  };

  return (
    <div className="rounded-3xl border border-neutral-200 dark:border-white/10 bg-white/70 dark:bg-neutral-900/50 backdrop-blur-xl p-6 sm:p-8 shadow-sm">
      {/* Header and Case Switcher Tabs */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-neutral-200 dark:border-white/10">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium text-neutral-500 dark:text-neutral-400 mb-1">
            <span className="font-semibold text-neutral-900 dark:text-white uppercase tracking-wider">
              {strings.navBeforeAfter}
            </span>
            <span aria-hidden="true">·</span>
            <span>{strings.dragHint}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-white">
            {strings.beforeAfterTitle}
          </h2>
          <p className="text-sm text-neutral-500 dark:text-neutral-400 mt-1 max-w-xl">
            {strings.beforeAfterSubtitle}
          </p>
        </div>

        {/* Case Switcher Tabs */}
        <div className="flex p-1.5 rounded-2xl bg-neutral-100 dark:bg-white/5 border border-neutral-200 dark:border-white/10 gap-1.5 self-start lg:self-center">
          {BEFORE_AFTER_CASES.map((c) => {
            const isSelected = c.id === selectedCaseId;
            return (
              <button
                key={c.id}
                onClick={() => {
                  setSelectedCaseId(c.id);
                  setSliderPosition(50);
                }}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                  isSelected
                    ? 'bg-neutral-950 text-white dark:bg-white dark:text-neutral-950 shadow-sm'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                }`}
              >
                {c.category === 'dental' ? (
                  <Smile className="w-3.5 h-3.5" />
                ) : (
                  <Sparkles className="w-3.5 h-3.5" />
                )}
                <span>{isFa ? c.titleFa.split(' ')[0] + ' ' + c.titleFa.split(' ')[1] : c.titleEn.split(' ').slice(0, 3).join(' ')}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Comparison Area: 2-Column Split */}
      <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Left: Draggable Cinematic Split Slider (7 cols) */}
        <div className="lg:col-span-7">
          <div
            ref={containerRef}
            onPointerDown={handlePointerDown}
            onPointerUp={() => setIsDragging(false)}
            onPointerLeave={() => setIsDragging(false)}
            onPointerMove={handleMouseMove}
            onTouchMove={handleTouchMove}
            className="relative aspect-[4/3] rounded-3xl overflow-hidden cursor-ew-resize select-none border border-neutral-200 dark:border-white/10 shadow-2xl bg-neutral-900"
          >
            {/* After Image (Full background layer) */}
            <img
              src={activeCase.afterImage}
              alt="After transformation"
              className="absolute inset-0 w-full h-full object-cover pointer-events-none"
              referrerPolicy="no-referrer"
            />

            {/* Before Image with Clinical Filter Overlay (Clipped layer) */}
            <div
              className="absolute inset-0 overflow-hidden pointer-events-none"
              style={{ width: `${sliderPosition}%` }}
            >
              <img
                src={activeCase.afterImage}
                alt="Before transformation"
                className="absolute inset-0 w-full h-full object-cover max-w-none pointer-events-none"
                style={{
                  width: containerRef.current ? `${containerRef.current.clientWidth}px` : '100%',
                  height: '100%',
                  filter: activeCase.beforeFilter,
                }}
                referrerPolicy="no-referrer"
              />
              {/* Subtle vintage clinical texture vignette for the before section */}
              <div className="absolute inset-0 bg-neutral-900/10 pointer-events-none" />
            </div>

            {/* Floating Labels: BEFORE & AFTER */}
            <div className="absolute top-4 left-4 apple-glass px-3 py-1 rounded-xl text-[11px] font-bold text-white tracking-widest border border-white/20 pointer-events-none">
              {strings.beforeLabel}
            </div>
            <div className="absolute top-4 right-4 apple-glass px-3 py-1 rounded-xl text-[11px] font-bold text-white tracking-widest border border-white/20 pointer-events-none">
              {strings.afterLabel}
            </div>

            {/* Center Draggable Hairline Divider & Thumb */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-white shadow-2xl pointer-events-none flex items-center justify-center"
              style={{ left: `${sliderPosition}%` }}
            >
              {/* Apple-grade glass thumb */}
              <div className="w-9 h-9 rounded-full apple-glass border border-white/80 shadow-2xl flex items-center justify-center text-white -translate-x-1/2">
                <ArrowLeftRight className="w-4 h-4" />
              </div>
            </div>

            {/* Bottom percentage indicator */}
            <div className="absolute bottom-4 inset-x-4 flex justify-between items-center text-xs text-white/90 pointer-events-none">
              <span className="apple-glass px-2.5 py-0.5 rounded-lg border border-white/10 font-mono tabular-nums">
                {isFa ? `تقسیم تصویر: ٪${Math.round(sliderPosition)}` : `Split: ${Math.round(sliderPosition)}%`}
              </span>
              <span className="apple-glass px-2.5 py-0.5 rounded-lg border border-white/10 text-[11px]">
                {strings.dragHint}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Clinical Metrics & Details (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          <div>
            <div className="text-xs font-mono uppercase tracking-wider text-neutral-400 mb-1">
              {strings.performedAt} {isFa ? activeCase.clinicNameFa : activeCase.clinicNameEn}
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-neutral-900 dark:text-white leading-snug">
              {isFa ? activeCase.titleFa : activeCase.titleEn}
            </h3>
            <p className="text-xs sm:text-sm text-neutral-600 dark:text-neutral-300 mt-2.5 leading-relaxed">
              {isFa ? activeCase.treatmentFa : activeCase.treatmentEn}
            </p>
          </div>

          {/* Metrics Grid */}
          <div className="p-5 rounded-2xl bg-neutral-100/70 dark:bg-white/5 border border-neutral-200 dark:border-white/10 space-y-3">
            <div className="text-xs font-semibold text-neutral-500 dark:text-neutral-400 uppercase tracking-wider">
              {strings.clinicalMetrics}
            </div>
            <div className="space-y-2.5">
              {(isFa ? activeCase.metricsFa : activeCase.metricsEn).map((m, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs sm:text-sm">
                  <span className="text-neutral-500 dark:text-neutral-400">{m.label}</span>
                  <span className="font-semibold text-neutral-900 dark:text-white tabular-nums">
                    {m.value}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Doctor Quote / Notes */}
          <div className="p-4 rounded-2xl border border-neutral-200 dark:border-white/10 bg-white dark:bg-neutral-900/60 text-xs text-neutral-600 dark:text-neutral-300 leading-relaxed">
            <span className="font-semibold text-neutral-900 dark:text-white block mb-1">
              {strings.doctorInCharge} {isFa ? activeCase.doctorNameFa : activeCase.doctorNameEn}
            </span>
            {isFa ? activeCase.notesFa : activeCase.notesEn}
          </div>

          {/* Action Button */}
          <button
            onClick={() => onBookSimilarSuite(activeCase)}
            className="w-full py-3.5 px-5 rounded-2xl text-sm font-semibold bg-neutral-950 text-white hover:bg-neutral-800 dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 transition-all shadow-md flex items-center justify-center gap-2"
          >
            <span>{strings.bookSimilarSuite}</span>
            <ChevronIcon className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
