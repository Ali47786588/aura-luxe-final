import React, { useState, useEffect } from 'react';
import { ShieldAlert, CheckCircle2, XCircle, Clock, Building2, UserCheck, DollarSign, FileText, ArrowLeft, ArrowRight, Lock, Key, RefreshCw, AlertCircle, ExternalLink, Sparkles, Terminal } from 'lucide-react';
import { OnboardingApplication, Language, EscrowTransaction, SecurityAuditRecord } from '../types';
import { INITIAL_APPLICATIONS, INITIAL_ESCROW_TRANSACTIONS } from '../data/mockData';
import { t, formatPrice, formatPersianNumber } from '../data/translations';

interface Props {
  lang: Language;
  onExitSuperAdmin: () => void;
  applications: OnboardingApplication[];
  onUpdateAppStatus: (appId: string, status: 'approved' | 'rejected') => void;
  onTriggerToast?: (type: 'success' | 'warning' | 'error' | 'info', title: string, message: string) => void;
}

export const SuperAdminPanel: React.FC<Props> = ({
  lang,
  onExitSuperAdmin,
  applications,
  onUpdateAppStatus,
  onTriggerToast,
}) => {
  const [activeTab, setActiveTab] = useState<'approvals' | 'revenues' | 'audit_logs'>('approvals');
  const [liveAuditLogs, setLiveAuditLogs] = useState<SecurityAuditRecord[]>([]);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const strings = t(lang);
  const isFa = lang === 'fa';

  const fetchLogs = () => {
    setIsRefreshing(true);
    fetch('/api/audit-logs')
      .then((res) => res.json())
      .then((data) => {
        if (data.logs) {
          setLiveAuditLogs(data.logs);
        }
      })
      .catch((err) => console.log('Audit log fetch error', err))
      .finally(() => setIsRefreshing(false));
  };

  useEffect(() => {
    fetchLogs();
  }, []);

  const pendingApps = applications.filter((a) => a.status === 'pending');
  const approvedApps = applications.filter((a) => a.status === 'approved');

  // Master Financial Stats across the entire platform
  const totalGMVToman = 248600000; // 248.6M Toman
  const totalPlatformCutToman = 19888000; // 8% take-rate
  const totalActiveVenues = 74;

  return (
    <div className="min-h-screen bg-[#0A0A0C] text-neutral-100 py-8 px-4 sm:px-6 lg:px-8 space-y-8 animate-fadeIn">
      {/* Top SuperAdmin Header */}
      <div className="max-w-7xl mx-auto rounded-3xl apple-glass border border-amber-400/20 p-5 sm:p-6 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-amber-200 via-amber-400 to-amber-600 text-neutral-950 flex items-center justify-center font-bold text-xl shadow-lg shrink-0">
            <ShieldAlert className="w-6 h-6" />
          </div>

          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-amber-300 mb-0.5">
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
              <span>SUPERADMIN MASTER CONSOLE</span>
              <span aria-hidden="true" className="text-neutral-500">·</span>
              <span className="text-neutral-400 font-sans">{isFa ? 'دسترسی رگولاتوری و نظارت کل سیستم' : 'Full Regulatory Clearance'}</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
              {isFa ? 'مرکز مدیریت کلان پلتفرم و تایید همکاران' : 'Master Governance & Partner Audit'}
            </h1>
            <p className="text-xs text-neutral-400 mt-0.5">
              {isFa
                ? 'نظارت بر تمامی کلینیک‌های تهران و کرج، بررسی مدارک نظام پزشکی و تسویه حساب‌های مالی'
                : 'Auditing all clinical applications, licensing verification and cross-venue revenue clearance.'}
            </p>
          </div>
        </div>

        {/* Exit Master Panel button */}
        <button
          onClick={onExitSuperAdmin}
          className="px-5 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold bg-white/10 hover:bg-white/20 text-neutral-200 hover:text-white border border-white/10 transition-colors flex items-center gap-2 self-stretch md:self-auto justify-center"
        >
          <Lock className="w-4 h-4 text-amber-300" />
          <span>{strings.switchToPublicView}</span>
        </button>
      </div>

      {/* High-Level Platform KPIs */}
      <div className="max-w-7xl mx-auto grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="p-5 rounded-2xl bg-neutral-900/80 border border-neutral-800">
          <div className="text-xs font-mono text-neutral-400 uppercase tracking-wider">
            {isFa ? 'گردش مالی کل پلتفرم (GMV)' : 'GROSS MARKETPLACE VOLUME'}
          </div>
          <div className="text-2xl font-bold text-white mt-1.5 tabular-nums">
            {formatPrice(totalGMVToman, lang)}
          </div>
          <div className="text-[11px] text-emerald-400 mt-2 flex items-center gap-1 font-medium">
            <Sparkles className="w-3 h-3 text-amber-300" />
            <span>{isFa ? 'تراکنش‌های امانی شاپرک/پایا' : '100% Escrow Collateralized'}</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-neutral-900/80 border border-neutral-800">
          <div className="text-xs font-mono text-neutral-400 uppercase tracking-wider">
            {isFa ? 'درآمد ناخالص کارمزد سیستم' : 'NET PLATFORM COMMISSION'}
          </div>
          <div className="text-2xl font-bold text-amber-300 mt-1.5 tabular-nums">
            {formatPrice(totalPlatformCutToman, lang)}
          </div>
          <div className="text-[11px] text-neutral-400 mt-2">
            {isFa ? 'میانگین ۱۲٪ تعرفه B2B پلتفرم' : 'Effective 12.0% platform take-rate'}
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-neutral-900/80 border border-neutral-800">
          <div className="text-xs font-mono text-neutral-400 uppercase tracking-wider">
            {isFa ? 'درخواست‌های در صف تایید' : 'APPLICATIONS IN QUEUE'}
          </div>
          <div className="text-2xl font-bold text-white mt-1.5 tabular-nums">
            {formatPersianNumber(pendingApps.length, lang)} {isFa ? 'مرکز' : 'Centers'}
          </div>
          <div className="text-[11px] text-amber-400 mt-2 flex items-center gap-1">
            <Clock className="w-3 h-3" />
            <span>{isFa ? 'نیاز به بررسی مدارک مجوز' : 'Requires regulatory sign-off'}</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-neutral-900/80 border border-neutral-800">
          <div className="text-xs font-mono text-neutral-400 uppercase tracking-wider">
            {isFa ? 'مراکز فعال و تایید شده' : 'VERIFIED ACTIVE VENUES'}
          </div>
          <div className="text-2xl font-bold text-emerald-400 mt-1.5 tabular-nums">
            {formatPersianNumber(totalActiveVenues, lang)}
          </div>
          <div className="text-[11px] text-neutral-400 mt-2">
            {isFa ? 'پوشش کامل تهران و کرج' : 'Tehran & Karaj clinical hubs'}
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="max-w-7xl mx-auto flex items-center justify-start overflow-x-auto pb-1 no-scrollbar">
        <div className="inline-flex p-1.5 rounded-2xl bg-neutral-900 border border-neutral-800 gap-1.5">
          <button
            onClick={() => setActiveTab('approvals')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeTab === 'approvals'
                ? 'bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 shadow-md font-bold'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>{isFa ? 'تایید همکاران و صف ثبت‌نام' : 'Partner Approvals & KYC'}</span>
            {pendingApps.length > 0 && (
              <span className="px-2 py-0.5 rounded-full text-[10px] bg-red-500 text-white font-bold tabular-nums">
                {formatPersianNumber(pendingApps.length, lang)}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('revenues')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeTab === 'revenues'
                ? 'bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 shadow-md font-bold'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <DollarSign className="w-4 h-4" />
            <span>{isFa ? 'دفتر کل امانی و درآمدها' : 'Escrow Ledger Audit'}</span>
          </button>

          <button
            onClick={() => setActiveTab('audit_logs')}
            className={`flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-semibold transition-all ${
              activeTab === 'audit_logs'
                ? 'bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 shadow-md font-bold'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>{isFa ? 'لاگ امنیتی سیستم' : 'System Security Logs'}</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Partner Approvals Queue */}
      {activeTab === 'approvals' && (
        <div className="max-w-7xl mx-auto space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white">
              {isFa ? 'صف درخواست‌های عضویت کلینیک‌ها و پزشکان جدید' : 'Pending Partner Verification Queue'}
            </h3>
            <span className="text-xs text-neutral-400">
              {isFa ? 'بررسی اصالت مجوز نظام پزشکی و استانداردهای بهداشتی' : 'Medical Board verification protocol'}
            </span>
          </div>

          <div className="space-y-3.5">
            {applications.map((app) => {
              const isPending = app.status === 'pending';
              const isApproved = app.status === 'approved';

              return (
                <div
                  key={app.id}
                  className={`p-5 sm:p-6 rounded-2xl border transition-all flex flex-col md:flex-row md:items-center justify-between gap-6 ${
                    isPending
                      ? 'bg-neutral-900/90 border-amber-500/30 shadow-lg'
                      : isApproved
                      ? 'bg-neutral-900/40 border-neutral-800'
                      : 'bg-neutral-900/20 border-red-500/20 opacity-70'
                  }`}
                >
                  <div className="space-y-2">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <span className="text-[11px] font-mono px-2.5 py-0.5 rounded-md bg-white/10 text-neutral-300">
                        {app.applicantType === 'clinic' ? 'CLINIC' : app.applicantType === 'doctor' ? 'DOCTOR' : 'SALON'}
                      </span>
                      <h4 className="text-base sm:text-lg font-bold text-white">
                        {app.businessName}
                      </h4>
                      <span
                        className={`text-[11px] font-semibold px-2.5 py-0.5 rounded-full ${
                          isPending
                            ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                            : isApproved
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : 'bg-red-500/20 text-red-400 border border-red-500/30'
                        }`}
                      >
                        {isPending ? (isFa ? 'در انتظار بررسی' : 'Pending Review') : isApproved ? (isFa ? 'تایید شده ✓' : 'Approved ✓') : (isFa ? 'رد شده' : 'Rejected')}
                      </span>
                    </div>

                    <div className="text-xs text-neutral-400 space-y-1">
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                        <span><strong className="text-neutral-200">{isFa ? 'نام / مسئول:' : 'Director:'}</strong> {app.applicantName || app.businessName}</span>
                        {app.medicalCouncilOrGuildId && app.medicalCouncilOrGuildId !== 'PENDING' && (
                          <span><strong className="text-neutral-200">{isFa ? 'کد نظام/صنف:' : 'License ID:'}</strong> <span className="font-mono text-amber-300">{app.medicalCouncilOrGuildId}</span></span>
                        )}
                        <span><strong className="text-neutral-200">{isFa ? 'تلفن تماس:' : 'Phone:'}</strong> <span className="font-mono text-neutral-300">{app.phoneNumber}</span></span>
                      </div>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                        <span><strong className="text-neutral-200">{isFa ? 'موقعیت:' : 'Location:'}</strong> {app.cityAndDistrict || (app.cityId ? (app.cityId === 'tehran' ? (isFa ? 'تهران' : 'Tehran') : (isFa ? 'کرج' : 'Karaj')) + ' · ' + app.district : app.district)}</span>
                        <span><strong className="text-neutral-200">{isFa ? 'تعداد صندلی/تخت:' : 'Capacity:'}</strong> {formatPersianNumber(app.chairsOrBedsCount, lang)} {isFa ? 'تخت/صندلی' : 'units'}</span>
                      </div>
                      {(app.shortDescription || app.primaryEquipment) && (
                        <div>
                          <strong className="text-neutral-200">{isFa ? 'توضیحات:' : 'Notes & Equipment:'}</strong> {app.shortDescription || app.primaryEquipment}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2.5 shrink-0">
                    {isPending ? (
                      <>
                        <button
                          onClick={() => onUpdateAppStatus(app.id, 'approved')}
                          className="px-4 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 hover:opacity-90 transition-all shadow-md flex items-center gap-1.5"
                        >
                          <CheckCircle2 className="w-4 h-4 text-neutral-950" />
                          <span>{isFa ? 'تایید و صدور مجوز B2B' : 'Approve & Activate'}</span>
                        </button>

                        <button
                          onClick={() => onUpdateAppStatus(app.id, 'rejected')}
                          className="px-3.5 py-2.5 rounded-xl text-xs font-semibold bg-white/5 hover:bg-red-500/20 text-neutral-400 hover:text-red-300 border border-white/10 transition-colors"
                        >
                          {isFa ? 'رد درخواست' : 'Reject'}
                        </button>
                      </>
                    ) : (
                      <button
                        onClick={() => onUpdateAppStatus(app.id, isApproved ? 'rejected' : 'approved')}
                        className="px-3.5 py-2 rounded-xl text-xs font-medium bg-white/5 hover:bg-white/10 text-neutral-300 border border-white/10 transition-colors"
                      >
                        {isApproved ? (isFa ? 'تعلیق مجوز' : 'Revoke') : (isFa ? 'تایید مجدد' : 'Re-approve')}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Tab 2: Master Escrow Revenues */}
      {activeTab === 'revenues' && (
        <div className="max-w-7xl mx-auto space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white">
              {isFa ? 'دفتر کل تراکنش‌ها و تسویه حساب‌های کل پلتفرم' : 'Master Escrow & Clearing Ledger'}
            </h3>
            <span className="text-xs font-mono text-amber-300">
              AUDITED BY BANK SHAPARAK GATEWAY
            </span>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-neutral-800 bg-neutral-900/70">
            <table className="w-full text-left rtl:text-right text-xs">
              <thead className="bg-neutral-900 border-b border-neutral-800 text-neutral-400">
                <tr>
                  <th className="py-3.5 px-4 font-semibold">{isFa ? 'کد قرارداد امانی' : 'Contract ID'}</th>
                  <th className="py-3.5 px-4 font-semibold">{isFa ? 'پزشک طرف قرارداد' : 'Practitioner'}</th>
                  <th className="py-3.5 px-4 font-semibold">{isFa ? 'کلینیک میزبان' : 'Host Venue'}</th>
                  <th className="py-3.5 px-4 font-semibold">{isFa ? 'مبلغ ناخالص' : 'Gross Volume'}</th>
                  <th className="py-3.5 px-4 font-semibold text-amber-300">{isFa ? 'سود ناخالص سیستم' : 'Platform Cut'}</th>
                  <th className="py-3.5 px-4 font-semibold text-emerald-400">{isFa ? 'واریزی به شبا کلینیک' : 'Clinic Net'}</th>
                  <th className="py-3.5 px-4 font-semibold">{isFa ? 'وضعیت تسویه' : 'Status'}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-neutral-800/80">
                {INITIAL_ESCROW_TRANSACTIONS.map((tx) => (
                  <tr key={tx.id} className="hover:bg-white/5 transition-colors">
                    <td className="py-3.5 px-4 font-mono font-medium text-amber-300">{tx.contractCode}</td>
                    <td className="py-3.5 px-4 font-semibold text-white">{tx.practitionerName}</td>
                    <td className="py-3.5 px-4 text-neutral-300">{tx.venueName}</td>
                    <td className="py-3.5 px-4 font-bold text-white tabular-nums">{formatPrice(tx.grossAmountToman, lang)}</td>
                    <td className="py-3.5 px-4 font-bold text-amber-300 tabular-nums">+{formatPrice(tx.platformFeeToman, lang)}</td>
                    <td className="py-3.5 px-4 font-bold text-emerald-400 tabular-nums">{formatPrice(tx.clinicPayoutToman, lang)}</td>
                    <td className="py-3.5 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-500/20 text-emerald-400">
                        {tx.status === 'released' ? (isFa ? 'تسویه کامل' : 'Released') : (isFa ? 'بلوکه در اسکرو' : 'Escrow Held')}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 3: System Security & Audit Logs */}
      {activeTab === 'audit_logs' && (
        <div className="max-w-7xl mx-auto space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <Terminal className="w-5 h-5 text-amber-300" />
              <span>{isFa ? 'لاگ‌های امنیتی و رویدادهای زنده سیستمی' : 'Immutable Security Audit Trail'}</span>
            </h3>
            <button
              onClick={fetchLogs}
              disabled={isRefreshing}
              className="px-3.5 py-1.5 rounded-xl bg-neutral-900 border border-neutral-700 hover:border-amber-400/40 text-xs font-mono text-neutral-300 hover:text-white flex items-center gap-1.5 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-amber-300 ${isRefreshing ? 'animate-spin' : ''}`} />
              <span>{isFa ? 'بروزرسانی لاگ‌ها' : 'Refresh Feed'}</span>
            </button>
          </div>

          <div className="rounded-2xl bg-neutral-900/90 border border-neutral-800 p-4 space-y-3 font-mono text-xs text-neutral-300 overflow-x-auto">
            {liveAuditLogs.length === 0 ? (
              <p className="text-neutral-500 py-6 text-center">{isFa ? 'داده‌ای یافت نشد' : 'No audit records'}</p>
            ) : (
              liveAuditLogs.map((log) => {
                let badgeClass = 'text-sky-400 bg-sky-500/10 border-sky-500/20';
                if (log.severity === 'critical') badgeClass = 'text-red-400 bg-red-500/10 border-red-500/20';
                if (log.severity === 'warning') badgeClass = 'text-amber-300 bg-amber-500/10 border-amber-500/20';

                return (
                  <div key={log.id} className="p-3 rounded-xl bg-neutral-950/80 border border-neutral-850 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold border uppercase ${badgeClass}`}>
                          {log.type} · {log.severity}
                        </span>
                        <span className="font-semibold text-white">
                          {isFa ? log.titleFa : log.titleEn}
                        </span>
                      </div>
                      <p className="text-[11px] text-neutral-400 font-sans">
                        {log.details}
                      </p>
                    </div>

                    <div className="text-left rtl:text-right sm:rtl:text-left text-[11px] text-neutral-500 shrink-0 font-mono">
                      <div>{new Date(log.timestamp).toLocaleTimeString(isFa ? 'fa-IR' : 'en-US')}</div>
                      <div>IP: {log.ip}</div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};
