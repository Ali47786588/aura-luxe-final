import React, { useRef, useState, useEffect } from 'react';
import { Eraser, Check, ShieldCheck, PenTool } from 'lucide-react';
import { Language } from '../types';

interface Props {
  lang: Language;
  signerName: string;
  signerRole: 'doctor' | 'patient';
  onSaveSignature: (signatureSvg: string, checksum: string) => void;
  onCancel?: () => void;
}

export const DigitalSignaturePad: React.FC<Props> = ({
  lang,
  signerName,
  signerRole,
  onSaveSignature,
  onCancel,
}) => {
  const isFa = lang === 'fa';
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);
  const [checksum, setChecksum] = useState('');

  useEffect(() => {
    // Generate initial dynamic checksum
    const rand = 'SIG-2026-' + Math.random().toString(36).substring(2, 8).toUpperCase() + '-' + Date.now().toString().slice(-4);
    setChecksum(rand);
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Handle high DPI
    const rect = canvas.getBoundingClientRect();
    canvas.width = rect.width * 2;
    canvas.height = rect.height * 2;
    ctx.scale(2, 2);
    ctx.strokeStyle = '#FDE68A'; // champagne gold
    ctx.lineWidth = 2.5;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
  }, []);

  const getCoordinates = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();

    if ('touches' in e) {
      const touch = e.touches[0];
      return {
        x: touch.clientX - rect.left,
        y: touch.clientY - rect.top,
      };
    } else {
      return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top,
      };
    }
  };

  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCoordinates(e);
    ctx.beginPath();
    ctx.moveTo(x, y);
    setIsDrawing(true);
    setHasDrawn(true);
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const { x, y } = getCoordinates(e);
    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    e.preventDefault();
    setIsDrawing(false);
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    setHasDrawn(false);
  };

  const handleConfirm = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const dataUrl = canvas.toDataURL('image/png');
    onSaveSignature(dataUrl, checksum);
  };

  return (
    <div className="rounded-2xl bg-neutral-900/90 border border-neutral-700/80 p-4 text-neutral-100 shadow-xl">
      <div className="flex items-center justify-between pb-3 border-b border-neutral-800 mb-3">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-amber-400/10 text-amber-300 flex items-center justify-center border border-amber-400/20">
            <PenTool className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-xs sm:text-sm font-bold text-white">
              {signerRole === 'doctor'
                ? (isFa ? 'امضای دیجیتال پزشک معالج' : 'Doctor Digital Signature')
                : (isFa ? 'امضا و تایید دریافت خدمات بیمار' : 'Patient Service Acceptance Signature')}
            </h4>
            <p className="text-[11px] text-neutral-400 font-mono">
              {signerName} · {checksum}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-[11px] text-amber-300/80 font-mono bg-neutral-950 px-2.5 py-1 rounded-md border border-neutral-800">
          <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
          <span>{isFa ? 'رمزنگاری SHA-256' : 'SHA-256 Sealed'}</span>
        </div>
      </div>

      {/* Signature Canvas Box */}
      <div className="relative rounded-xl border border-dashed border-amber-300/30 bg-neutral-950/80 overflow-hidden">
        <canvas
          ref={canvasRef}
          onMouseDown={startDrawing}
          onMouseMove={draw}
          onMouseUp={stopDrawing}
          onMouseLeave={stopDrawing}
          onTouchStart={startDrawing}
          onTouchMove={draw}
          onTouchEnd={stopDrawing}
          className="w-full h-36 cursor-crosshair touch-none"
        />

        {!hasDrawn && (
          <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-neutral-500">
            <PenTool className="w-5 h-5 mb-1.5 opacity-40 text-amber-300" />
            <p className="text-xs font-medium">
              {isFa ? 'جهت تایید رسمی، در این کادر با قلم یا لمس انگشت امضا فرمایید' : 'Sign here with finger or stylus'}
            </p>
          </div>
        )}

        <div className="absolute bottom-2 left-3 rtl:left-auto rtl:right-3 text-[10px] text-neutral-500 font-mono">
          {new Date().toLocaleString(isFa ? 'fa-IR' : 'en-US')}
        </div>
      </div>

      {/* Control Actions */}
      <div className="flex items-center justify-between gap-3 mt-3 pt-2">
        <button
          type="button"
          onClick={clearCanvas}
          className="px-3 py-1.5 rounded-lg text-xs font-medium text-neutral-400 hover:text-white hover:bg-neutral-800 border border-neutral-800 transition-colors flex items-center gap-1.5"
        >
          <Eraser className="w-3.5 h-3.5" />
          <span>{isFa ? 'پاک کردن' : 'Clear'}</span>
        </button>

        <div className="flex items-center gap-2">
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="px-3 py-1.5 rounded-lg text-xs text-neutral-400 hover:text-white transition-colors"
            >
              {isFa ? 'انصراف' : 'Cancel'}
            </button>
          )}

          <button
            type="button"
            disabled={!hasDrawn}
            onClick={handleConfirm}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
              hasDrawn
                ? 'bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 shadow-md hover:opacity-95'
                : 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700'
            }`}
          >
            <Check className="w-3.5 h-3.5" />
            <span>{isFa ? 'ثبت و الصاق امضا به پرونده' : 'Apply Official Signature'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
