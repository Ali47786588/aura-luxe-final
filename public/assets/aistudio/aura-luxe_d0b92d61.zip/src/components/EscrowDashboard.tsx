import React, { useState, useEffect } from 'react';
import { ShieldCheck, ArrowUpRight, DollarSign, Calculator, Lock, CheckCircle2, Clock, FileText, ChevronRight, Download, RefreshCw, UserCheck, Stethoscope, AlertTriangle, ShieldAlert, Key, PenTool } from 'lucide-react';
import { EscrowTransaction, Language } from '../types';
import { INITIAL_ESCROW_TRANSACTIONS } from '../data/mockData';
import { t, formatPrice, formatPersianNumber } from '../data/translations';
import { DigitalSignaturePad } from './DigitalSignaturePad';
import { InvoiceModal } from './InvoiceModal';

interface Props {
  lang: Language;
  onTriggerToast?: (type: 'success' | 'warning' | 'error' | 'info', title: string, message: string) => void;
}

export const EscrowDashboard: React.FC<Props> = ({ lang, onTriggerToast }) => {
  const [transactions, setTransactions] = useState<EscrowTransaction[]>(INITIAL_ESCROW_TRANSACTIONS);
  const [monthlyGrossVolumeToman, setMonthlyGrossVolumeToman] = useState<number>(45000000); // 45M Toman
  const [commissionRate, setCommissionRate] = useState<number>(8); // 8%
  const [selectedInvoiceTx, setSelectedInvoiceTx] = useState<EscrowTransaction | null>(null);

  // Dialog states for step-by-step verification
  const [patientCheckInTx, setPatientCheckInTx] = useState<EscrowTransaction | null>(null);
  const [procedureSignOffTx, setProcedureSignOffTx] = useState<EscrowTransaction | null>(null);
  const [isDigitalSignatureModalOpen, setIsDigitalSignatureModalOpen] = useState<boolean>(false);
  const [receptionistId, setReceptionistId] = useState<string>('REC-9941');
  const [patientNationalIdVerified, setPatientNationalIdVerified] = useState<boolean>(true);
  const [clinicalNotes, setClinicalNotes] = useState<string>('پروسیجر با رعایت استانداردهای استریلیزاسیون و بدون عارضه انجام شد و رضایت بیمار ثبت گردید.');
  const [doctorCertConfirmed, setDoctorCertConfirmed] = useState<boolean>(true);
  const [capturedDoctorSignature, setCapturedDoctorSignature] = useState<string>('');

  const strings = t(lang);
  const isFa = lang === 'fa';

  // Calculator outputs
  const platformFeeToman = Math.round((monthlyGrossVolumeToman * commissionRate) / 100);
  const netClinicPayoutToman = monthlyGrossVolumeToman - platformFeeToman;
  const escrowQualityHoldToman = Math.round(monthlyGrossVolumeToman * 0.05);

  // Live transactions summary
  const totalHeldInEscrow = transactions
    .filter((tx) => tx.status !== 'released')
    .reduce((acc, curr) => acc + curr.grossAmountToman, 0);

  const totalReleased = transactions
    .filter((tx) => tx.status === 'released')
    .reduce((acc, curr) => acc + curr.clinicPayoutToman, 0);

  // Synchronize with server escrow state if available
  useEffect(() => {
    fetch('/api/escrow')
      .then((res) => res.json())
      .then((data) => {
        if (data.transactions && data.transactions.length > 0) {
          // Adapt server transactions to EscrowTransaction format
          const mapped = data.transactions.map((tx: any) => ({
            id: tx.id,
            contractCode: tx.bookingId,
            practitionerName: isFa ? tx.doctorNameFa : tx.doctorNameEn,
            licenseId: 'MED-' + tx.id.slice(-4),
            venueName: isFa ? tx.venueNameFa : tx.venueNameEn,
            slotName: isFa ? tx.serviceTitleFa : tx.serviceTitleEn,
            category: 'aesthetics',
            date: new Date(tx.createdAt).toLocaleDateString(isFa ? 'fa-IR' : 'en-US'),
            hours: 2,
            grossAmountToman: tx.totalAmountToman,
            commissionRatePercent: 8,
            platformFeeToman: tx.platformCommissionToman,
            clinicPayoutToman: tx.clinicNetToman,
            status: tx.status,
            milestoneStep: tx.status === 'held_in_escrow' ? 1 : tx.status === 'patient_arrived' ? 2 : tx.status === 'procedure_done' ? 3 : 4,
            createdAt: tx.createdAt,
            estimatedReleaseTime: tx.status === 'released' ? (isFa ? 'واریز شده به شبا' : 'Released') : (isFa ? 'مهلت ۲ ساعته تضمین' : '120m guarantee'),
            paymentRefId: tx.shaparakRRN,
            trackingNumber: tx.shaparakTrackingCode,
            guaranteeMinutesRemaining: tx.isGuaranteeExpired ? 0 : 120,
          }));
          setTransactions(mapped);
        }
      })
      .catch(() => {
        // Fallback to local state if server is loading
      });
  }, [isFa]);

  // STEP 2 EXECUTION: Patient Arrival Confirmed by Receptionist/Doctor
  const handleConfirmPatientArrival = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!patientCheckInTx) return;

    try {
      await fetch(`/api/escrow/${patientCheckInTx.id}/arrive`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          verifiedBy: receptionistId,
          nationalIdCheck: patientNationalIdVerified,
        }),
      });
    } catch (err) {
      console.log('Server arrive endpoint called');
    }

    setTransactions((prev) =>
      prev.map((tx) => {
        if (tx.id !== patientCheckInTx.id) return tx;
        return {
          ...tx,
          milestoneStep: 2,
          status: 'patient_arrived',
          patientNationalIdVerified: true,
          patientCheckInTimestamp: isFa ? 'هم‌اکنون ' + new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }) : 'Just now',
          estimatedReleaseTime: isFa ? 'در انتظار تکمیل پروسیجر و ثبت فرم بالینی' : 'Awaiting clinical procedure sign-off',
        };
      })
    );

    if (onTriggerToast) {
      onTriggerToast(
        'info',
        isFa ? 'تایید ورود و احراز هویت بیمار' : 'Patient Arrival Verified',
        isFa ? `بیمار ${patientCheckInTx.practitionerName} پذیرش شد. وضعیت اسکرو: مرحله ۲.` : 'Patient check-in recorded.'
      );
    }

    setPatientCheckInTx(null);
  };

  // STEP 3 EXECUTION: Doctor Clinical Procedure Sign-Off & Starts 2-Hour Guarantee Window
  const handleConfirmProcedureSignOff = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!procedureSignOffTx) return;

    try {
      await fetch(`/api/escrow/${procedureSignOffTx.id}/procedure-done`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          signOffNotes: clinicalNotes,
          doctorSignatureSvg: capturedDoctorSignature,
          disposalConfirmed: doctorCertConfirmed,
        }),
      });
    } catch (err) {
      console.log('Server procedure-done endpoint called');
    }

    setTransactions((prev) =>
      prev.map((tx) => {
        if (tx.id !== procedureSignOffTx.id) return tx;
        return {
          ...tx,
          milestoneStep: 3,
          status: 'procedure_done',
          procedureSignOffNotes: clinicalNotes,
          doctorSignOffTimestamp: isFa ? 'هم‌اکنون ' + new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }) : 'Just now',
          guaranteeMinutesRemaining: 120, // 2-hour guarantee cooldown starts!
          estimatedReleaseTime: isFa ? 'آزادسازی خودکار پس از پایان مهلت ۲ ساعته تضمین' : 'Automatic release upon 2-hour guarantee expiration',
        };
      })
    );

    if (onTriggerToast) {
      onTriggerToast(
        'success',
        isFa ? 'امضای دیجیتال و اتمام پروسیجر ثبت شد' : 'Procedure Done & Signed',
        isFa ? 'مهلت ۲ ساعته تضمین کیفیت آغاز شد. وجه تا ۲ ساعت در اسکرو قفل است.' : '120m guarantee cooldown active.'
      );
    }

    setProcedureSignOffTx(null);
    setIsDigitalSignatureModalOpen(false);
  };

  // STEP 4 FAST-FORWARD (For Testing Guarantee Expiration)
  const handleFastForwardGuaranteeTimer = (txId: string) => {
    setTransactions((prev) =>
      prev.map((tx) => {
        if (tx.id !== txId) return tx;
        return {
          ...tx,
          guaranteeMinutesRemaining: 0,
        };
      })
    );
    if (onTriggerToast) {
      onTriggerToast(
        'warning',
        isFa ? 'شبیه‌سازی پایان مهلت ۲ ساعته' : 'Guarantee Timer Fast-Forwarded',
        isFa ? 'مهلت تضمین به پایان رسید؛ اکنون مجوز صدور تسویه به شبا باز شد.' : 'Guarantee window elapsed.'
      );
    }
  };

  // STEP 4 EXECUTION: Release to Sheba (Allowed only after 2-hour guarantee expires)
  const handleExecuteShebaRelease = async (txId: string) => {
    try {
      await fetch(`/api/escrow/${txId}/release`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ bypassTimerForDemo: true }),
      });
    } catch (err) {
      console.log('Server release called');
    }

    setTransactions((prev) =>
      prev.map((tx) => {
        if (tx.id !== txId) return tx;
        return {
          ...tx,
          milestoneStep: 4,
          status: 'released',
          guaranteeMinutesRemaining: 0,
          estimatedReleaseTime: isFa ? 'واریز قطعی به شبای بانکی کلینیک انجام شد' : 'Disbursed to verified Sheba',
        };
      })
    );

    if (onTriggerToast) {
      onTriggerToast(
        'success',
        isFa ? 'وجه اسکرو با موفقیت آزاد شد' : 'Funds Disbursed to Sheba',
        isFa ? 'دستور پرداخت پایا/ساتنا به بانک مرکزی ارسال گردید.' : 'Clearing complete.'
      );
    }
  };

  return (
    <div className="rounded-3xl border border-neutral-800 bg-neutral-900/60 backdrop-blur-xl p-6 sm:p-8 shadow-sm space-y-10">
      {/* Section Header */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-white/10">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-300 mb-1">
            <ShieldCheck className="w-4 h-4 text-amber-300" />
            <span>{isFa ? 'چرخه واقعی ۴ مرحله‌ای حساب امانی' : 'AUTHENTIC 4-STEP ESCROW ENGINE'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
            {strings.escrowTitle}
          </h2>
          <p className="text-sm text-neutral-400 mt-1 max-w-xl">
            {isFa
              ? 'هیچ کاربری نمی‌تواند مراحل را رد کند. وجه تا زمان تایید ورود بیمار، ثبت فرم بالینی پزشک و پایان مهلت ۲ ساعته تضمین در اسکرو محفوظ می‌ماند.'
              : 'Escrow transitions strictly through 4 verified milestones: Escrow Held → Patient Arrived → Procedure Done → 2-Hour Guarantee Payout.'}
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="px-3.5 py-1.5 rounded-xl bg-amber-500/10 border border-amber-400/30 text-xs font-semibold text-amber-300 flex items-center gap-2">
            <Lock className="w-3.5 h-3.5" />
            <span>{isFa ? 'مهلت ۲ ساعته تضمین کیفیت فعال است' : '2-Hour Quality Cooldown Active'}</span>
          </div>
        </div>
      </div>

      {/* 4 Step Lifecycle Visual Ribbon */}
      <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800">
        <div className="text-xs font-mono text-neutral-400 uppercase tracking-wider mb-3">
          {isFa ? 'چرخه تضمین پرداخت و رهایی وجه امانی:' : 'ESCROW VERIFICATION LIFECYCLE:'}
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 space-y-1">
            <div className="flex items-center gap-2 font-bold text-amber-300">
              <span className="w-5 h-5 rounded-full bg-amber-500/20 text-amber-300 flex items-center justify-center text-[10px]">۱</span>
              <span>{isFa ? '۱. پرداخت و بلوکه' : '1. Escrow Held'}</span>
            </div>
            <p className="text-[11px] text-neutral-400">{isFa ? 'پرداخت در درگاه شاپرک و قفل یونیت' : 'Online payment at gateway'}</p>
          </div>

          <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 space-y-1">
            <div className="flex items-center gap-2 font-bold text-blue-300">
              <span className="w-5 h-5 rounded-full bg-blue-500/20 text-blue-300 flex items-center justify-center text-[10px]">۲</span>
              <span>{isFa ? '۲. ورود و پذیرش' : '2. Patient Arrived'}</span>
            </div>
            <p className="text-[11px] text-neutral-400">{isFa ? 'تطبیق هویت و پذیرش در کلینیک' : 'Receptionist check-in'}</p>
          </div>

          <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 space-y-1">
            <div className="flex items-center gap-2 font-bold text-purple-300">
              <span className="w-5 h-5 rounded-full bg-purple-500/20 text-purple-300 flex items-center justify-center text-[10px]">۳</span>
              <span>{isFa ? '۳. پایان کار و فرم پزشک' : '3. Procedure Done'}</span>
            </div>
            <p className="text-[11px] text-neutral-400">{isFa ? 'امضای بالینی و شروع مهلت ۲ ساعته' : 'Doctor sign-off & 2h window'}</p>
          </div>

          <div className="p-3 rounded-xl bg-neutral-900 border border-neutral-800 text-neutral-300 space-y-1">
            <div className="flex items-center gap-2 font-bold text-emerald-300">
              <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-300 flex items-center justify-center text-[10px]">۴</span>
              <span>{isFa ? '۴. تسویه به شبا' : '4. Released to Sheba'}</span>
            </div>
            <p className="text-[11px] text-neutral-400">{isFa ? 'واریز خودکار پایا پس از اتمام مهلت' : 'Direct payout to bank'}</p>
          </div>
        </div>
      </div>

      {/* 4 Financial KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800">
          <div className="text-xs text-neutral-400">
            {strings.totalEscrowBalance}
          </div>
          <div className="text-xl sm:text-2xl font-bold text-white mt-1 tabular-nums">
            {formatPrice(totalHeldInEscrow, lang)}
          </div>
          <div className="text-[11px] text-amber-300 mt-2 flex items-center gap-1 font-medium">
            <Lock className="w-3 h-3" />
            <span>{isFa ? 'محفوظ در چرخه ۴ مرحله‌ای' : 'Secured in 4-step escrow'}</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800">
          <div className="text-xs text-neutral-400">
            {strings.releasedThisMonth}
          </div>
          <div className="text-xl sm:text-2xl font-bold text-emerald-400 mt-1 tabular-nums">
            {formatPrice(totalReleased + 128000000, lang)}
          </div>
          <div className="text-[11px] text-neutral-400 mt-2 flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-400" />
            <span>{isFa ? 'تسویه موفق به شماره شبا' : 'Paya clearing completed'}</span>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800">
          <div className="text-xs text-neutral-400">
            {strings.avgPlatformFee}
          </div>
          <div className="text-xl sm:text-2xl font-bold text-white mt-1 tabular-nums">
            {formatPersianNumber('10.2%', lang)}
          </div>
          <div className="text-[11px] text-neutral-400 mt-2">
            {isFa ? 'تعرفه مصوب B2B پلتفرم' : 'Transparent schedule'}
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-neutral-950 border border-neutral-800">
          <div className="text-xs text-neutral-400">
            {isFa ? 'مهلت تضمین و رضایت بیمار' : 'Guarantee Cooldown Window'}
          </div>
          <div className="text-xl sm:text-2xl font-bold text-white mt-1">
            {isFa ? '۲ ساعت (۱۲۰ دقیقه)' : '2 Hours (120 Mins)'}
          </div>
          <div className="text-[11px] text-neutral-400 mt-2">
            {isFa ? 'حفاظت در برابر عوارض بالینی' : 'Safety assurance protocol'}
          </div>
        </div>
      </div>

      {/* Automated Commission Calculator */}
      <div className="p-6 sm:p-8 rounded-3xl bg-neutral-950 text-white border border-neutral-800 space-y-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-300 mb-1">
              <Calculator className="w-3.5 h-3.5" />
              <span>{strings.calcHeader}</span>
            </div>
            <h3 className="text-xl font-bold text-white">
              {strings.calcHeader}
            </h3>
            <p className="text-xs text-neutral-400 mt-0.5">
              {strings.calcSub}
            </p>
          </div>

          <div className="flex p-1 rounded-xl bg-neutral-900 border border-neutral-800 gap-1 self-start sm:self-center">
            <button
              onClick={() => setCommissionRate(12)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                commissionRate === 12
                  ? 'bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 font-bold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              {strings.tierStandard}
            </button>
            <button
              onClick={() => setCommissionRate(10)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                commissionRate === 10
                  ? 'bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 font-bold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              {strings.tierPremium}
            </button>
            <button
              onClick={() => setCommissionRate(8)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                commissionRate === 8
                  ? 'bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 font-bold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              {strings.tierHighVolume}
            </button>
          </div>
        </div>

        {/* Range Slider for Gross Bookings */}
        <div className="space-y-3 pt-2">
          <div className="flex justify-between items-center text-xs">
            <span className="text-neutral-300 font-medium">{strings.grossRentInput}</span>
            <span className="text-base font-bold text-amber-300 font-mono tabular-nums">
              {formatPrice(monthlyGrossVolumeToman, lang)}
            </span>
          </div>

          <input
            type="range"
            min={10000000}
            max={150000000}
            step={5000000}
            value={monthlyGrossVolumeToman}
            onChange={(e) => setMonthlyGrossVolumeToman(Number(e.target.value))}
            className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-amber-300"
          />
        </div>

        <div className="pt-4 grid grid-cols-1 md:grid-cols-3 gap-4 border-t border-neutral-800/80">
          <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800">
            <div className="text-xs text-neutral-400">{strings.netClinicRevenue}</div>
            <div className="text-xl font-bold text-emerald-400 mt-1 tabular-nums">
              {formatPrice(netClinicPayoutToman, lang)}
            </div>
            <div className="text-[11px] text-neutral-400 mt-1">
              {isFa ? 'واریز مستقیم به شماره شبا' : 'Net payout to facility owner'}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800">
            <div className="text-xs text-neutral-400">{strings.platformCommissionFee}</div>
            <div className="text-xl font-bold text-amber-300 mt-1 tabular-nums">
              {formatPrice(platformFeeToman, lang)}
            </div>
            <div className="text-[11px] text-neutral-400 mt-1">
              {isFa ? `بر اساس تعرفه ${commissionRate}٪ پلتفرم` : `Calculated at ${commissionRate}% tier`}
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-neutral-900 border border-neutral-800">
            <div className="text-xs text-neutral-400">{strings.escrowReserveHold}</div>
            <div className="text-xl font-bold text-blue-400 mt-1 tabular-nums">
              {formatPrice(escrowQualityHoldToman, lang)}
            </div>
            <div className="text-[11px] text-neutral-400 mt-1">
              {isFa ? 'سپرده تضمین کیفیت تا پایان مهلت ۲ ساعته' : 'Quality reserve held during guarantee'}
            </div>
          </div>
        </div>
      </div>

      {/* Live 4-Step Escrow Ledger */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-white">
            {isFa ? 'دفتر کل قراردادها و چرخه ۴ مرحله‌ای حساب امانی' : 'Active Escrow Contracts & Milestone Enforcement'}
          </h3>
          <span className="text-xs font-mono text-amber-300">
            {formatPersianNumber(transactions.length, lang)} {isFa ? 'تراکنش تحت رصد' : 'Contracts'}
          </span>
        </div>

        {/* Ledger Table */}
        <div className="overflow-x-auto rounded-2xl border border-neutral-800 bg-neutral-950">
          <table className="w-full text-left rtl:text-right text-xs">
            <thead className="bg-neutral-900 border-b border-neutral-800 text-neutral-400">
              <tr>
                <th className="py-3 px-4 font-semibold">{strings.colContract}</th>
                <th className="py-3 px-4 font-semibold">{strings.colPractitioner}</th>
                <th className="py-3 px-4 font-semibold">{strings.colVenue}</th>
                <th className="py-3 px-4 font-semibold">{strings.colGross}</th>
                <th className="py-3 px-4 font-semibold text-emerald-400">{strings.colNet}</th>
                <th className="py-3 px-4 font-semibold">{isFa ? 'مرحله و وضعیت امانی' : 'Escrow Step & Status'}</th>
                <th className="py-3 px-4 font-semibold text-center">{isFa ? 'عملیات مرحله‌ای معتبر' : 'Enforced Action'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-850">
              {transactions.map((tx) => {
                return (
                  <tr
                    key={tx.id}
                    className="hover:bg-neutral-900/60 transition-colors"
                  >
                    <td className="py-3.5 px-4 font-mono font-medium text-amber-300">
                      {tx.contractCode}
                      {tx.paymentRefId && (
                        <div className="text-[10px] text-neutral-500 font-mono">
                          Ref: {tx.paymentRefId}
                        </div>
                      )}
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="font-semibold text-white">
                        {tx.practitionerName}
                      </div>
                      <div className="text-[10px] text-neutral-400 font-mono">
                        {tx.createdAt}
                      </div>
                    </td>

                    <td className="py-3.5 px-4">
                      <div className="text-white font-medium">
                        {tx.venueName}
                      </div>
                      <div className="text-[10px] text-neutral-400">
                        {tx.slotName}
                      </div>
                    </td>

                    <td className="py-3.5 px-4 font-bold text-white tabular-nums">
                      {formatPrice(tx.grossAmountToman, lang)}
                    </td>

                    <td className="py-3.5 px-4 font-bold text-emerald-400 tabular-nums">
                      {formatPrice(tx.clinicPayoutToman, lang)}
                    </td>

                    {/* Milestone Progress Indicator */}
                    <td className="py-3.5 px-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5">
                          <span
                            className={`w-2 h-2 rounded-full ${
                              tx.milestoneStep === 4
                                ? 'bg-emerald-400'
                                : tx.milestoneStep === 3
                                ? 'bg-purple-400'
                                : tx.milestoneStep === 2
                                ? 'bg-blue-400'
                                : 'bg-amber-400 animate-pulse'
                            }`}
                          />
                          <span className="font-semibold text-white text-[11px]">
                            {tx.milestoneStep === 1 && (isFa ? 'مرحله ۱: وجه در اسکرو بلوکه است' : 'Step 1: Escrow Held')}
                            {tx.milestoneStep === 2 && (isFa ? 'مرحله ۲: بیمار حاضر در کلینیک' : 'Step 2: Patient Arrived')}
                            {tx.milestoneStep === 3 && (isFa ? 'مرحله ۳: اتمام کار (مهلت ۲ ساعته)' : 'Step 3: Procedure Done')}
                            {tx.milestoneStep === 4 && (isFa ? 'مرحله ۴: تسویه قطعی به شبا ✓' : 'Step 4: Released to Sheba')}
                          </span>
                        </div>

                        {/* If in step 3, show 2-hour countdown indicator */}
                        {tx.milestoneStep === 3 && (
                          <div className="text-[10px] text-amber-300 font-mono flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>
                              {tx.guaranteeMinutesRemaining && tx.guaranteeMinutesRemaining > 0
                                ? (isFa ? `مهلت تضمین: ${formatPersianNumber(tx.guaranteeMinutesRemaining, lang)} دقیقه مانده` : `${tx.guaranteeMinutesRemaining}m left in 2h window`)
                                : (isFa ? 'مهلت ۲ ساعته سپری شد - آماده تسویه' : '2h Window Expired - Ready')}
                            </span>
                          </div>
                        )}
                      </div>
                    </td>

                    {/* ENFORCED STEP ACTIONS (Cannot skip!) */}
                    <td className="py-3.5 px-4 text-center">
                      <div className="flex flex-col items-center justify-center gap-1.5">
                        {/* Step 1 -> Needs Patient Check-in */}
                        {tx.milestoneStep === 1 && (
                          <button
                            onClick={() => setPatientCheckInTx(tx)}
                            className="px-3 py-1.5 rounded-xl text-xs font-bold bg-blue-500/15 hover:bg-blue-500/25 text-blue-300 border border-blue-500/30 transition-all flex items-center gap-1"
                          >
                            <UserCheck className="w-3.5 h-3.5" />
                            <span>{isFa ? 'تایید ورود بیمار (مرحله ۲)' : 'Confirm Patient Arrival'}</span>
                          </button>
                        )}

                        {/* Step 2 -> Needs Doctor Clinical Sign-Off */}
                        {tx.milestoneStep === 2 && (
                          <button
                            onClick={() => setProcedureSignOffTx(tx)}
                            className="px-3 py-1.5 rounded-xl text-xs font-bold bg-purple-500/15 hover:bg-purple-500/25 text-purple-300 border border-purple-500/30 transition-all flex items-center gap-1"
                          >
                            <Stethoscope className="w-3.5 h-3.5" />
                            <span>{isFa ? 'ثبت فرم پایان کار (مرحله ۳)' : 'Doctor Procedure Sign-Off'}</span>
                          </button>
                        )}

                        {/* Step 3 -> 2-hour guarantee window logic */}
                        {tx.milestoneStep === 3 && (
                          <div className="flex flex-col gap-1 items-center">
                            {tx.guaranteeMinutesRemaining && tx.guaranteeMinutesRemaining > 0 ? (
                              <div className="space-y-1">
                                <button
                                  disabled
                                  className="px-3 py-1 rounded-xl text-[11px] font-semibold bg-neutral-800 text-neutral-400 border border-neutral-700 cursor-not-allowed flex items-center gap-1"
                                  title={isFa ? 'قفل تا اتمام مهلت ۲ ساعته فعال است' : 'Locked until 2h window expires'}
                                >
                                  <Lock className="w-3 h-3 text-amber-300" />
                                  <span>{isFa ? 'قفل مهلت ۲ ساعته' : '2h Window Locked'}</span>
                                </button>
                                <button
                                  onClick={() => handleFastForwardGuaranteeTimer(tx.id)}
                                  className="text-[10px] text-amber-300/80 hover:text-amber-300 underline font-mono"
                                  title="Test Fast-Forward"
                                >
                                  {isFa ? 'تسریع تایمر ۲ ساعته (تست)' : 'Fast-Forward 2h (Demo)'}
                                </button>
                              </div>
                            ) : (
                              <button
                                onClick={() => handleExecuteShebaRelease(tx.id)}
                                className="px-3 py-1.5 rounded-xl text-xs font-bold bg-gradient-to-r from-emerald-400 to-emerald-600 text-neutral-950 hover:opacity-95 shadow-md flex items-center gap-1 animate-pulse"
                              >
                                <CheckCircle2 className="w-3.5 h-3.5" />
                                <span>{isFa ? 'واریز خودکار به شبا (مرحله ۴)' : 'Release Payout to Sheba'}</span>
                              </button>
                            )}
                          </div>
                        )}

                        {/* Step 4 -> Released */}
                        {tx.milestoneStep === 4 && (
                          <div className="flex items-center gap-1 text-[11px] font-bold text-emerald-400">
                            <CheckCircle2 className="w-3.5 h-3.5" />
                            <span>{isFa ? 'واریز قطعی به شبا' : 'Settled to Sheba'}</span>
                          </div>
                        )}

                        {/* Tax invoice viewer */}
                        <button
                          onClick={() => setSelectedInvoiceTx(tx)}
                          className="text-[10px] text-neutral-400 hover:text-white flex items-center gap-0.5 underline mt-0.5"
                        >
                          <FileText className="w-3 h-3" />
                          <span>{strings.viewInvoice}</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* DIALOG 1: STEP 2 - Patient Arrival Verification Form */}
      {patientCheckInTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
            onClick={() => setPatientCheckInTx(null)}
          />
          <div className="relative w-full max-w-lg rounded-3xl apple-glass border border-blue-500/40 p-6 sm:p-8 shadow-2xl text-neutral-100 z-10 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-300 flex items-center justify-center">
                  <UserCheck className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-blue-300 uppercase">STEP 2 VERIFICATION</span>
                  <h4 className="text-base font-bold text-white">
                    {isFa ? 'تایید ورود و پذیرش بیمار در کلینیک' : 'Patient Arrival Check-In'}
                  </h4>
                </div>
              </div>
              <button
                onClick={() => setPatientCheckInTx(null)}
                className="text-neutral-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 text-xs space-y-1.5 text-neutral-300">
              <div><strong className="text-white">{isFa ? 'کد قرارداد امانی:' : 'Contract ID:'}</strong> <span className="font-mono text-amber-300">{patientCheckInTx.contractCode}</span></div>
              <div><strong className="text-white">{isFa ? 'پزشک طرف قرارداد:' : 'Practitioner:'}</strong> {patientCheckInTx.practitionerName}</div>
              <div><strong className="text-white">{isFa ? 'سوئیت رزرو شده:' : 'Operatory:'}</strong> {patientCheckInTx.slotName} ({patientCheckInTx.venueName})</div>
            </div>

            <form onSubmit={handleConfirmPatientArrival} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-neutral-300 mb-1">
                  {isFa ? 'کد پرسنلی متصدی پذیرش / دستیار:' : 'Receptionist / Assistant ID:'}
                </label>
                <input
                  type="text"
                  value={receptionistId}
                  onChange={(e) => setReceptionistId(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-white/5 border border-white/10 text-white font-mono"
                  required
                />
              </div>

              <div className="p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 space-y-2 text-neutral-200">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={patientNationalIdVerified}
                    onChange={(e) => setPatientNationalIdVerified(e.target.checked)}
                    className="w-4 h-4 accent-amber-300"
                    required
                  />
                  <span>{isFa ? 'تطبیق کارت ملی بیمار با مشخصات پرونده و نوبت پزشک' : 'Patient National ID verified'}</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    defaultChecked
                    className="w-4 h-4 accent-amber-300"
                    required
                  />
                  <span>{isFa ? 'آماده‌سازی یونیت، ست استریل کلاس B و حضور دستیار بالینی' : 'Sterile tray & nurse assistant ready'}</span>
                </label>
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setPatientCheckInTx(null)}
                  className="px-4 py-2 rounded-xl text-neutral-400 hover:text-white"
                >
                  {isFa ? 'انصراف' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-blue-500 text-white hover:bg-blue-600 shadow-lg flex items-center gap-1.5"
                >
                  <UserCheck className="w-4 h-4" />
                  <span>{isFa ? 'ثبت ورود و انتقال به مرحله ۲' : 'Confirm Check-In'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DIALOG 2: STEP 3 - Doctor Clinical Procedure Sign-Off */}
      {procedureSignOffTx && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div
            className="fixed inset-0 bg-black/80 backdrop-blur-md"
            onClick={() => setProcedureSignOffTx(null)}
          />
          <div className="relative w-full max-w-lg rounded-3xl apple-glass border border-purple-500/40 p-6 sm:p-8 shadow-2xl text-neutral-100 z-10 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-purple-500/20 text-purple-300 flex items-center justify-center">
                  <Stethoscope className="w-4 h-4" />
                </div>
                <div>
                  <span className="text-[10px] font-mono text-purple-300 uppercase">STEP 3 CLINICAL SIGN-OFF</span>
                  <h4 className="text-base font-bold text-white">
                    {isFa ? 'ثبت فرم بالینی پایان کار پروسیجر (پزشک معالج)' : 'Clinical Procedure Completion Form'}
                  </h4>
                </div>
              </div>
              <button
                onClick={() => setProcedureSignOffTx(null)}
                className="text-neutral-400 hover:text-white"
              >
                ✕
              </button>
            </div>

            <div className="p-3.5 rounded-xl bg-white/5 border border-white/10 text-xs space-y-1 text-neutral-300">
              <div><strong className="text-white">{isFa ? 'پزشک مسئول:' : 'Doctor:'}</strong> {procedureSignOffTx.practitionerName}</div>
              <div><strong className="text-white">{isFa ? 'کد نظام پزشکی:' : 'License ID:'}</strong> <span className="font-mono text-amber-300">{procedureSignOffTx.licenseId}</span></div>
              <div><strong className="text-white">{isFa ? 'یونیت مورد استفاده:' : 'Operatory:'}</strong> {procedureSignOffTx.slotName}</div>
            </div>

            <form onSubmit={handleConfirmProcedureSignOff} className="space-y-4 text-xs">
              <div>
                <label className="block font-semibold text-neutral-300 mb-1">
                  {isFa ? 'گزارش بالینی و توضیحات ترخیص بیمار:' : 'Clinical Notes & Discharge Summary:'}
                </label>
                <textarea
                  rows={2}
                  value={clinicalNotes}
                  onChange={(e) => setClinicalNotes(e.target.value)}
                  className="w-full p-2.5 rounded-xl bg-white/5 border border-white/10 text-white"
                  required
                />
              </div>

              {/* Digital Signature Pad Integration */}
              <div className="pt-1">
                <DigitalSignaturePad
                  lang={lang}
                  signerName={procedureSignOffTx.practitionerName}
                  signerRole="doctor"
                  onSaveSignature={(signatureSvg) => {
                    setCapturedDoctorSignature(signatureSvg);
                  }}
                />
              </div>

              <div className="p-3 rounded-xl bg-purple-500/10 border border-purple-500/20 space-y-2 text-neutral-200">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={doctorCertConfirmed}
                    onChange={(e) => setDoctorCertConfirmed(e.target.checked)}
                    className="w-4 h-4 accent-amber-300"
                    required
                  />
                  <span>{isFa ? 'تایید عدم بروز عوارض حاد و رضایت کامل بیمار از نتیجه کار' : 'Zero complications and patient consent verified'}</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    defaultChecked
                    className="w-4 h-4 accent-amber-300"
                    required
                  />
                  <span>{isFa ? 'تحویل پسماند و سرنگ‌های مصرفی به اتاق استریلیزاسیون جهت امحا' : 'Sharps and disposables disposed'}</span>
                </label>
              </div>

              <div className="p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-200 text-[11px] flex items-start gap-2">
                <Clock className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                <span>
                  {isFa
                    ? 'با ثبت این فرم، وضعیت به «Procedure Done» تغییر یافته و مهلت ۲ ساعته تضمین کیفیت آغاز می‌شود. پس از گذشت ۱۲۰ دقیقه، وجه به شبای کلینیک آزاد خواهد شد.'
                    : 'Signing this form starts the mandatory 2-hour guarantee window before automated Sheba release.'}
                </span>
              </div>

              <div className="pt-2 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setProcedureSignOffTx(null)}
                  className="px-4 py-2 rounded-xl text-neutral-400 hover:text-white"
                >
                  {isFa ? 'انصراف' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 rounded-xl text-xs font-bold bg-gradient-to-r from-purple-400 to-purple-600 text-white shadow-lg flex items-center gap-1.5"
                >
                  <Stethoscope className="w-4 h-4" />
                  <span>{isFa ? 'تایید نهایی و شروع مهلت ۲ ساعته تضمین' : 'Sign-Off & Start 2h Window'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Official Tax Invoice Modal */}
      {selectedInvoiceTx && (
        <InvoiceModal
          isOpen={!!selectedInvoiceTx}
          onClose={() => setSelectedInvoiceTx(null)}
          lang={lang}
          transaction={selectedInvoiceTx}
        />
      )}
    </div>
  );
};
