import React, { useState } from 'react';
import { 
  Building2, 
  LogOut, 
  DollarSign, 
  CheckCircle2, 
  Clock, 
  User, 
  Stethoscope, 
  Sparkles, 
  TrendingUp, 
  Calendar, 
  ArrowRight, 
  ArrowLeft, 
  Check, 
  X,
  Copy, 
  SlidersHorizontal, 
  Activity, 
  Phone,
  Hourglass,
  CalendarCheck,
  AlertCircle
} from 'lucide-react';
import { Venue, RealtimeSlot, Language, SlotStatus, BookingRequest } from '../types';
import { VENUES } from '../data/mockData';
import { t, formatPrice, formatPersianNumber } from '../data/translations';

interface Props {
  lang: Language;
  managedVenue: Venue;
  onSwitchVenue: (venue: Venue) => void;
  onExitPortal: () => void;
  slots: RealtimeSlot[];
  onToggleSlotStatus: (slotId: string, nextStatus: SlotStatus) => void;
  onBookSlot: (slot: RealtimeSlot) => void;
  onTriggerToast?: (type: 'success' | 'warning' | 'error' | 'info', title: string, message: string) => void;
  bookingRequests: BookingRequest[];
  onUpdateBookingRequestStatus: (requestId: string, status: 'confirmed' | 'rejected') => void;
}

export const ClinicAdminPortal: React.FC<Props> = ({
  lang,
  managedVenue,
  onSwitchVenue,
  onExitPortal,
  slots,
  onToggleSlotStatus,
  onBookSlot,
  onTriggerToast,
  bookingRequests,
  onUpdateBookingRequestStatus,
}) => {
  const strings = t(lang);
  const isFa = lang === 'fa';
  const [copiedCode, setCopiedCode] = useState<string | null>(null);
  const [slotFilter, setSlotFilter] = useState<'all' | 'available' | 'reserved' | 'in_procedure'>('all');

  // Filter slots belonging to this managed venue
  const venueSlots = slots.filter((s) => s.venueId === managedVenue.id);
  const availableCount = venueSlots.filter((s) => s.status === 'available').length;
  const reservedCount = venueSlots.filter((s) => s.status === 'reserved').length;
  const inProcedureCount = venueSlots.filter((s) => s.status === 'in_procedure').length;

  const filteredVenueSlots = venueSlots.filter((s) => {
    if (slotFilter === 'all') return true;
    return s.status === slotFilter;
  });

  // Filter booking requests for this venue (or allow all if demo)
  const venueRequests = bookingRequests.filter(
    (r) => r.venueId === managedVenue.id || r.venueNameFa.includes(managedVenue.nameFa.slice(0, 10))
  );

  const pendingRequests = venueRequests.filter((r) => r.status === 'pending_confirmation');
  const confirmedRequests = venueRequests.filter((r) => r.status === 'confirmed');

  // Simulated revenue statistics for this venue
  const baseRevenue = managedVenue.baseHourlyToman * 5;
  const todayRevenueToman = baseRevenue;
  const monthlyRevenueToman = baseRevenue * 8.5;
  const occupancyRate = venueSlots.length > 0 
    ? Math.round(((reservedCount + inProcedureCount) / venueSlots.length) * 100) 
    : 65;

  const handleCopyCode = (code: string) => {
    navigator.clipboard?.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2000);
  };

  const handleDirectStatusChange = (slotId: string, status: SlotStatus) => {
    onToggleSlotStatus(slotId, status);
    if (onTriggerToast) {
      const statusLabel = 
        status === 'available' ? (isFa ? 'خالی و آماده پذیرش' : 'Available') :
        status === 'reserved' ? (isFa ? 'رزرو شده' : 'Reserved') :
        status === 'in_procedure' ? (isFa ? 'در حال انجام پروسیجر' : 'In Procedure') :
        status;

      onTriggerToast(
        'success',
        isFa ? 'تغییر وضعیت صندلی' : 'Unit Status Updated',
        isFa ? `وضعیت به «${statusLabel}» تغییر یافت.` : `Status altered to ${statusLabel}.`
      );
    }
  };

  const handleApprove = (request: BookingRequest) => {
    onUpdateBookingRequestStatus(request.id, 'confirmed');

    // Automatically reserve corresponding slot if specified
    if (request.slotId) {
      onToggleSlotStatus(request.slotId, 'reserved');
    }

    if (onTriggerToast) {
      onTriggerToast(
        'success',
        isFa ? 'نوبت با موفقیت تأیید شد' : 'Appointment Confirmed',
        isFa
          ? `درخواست ${request.fullName} تأیید و صندلی در وضعیت «رزرو شده» قرار گرفت.`
          : `Request for ${request.fullName} approved and slot locked.`
      );
    }
  };

  const handleReject = (request: BookingRequest) => {
    onUpdateBookingRequestStatus(request.id, 'rejected');
    if (onTriggerToast) {
      onTriggerToast(
        'warning',
        isFa ? 'درخواست نوبت رد شد' : 'Appointment Rejected',
        isFa ? `درخواست ${request.fullName} رد شد.` : `Request for ${request.fullName} rejected.`
      );
    }
  };

  return (
    <div className="min-h-screen bg-[#090A0D] text-neutral-100 py-6 sm:py-8 px-4 sm:px-6 lg:px-8 space-y-8 animate-fadeIn">
      
      {/* 1. Executive Header Bar */}
      <header className="max-w-7xl mx-auto rounded-3xl bg-[#11131A] border border-[#E5C378]/25 p-5 sm:p-7 shadow-2xl flex flex-col md:flex-row items-start md:items-center justify-between gap-5 backdrop-blur-xl">
        <div className="flex items-center gap-4">
          <div className="w-13 h-13 rounded-2xl bg-gradient-to-tr from-[#E5C378] via-[#F3E5AB] to-[#C5A059] text-neutral-950 flex items-center justify-center font-bold text-xl shadow-lg shadow-[#E5C378]/15 shrink-0">
            <Building2 className="w-7 h-7 text-neutral-950" />
          </div>

          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-[#E5C378] mb-1">
              <span className="w-2 h-2 rounded-full bg-[#E5C378] animate-pulse" />
              <span className="font-bold tracking-wider uppercase">
                {isFa ? 'پنل مدیریت اختصاصی کلینیک' : 'EXECUTIVE CLINIC PORTAL'}
              </span>
              <span className="text-neutral-600">·</span>
              <span className="text-neutral-400 font-mono">{managedVenue.medicalLicenseNumber}</span>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <h1 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                {isFa ? managedVenue.nameFa : managedVenue.nameEn}
              </h1>

              {/* Facility Selector */}
              <select
                value={managedVenue.id}
                onChange={(e) => {
                  const found = VENUES.find((v) => v.id === e.target.value);
                  if (found) onSwitchVenue(found);
                }}
                className="text-xs bg-[#1A1D26] hover:bg-[#222634] border border-[#E5C378]/30 text-[#E5C378] rounded-xl px-3 py-1.5 focus:outline-none cursor-pointer transition-colors"
                title={isFa ? 'تعویض کلینیک تحت مدیریت' : 'Switch Facility'}
              >
                {VENUES.map((v) => (
                  <option key={v.id} value={v.id} className="bg-neutral-900 text-white">
                    {isFa ? v.nameFa : v.nameEn}
                  </option>
                ))}
              </select>
            </div>

            <div className="text-xs text-neutral-400 mt-1 flex items-center gap-2">
              <span>{isFa ? 'مسئول فنی:' : 'Medical Director:'}</span>
              <span className="text-neutral-200 font-medium">
                {isFa ? managedVenue.medicalDirectorFa : managedVenue.medicalDirectorEn}
              </span>
            </div>
          </div>
        </div>

        {/* Exit Button */}
        <button
          onClick={onExitPortal}
          className="px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-semibold bg-white/5 hover:bg-white/10 text-neutral-200 hover:text-white border border-white/10 transition-colors flex items-center gap-2 self-stretch md:self-auto justify-center cursor-pointer"
        >
          <LogOut className="w-4 h-4 text-[#E5C378]" />
          <span>{strings.switchToPublicView}</span>
        </button>
      </header>

      {/* 2. SECTION 1: مدیریت صندلی‌ها و تخت‌ها (تغییر وضعیت خالی / رزرو شده / در حال انجام) */}
      <section className="max-w-7xl mx-auto space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#E5C378]/15 border border-[#E5C378]/30 text-[#E5C378] flex items-center justify-center">
              <SlidersHorizontal className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">
                {isFa ? 'مدیریت صندلی‌ها و تخت‌ها' : 'Chairs & Beds Management'}
              </h2>
              <p className="text-xs text-neutral-400">
                {isFa 
                  ? 'تغییر آنی وضعیت صندلی‌ها و تخت‌ها: خالی / رزرو شده / در حال انجام' 
                  : 'Toggle real-time status: Available / Reserved / In Procedure'}
              </p>
            </div>
          </div>

          {/* Filter Pills */}
          <div className="inline-flex p-1 rounded-2xl bg-[#11131A] border border-[#222634] text-xs self-start sm:self-auto">
            <button
              onClick={() => setSlotFilter('all')}
              className={`px-3 py-1.5 rounded-xl font-medium transition-colors ${
                slotFilter === 'all' ? 'bg-[#E5C378] text-neutral-950 font-bold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              {isFa ? 'همه' : 'All'} ({formatPersianNumber(venueSlots.length, lang)})
            </button>
            <button
              onClick={() => setSlotFilter('available')}
              className={`px-3 py-1.5 rounded-xl font-medium transition-colors ${
                slotFilter === 'available' ? 'bg-[#E5C378] text-neutral-950 font-bold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              {isFa ? 'خالی' : 'Available'} ({formatPersianNumber(availableCount, lang)})
            </button>
            <button
              onClick={() => setSlotFilter('reserved')}
              className={`px-3 py-1.5 rounded-xl font-medium transition-colors ${
                slotFilter === 'reserved' ? 'bg-[#E5C378] text-neutral-950 font-bold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              {isFa ? 'رزرو شده' : 'Reserved'} ({formatPersianNumber(reservedCount, lang)})
            </button>
            <button
              onClick={() => setSlotFilter('in_procedure')}
              className={`px-3 py-1.5 rounded-xl font-medium transition-colors ${
                slotFilter === 'in_procedure' ? 'bg-[#E5C378] text-neutral-950 font-bold' : 'text-neutral-400 hover:text-white'
              }`}
            >
              {isFa ? 'در حال انجام' : 'In Action'} ({formatPersianNumber(inProcedureCount, lang)})
            </button>
          </div>
        </div>

        {/* Chairs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredVenueSlots.map((slot) => {
            const isAvail = slot.status === 'available';
            const isRes = slot.status === 'reserved';
            const isInProc = slot.status === 'in_procedure';

            return (
              <div 
                key={slot.id}
                className="p-5 rounded-3xl bg-[#11131A] border border-[#222634] hover:border-[#E5C378]/40 transition-all shadow-xl flex flex-col justify-between gap-4 group"
              >
                <div>
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <span className="text-[11px] font-mono text-neutral-400 bg-white/5 px-2.5 py-0.5 rounded-lg border border-white/5">
                      {isFa ? slot.roomNameFa : slot.roomNameEn}
                    </span>

                    {/* Badge */}
                    <div className="flex items-center gap-1.5">
                      {isAvail && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-400 bg-emerald-500/15 border border-emerald-500/30 px-2.5 py-0.5 rounded-full">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                          <span>{isFa ? 'خالی' : 'Available'}</span>
                        </span>
                      )}
                      {isRes && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-[#E5C378] bg-[#E5C378]/15 border border-[#E5C378]/30 px-2.5 py-0.5 rounded-full">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#E5C378]" />
                          <span>{isFa ? 'رزرو شده' : 'Reserved'}</span>
                        </span>
                      )}
                      {isInProc && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-bold text-sky-300 bg-sky-500/15 border border-sky-500/30 px-2.5 py-0.5 rounded-full">
                          <span className="w-1.5 h-1.5 rounded-full bg-sky-300 animate-pulse" />
                          <span>{isFa ? 'در حال انجام' : 'In Action'}</span>
                        </span>
                      )}
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-white group-hover:text-[#E5C378] transition-colors">
                    {isFa ? slot.roomNameFa : slot.roomNameEn}
                  </h3>

                  {/* Equipment */}
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {slot.equipment.slice(0, 3).map((eq, idx) => (
                      <span key={idx} className="text-[10px] text-neutral-300 bg-white/5 px-2 py-0.5 rounded-md border border-white/5">
                        {eq}
                      </span>
                    ))}
                  </div>
                </div>

                {/* 3-way toggle buttons: خالی / رزرو شده / در حال انجام */}
                <div className="pt-3 border-t border-white/5 space-y-1.5">
                  <div className="text-[10px] text-neutral-400 font-semibold mb-1">
                    {isFa ? 'تغییر مستقیم وضعیت:' : 'Change Status:'}
                  </div>

                  <div className="grid grid-cols-3 gap-1.5">
                    <button
                      type="button"
                      onClick={() => handleDirectStatusChange(slot.id, 'available')}
                      className={`py-2 px-1 text-center rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        isAvail 
                          ? 'bg-emerald-500/25 text-emerald-300 border border-emerald-500/50 shadow-sm shadow-emerald-500/20' 
                          : 'bg-white/5 hover:bg-emerald-500/10 text-neutral-400 hover:text-emerald-300 border border-transparent'
                      }`}
                    >
                      {isFa ? 'خالی' : 'Available'}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDirectStatusChange(slot.id, 'reserved')}
                      className={`py-2 px-1 text-center rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        isRes 
                          ? 'bg-[#E5C378]/25 text-[#E5C378] border border-[#E5C378]/50 shadow-sm shadow-amber-500/20' 
                          : 'bg-white/5 hover:bg-[#E5C378]/10 text-neutral-400 hover:text-[#E5C378] border border-transparent'
                      }`}
                    >
                      {isFa ? 'رزرو شده' : 'Reserved'}
                    </button>

                    <button
                      type="button"
                      onClick={() => handleDirectStatusChange(slot.id, 'in_procedure')}
                      className={`py-2 px-1 text-center rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        isInProc 
                          ? 'bg-sky-500/25 text-sky-300 border border-sky-500/50 shadow-sm shadow-sky-500/20' 
                          : 'bg-white/5 hover:bg-sky-500/10 text-neutral-400 hover:text-sky-300 border border-transparent'
                      }`}
                    >
                      {isFa ? 'در حال انجام' : 'In Action'}
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      </section>

      {/* 3. SECTION 2: لیست درخواست‌های نوبت (در انتظار تأیید) */}
      <section className="max-w-7xl mx-auto space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-t border-white/5 pt-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-amber-500/15 border border-amber-400/30 text-amber-300 flex items-center justify-center">
              <Hourglass className="w-4 h-4 text-amber-300 animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white">
                  {isFa ? 'درخواست‌های نوبت (در انتظار بررسی و تأیید)' : 'Pending Booking Requests'}
                </h2>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-400/30 font-bold font-mono">
                  {formatPersianNumber(pendingRequests.length, lang)} {isFa ? 'درخواست جدید' : 'new'}
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                {isFa 
                  ? 'درخواست‌های ثبت‌شده توسط کاربران. با تأیید نوبت، وضعیت به «تأیید شده» تغییر یافته و صندلی رزرو می‌شود.' 
                  : 'Submitted appointment requests awaiting confirmation.'}
              </p>
            </div>
          </div>
        </div>

        {/* Pending Requests Cards */}
        {pendingRequests.length === 0 ? (
          <div className="p-8 rounded-3xl bg-[#11131A] border border-[#222634] text-center space-y-2">
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mx-auto" />
            <h4 className="text-sm font-bold text-white">
              {isFa ? 'هیچ درخواست در انتظار بررسی وجود ندارد' : 'No Pending Requests'}
            </h4>
            <p className="text-xs text-neutral-400">
              {isFa ? 'تمام درخواست‌های ورودی بررسی و تعیین وضعیت شده‌اند.' : 'All incoming booking requests have been reviewed.'}
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {pendingRequests.map((req) => (
              <div
                key={req.id}
                className="p-5 rounded-3xl bg-[#11131A] border border-amber-400/30 hover:border-amber-400/50 transition-all shadow-xl flex flex-col lg:flex-row lg:items-center justify-between gap-5"
              >
                {/* Applicant Details */}
                <div className="space-y-2 flex-1">
                  <div className="flex flex-wrap items-center gap-2.5">
                    <span className="text-base font-bold text-white flex items-center gap-1.5">
                      <User className="w-4 h-4 text-[#E5C378]" />
                      <span>{req.fullName}</span>
                    </span>

                    <a
                      href={`tel:${req.phoneNumber}`}
                      className="text-xs font-mono font-bold text-[#E5C378] bg-[#E5C378]/10 hover:bg-[#E5C378]/20 px-2.5 py-1 rounded-lg border border-[#E5C378]/30 flex items-center gap-1 transition-colors"
                      title={isFa ? 'تماس با متقاضی' : 'Call Applicant'}
                    >
                      <Phone className="w-3.5 h-3.5" />
                      <span>{req.phoneNumber}</span>
                    </a>

                    {/* Status Badge: در انتظار تأیید */}
                    <span className="inline-flex items-center gap-1 px-3 py-0.5 rounded-full text-[11px] font-bold bg-amber-500/15 text-amber-300 border border-amber-400/30">
                      <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
                      <span>{isFa ? 'در انتظار تأیید' : 'Pending Confirmation'}</span>
                    </span>
                  </div>

                  {/* Desired Service */}
                  <div className="text-xs text-neutral-200">
                    <span className="text-neutral-400">{isFa ? 'خدمت درخواستی:' : 'Requested Service:'} </span>
                    <strong className="text-[#E5C378]">{req.desiredService}</strong>
                  </div>

                  {/* Date, Time & Slot */}
                  <div className="flex flex-wrap items-center gap-3 text-xs text-neutral-400">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-neutral-500" />
                      <span>{req.suggestedDate}</span>
                    </span>
                    <span>·</span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-neutral-500" />
                      <span>{req.suggestedTime}</span>
                    </span>
                    {req.slotNameFa && (
                      <>
                        <span>·</span>
                        <span className="text-neutral-300 font-semibold">{req.slotNameFa}</span>
                      </>
                    )}
                  </div>

                  {/* Notes if provided */}
                  {req.notes && (
                    <div className="p-2.5 rounded-xl bg-white/5 border border-white/5 text-xs text-neutral-300">
                      <span className="text-neutral-400">{isFa ? 'یادداشت متقاضی:' : 'Notes:'} </span>
                      <span>{req.notes}</span>
                    </div>
                  )}
                </div>

                {/* Right Side: Tracking Code & Action Buttons */}
                <div className="flex flex-col sm:flex-row lg:flex-col items-start lg:items-end justify-between gap-3 shrink-0 border-t lg:border-t-0 pt-3 lg:pt-0 border-white/5">
                  <div className="text-left rtl:text-right">
                    <span className="text-[10px] text-neutral-500 block">{isFa ? 'کد پیگیری:' : 'Tracking:'}</span>
                    <button
                      type="button"
                      onClick={() => handleCopyCode(req.trackingCode)}
                      className="font-mono text-xs font-bold text-neutral-300 hover:text-[#E5C378] flex items-center gap-1 transition-colors cursor-pointer"
                    >
                      <span>{req.trackingCode}</span>
                      {copiedCode === req.trackingCode ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5 text-neutral-500" />
                      )}
                    </button>
                  </div>

                  {/* Approve / Reject Buttons */}
                  <div className="flex items-center gap-2 w-full sm:w-auto">
                    <button
                      type="button"
                      onClick={() => handleApprove(req)}
                      className="flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold bg-emerald-500 hover:bg-emerald-400 text-neutral-950 transition-all flex items-center justify-center gap-1.5 shadow-md shadow-emerald-500/20 cursor-pointer"
                    >
                      <Check className="w-4 h-4 text-neutral-950" />
                      <span>{isFa ? 'تأیید نوبت' : 'Approve'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleReject(req)}
                      className="flex-1 sm:flex-none px-3.5 py-2 rounded-xl text-xs font-bold bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <X className="w-4 h-4 text-rose-300" />
                      <span>{isFa ? 'رد درخواست' : 'Reject'}</span>
                    </button>
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}
      </section>

      {/* 4. SECTION 3: لیست نوبت‌های تأیید شده (تأیید شده) */}
      <section className="max-w-7xl mx-auto space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-t border-white/5 pt-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 flex items-center justify-center">
              <CalendarCheck className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-bold text-white">
                  {isFa ? 'لیست نوبت‌های تأیید شده' : 'Confirmed Appointments'}
                </h2>
                <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 font-bold font-mono">
                  {formatPersianNumber(confirmedRequests.length, lang)} {isFa ? 'نوبت تأیید شده' : 'confirmed'}
                </span>
              </div>
              <p className="text-xs text-neutral-400">
                {isFa ? 'نوبت‌های قطعی و زمان‌بندی‌شده توسط مدیریت کلینیک' : 'Confirmed clinic reservations'}
              </p>
            </div>
          </div>
        </div>

        {/* Confirmed List */}
        <div className="space-y-3">
          {confirmedRequests.map((req) => (
            <div
              key={req.id}
              className="p-4 sm:p-5 rounded-2xl bg-[#11131A] border border-[#222634] hover:border-emerald-500/30 transition-all flex flex-col md:flex-row md:items-center justify-between gap-4"
            >
              <div className="flex items-start sm:items-center gap-4">
                <div className="px-3.5 py-2 rounded-xl bg-[#1A1D26] border border-[#2B303C] text-center shrink-0">
                  <span className="text-[10px] text-neutral-400 block font-mono">
                    {isFa ? 'شیفت' : 'Slot'}
                  </span>
                  <span className="text-xs sm:text-sm font-bold font-mono text-white">
                    {req.suggestedTime.split('(')[0] || req.suggestedTime}
                  </span>
                </div>

                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm sm:text-base font-bold text-white">
                      {req.fullName}
                    </span>
                    <span className="text-xs font-mono text-neutral-400">
                      {req.phoneNumber}
                    </span>
                  </div>

                  <div className="text-xs text-[#E5C378] font-medium mt-0.5">
                    {req.desiredService}
                  </div>

                  <div className="text-[11px] text-neutral-400 mt-1 flex items-center gap-2">
                    <span>{req.suggestedDate}</span>
                    {req.slotNameFa && (
                      <>
                        <span>·</span>
                        <span>{req.slotNameFa}</span>
                      </>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between md:justify-end gap-4 border-t md:border-t-0 pt-3 md:pt-0 border-white/5">
                <div className="text-left rtl:text-right">
                  <span className="text-[10px] text-neutral-500 block">{isFa ? 'کد پیگیری:' : 'Tracking:'}</span>
                  <span className="font-mono text-xs font-bold text-neutral-300">{req.trackingCode}</span>
                </div>

                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{isFa ? 'تأیید شده' : 'Confirmed'}</span>
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 5. SECTION 4: مشاهده ساده درآمد (هنوز ساختگی) */}
      <section className="max-w-7xl mx-auto space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-t border-white/5 pt-6">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-[#E5C378]/15 border border-[#E5C378]/30 text-[#E5C378] flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-white">
                {isFa ? 'مشاهده ساده درآمد' : 'Revenue Overview'}
              </h2>
              <p className="text-xs text-neutral-400">
                {isFa ? 'گردش مالی و مبالغ رزرو شده روزانه و ماهانه کلینیک' : 'Daily and monthly revenue performance'}
              </p>
            </div>
          </div>

          <span className="text-[11px] font-mono text-[#E5C378] bg-[#E5C378]/10 border border-[#E5C378]/25 px-3 py-1 rounded-full self-start sm:self-auto">
            {isFa ? 'داده‌های شبیه‌سازی‌شده (نسخه دمو)' : 'Simulated Revenue Demo'}
          </span>
        </div>

        {/* Metric Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div className="p-5 rounded-3xl bg-[#11131A] border border-[#E5C378]/20 hover:border-[#E5C378]/40 transition-colors shadow-lg">
            <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
              <span>{isFa ? 'درآمد تخمینی امروز:' : "Today's Revenue:"}</span>
              <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20 font-bold">
                +۱۴٪
              </span>
            </div>
            <div className="text-2xl font-bold font-mono text-[#E5C378] tracking-tight">
              {formatPrice(todayRevenueToman, lang)}
            </div>
            <div className="text-[11px] text-neutral-400 mt-2 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-neutral-500" />
              <span>{isFa ? 'از نوبت‌های تأیید شده' : 'From confirmed appointments'}</span>
            </div>
          </div>

          <div className="p-5 rounded-3xl bg-[#11131A] border border-[#222634] hover:border-[#E5C378]/30 transition-colors shadow-lg">
            <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
              <span>{isFa ? 'درآمد کل این ماه (برآوردی):' : 'Estimated Monthly Revenue:'}</span>
              <TrendingUp className="w-4 h-4 text-[#E5C378]" />
            </div>
            <div className="text-2xl font-bold font-mono text-white tracking-tight">
              {formatPrice(monthlyRevenueToman, lang)}
            </div>
            <div className="text-[11px] text-neutral-400 mt-2 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-[#E5C378]" />
              <span>{isFa ? `${formatPersianNumber(confirmedRequests.length, lang)} نوبت فعال` : `${confirmedRequests.length} active bookings`}</span>
            </div>
          </div>

          <div className="p-5 rounded-3xl bg-[#11131A] border border-[#222634] hover:border-[#E5C378]/30 transition-colors shadow-lg">
            <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
              <span>{isFa ? 'نرخ اشغال صندلی‌ها و تخت‌ها:' : 'Seat Occupancy Rate:'}</span>
              <Activity className="w-4 h-4 text-[#E5C378]" />
            </div>
            <div className="text-2xl font-bold font-mono text-white tracking-tight">
              {formatPersianNumber(occupancyRate, lang)}٪
            </div>
            <div className="w-full h-1.5 bg-neutral-800 rounded-full mt-3 overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-[#E5C378] to-[#F3E5AB] rounded-full transition-all duration-500"
                style={{ width: `${occupancyRate}%` }}
              />
            </div>
          </div>

          <div className="p-5 rounded-3xl bg-[#11131A] border border-[#222634] hover:border-[#E5C378]/30 transition-colors shadow-lg">
            <div className="flex items-center justify-between text-xs text-neutral-400 mb-2">
              <span>{isFa ? 'صندلی‌های خالی و آماده:' : 'Available Seats Now:'}</span>
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" />
            </div>
            <div className="text-2xl font-bold font-mono text-emerald-400 tracking-tight">
              {formatPersianNumber(availableCount, lang)} <span className="text-xs font-sans text-neutral-400">/ {formatPersianNumber(venueSlots.length, lang)}</span>
            </div>
            <div className="text-[11px] text-neutral-400 mt-2">
              {isFa
                ? `${formatPersianNumber(inProcedureCount, lang)} تخت در حال انجام، ${formatPersianNumber(reservedCount, lang)} رزرو شده`
                : `${inProcedureCount} in procedure, ${reservedCount} reserved`}
            </div>
          </div>
        </div>
      </section>

    </div>
  );
};
