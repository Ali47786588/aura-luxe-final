import React from 'react';
import { CheckCircle2, AlertCircle, Info, XCircle, X } from 'lucide-react';
import { ToastAlert } from '../types';

interface Props {
  toasts: ToastAlert[];
  onDismiss: (id: string) => void;
}

export const ToastNotificationContainer: React.FC<Props> = ({ toasts, onDismiss }) => {
  if (toasts.length === 0) return null;

  return (
    <div className="fixed top-5 left-1/2 -translate-x-1/2 z-50 flex flex-col gap-2 w-full max-w-md px-4 pointer-events-none">
      {toasts.map((toast) => {
        let Icon = CheckCircle2;
        let borderClass = 'border-amber-400/30';
        let iconColor = 'text-amber-300';

        if (toast.type === 'error') {
          Icon = XCircle;
          borderClass = 'border-red-500/40';
          iconColor = 'text-red-400';
        } else if (toast.type === 'warning') {
          Icon = AlertCircle;
          borderClass = 'border-amber-500/50';
          iconColor = 'text-amber-400';
        } else if (toast.type === 'info') {
          Icon = Info;
          borderClass = 'border-sky-500/40';
          iconColor = 'text-sky-400';
        }

        return (
          <div
            key={toast.id}
            className={`pointer-events-auto rounded-2xl bg-neutral-900/95 backdrop-blur-2xl border ${borderClass} p-3.5 shadow-2xl text-white flex items-start gap-3 transition-all animate-in fade-in slide-in-from-top-3 duration-200`}
          >
            <Icon className={`w-5 h-5 shrink-0 mt-0.5 ${iconColor}`} />
            <div className="flex-1 min-w-0">
              <h5 className="text-xs font-bold text-white tracking-tight">{toast.title}</h5>
              <p className="text-[11px] text-neutral-300 mt-0.5 leading-relaxed">{toast.message}</p>
            </div>
            <button
              onClick={() => onDismiss(toast.id)}
              className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
