import React, { useState } from 'react';
import { Clock, CheckCircle2, AlertCircle, RefreshCw, UserCheck, ShieldAlert, Sparkles, Filter, ChevronRight, Stethoscope } from 'lucide-react';
import { RealtimeSlot, SlotStatus, Language } from '../types';
import { t, formatPrice, formatPersianNumber } from '../data/translations';

interface Props {
  slots: RealtimeSlot[];
  onToggleSlotStatus: (slotId: string, nextStatus: SlotStatus) => void;
  onBookSlot: (slot: RealtimeSlot) => void;
  lang: Language;
}

export const RealtimeSlotPanel: React.FC<Props> = ({
  slots,
  onToggleSlotStatus,
  onBookSlot,
  lang,
}) => {
  const [filterMode, setFilterMode] = useState<'all' | 'available_only'>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const strings = t(lang);
  const isFa = lang === 'fa';

  const filteredSlots = slots.filter((slot) => {
    if (filterMode === 'available_only' && slot.status !== 'available') return false;
    if (selectedType !== 'all' && slot.type !== selectedType) return false;
    return true;
  });

  const getStatusBadge = (status: SlotStatus) => {
    switch (status) {
      case 'available':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-600 dark:text-emerald-400 border border-emerald-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span>{strings.statusAvailable}</span>
          </span>
        );
      case 'in_procedure':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-500/15 text-blue-600 dark:text-blue-400 border border-blue-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-500" />
            <span>{strings.statusInProcedure}</span>
          </span>
        );
      case 'reserved':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-amber-500/15 text-amber-600 dark:text-amber-400 border border-amber-500/30">
            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
            <span>{strings.statusReserved}</span>
          </span>
        );
      case 'sanitizing':
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-purple-500/15 text-purple-600 dark:text-purple-400 border border-purple-500/30">
            <RefreshCw className="w-3 h-3 animate-spin" />
            <span>{strings.statusSanitizing}</span>
          </span>
        );
    }
  };

  const getNextStatus = (current: SlotStatus): SlotStatus => {
    switch (current) {
      case 'available':
        return 'in_procedure';
      case 'in_procedure':
        return 'sanitizing';
      case 'sanitizing':
        return 'available';
      case 'reserved':
        return 'in_procedure';
      default:
        return 'available';
    }
  };

  return (
    <div className="rounded-3xl border border-neutral-200 dark:border-white/10 bg-white/70 dark:bg-neutral-900/50 backdrop-blur-xl p-6 sm:p-8 shadow-sm">
      {/* Header and Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 pb-6 border-b border-neutral-200 dark:border-white/10">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium text-neutral-500 dark:text-neutral-400 mb-1">
            <span className="font-semibold text-neutral-900 dark:text-white uppercase tracking-wider">
              {strings.ownerConsoleBtn}
            </span>
            <span aria-hidden="true">·</span>
            <span>{isFa ? 'مدیریت فوری تخت و صندلی' : 'Immediate Chair Allocation'}</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-900 dark:text-white">
            {strings.slotPanelTitle}
          </h2>
          <p className="text-sm text-neutral-500 dark:text-neutral-400 mt-1 max-w-xl">
            {strings.slotPanelSubtitle}
          </p>
        </div>

        {/* Filter controls */}
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setFilterMode('all')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors ${
              filterMode === 'all'
                ? 'bg-neutral-950 text-white dark:bg-white dark:text-neutral-950 shadow-sm'
                : 'bg-neutral-100 dark:bg-white/5 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-white/10'
            }`}
          >
            {strings.filterAllSlots}
          </button>
          <button
            onClick={() => setFilterMode('available_only')}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-colors ${
              filterMode === 'available_only'
                ? 'bg-neutral-950 text-white dark:bg-white dark:text-neutral-950 shadow-sm'
                : 'bg-neutral-100 dark:bg-white/5 text-neutral-600 dark:text-neutral-300 hover:bg-neutral-200 dark:hover:bg-white/10'
            }`}
          >
            {strings.filterAvailableOnly}
          </button>

          <select
            value={selectedType}
            onChange={(e) => setSelectedType(e.target.value)}
            className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-neutral-100 dark:bg-white/5 text-neutral-800 dark:text-neutral-200 border border-neutral-300/80 dark:border-white/10 focus:outline-none"
          >
            <option value="all">{isFa ? 'همه تجهیزات' : 'All Types'}</option>
            <option value="operatory">{isFa ? 'یونیت دندانپزشکی' : 'Dental Operatory'}</option>
            <option value="laser_suite">{isFa ? 'سوئیت لیزر' : 'Laser Suite'}</option>
            <option value="bed">{isFa ? 'تخت جراحی / پوست' : 'Aesthetic Bed'}</option>
            <option value="chair">{isFa ? 'صندلی سالن و استایلینگ' : 'Salon Chair'}</option>
          </select>
        </div>
      </div>

      {/* Real-time Slots Grid */}
      <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredSlots.map((slot) => {
          const isAvailable = slot.status === 'available';

          return (
            <div
              key={slot.id}
              className={`p-5 rounded-2xl border transition-all duration-200 flex flex-col justify-between ${
                isAvailable
                  ? 'bg-white dark:bg-neutral-900/90 border-neutral-200 dark:border-white/10 shadow-sm hover:border-neutral-300 dark:hover:border-white/20'
                  : 'bg-neutral-50 dark:bg-neutral-900/40 border-neutral-200 dark:border-white/5 opacity-90'
              }`}
            >
              {/* Slot Header */}
              <div>
                <div className="flex items-start justify-between gap-3 mb-2">
                  <div>
                    <span className="text-[11px] font-mono uppercase tracking-wider text-neutral-400">
                      {isFa ? slot.venueNameFa : slot.venueNameEn}
                    </span>
                    <h3 className="text-base font-bold text-neutral-900 dark:text-white mt-0.5">
                      {isFa ? slot.roomNameFa : slot.roomNameEn}
                    </h3>
                  </div>
                  <div>{getStatusBadge(slot.status)}</div>
                </div>

                {/* Occupied State Info */}
                {slot.status === 'in_procedure' && (
                  <div className="my-3 p-3 rounded-xl bg-blue-500/10 border border-blue-500/20 text-xs text-blue-900 dark:text-blue-200">
                    <div className="font-semibold">{slot.currentPractitioner}</div>
                    <div className="text-[11px] text-blue-700 dark:text-blue-300 mt-0.5">
                      {slot.patientProcedure}
                    </div>
                  </div>
                )}

                {slot.status === 'reserved' && (
                  <div className="my-3 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-xs text-amber-900 dark:text-amber-200">
                    <div className="font-semibold">{slot.currentPractitioner}</div>
                    <div className="text-[11px] text-amber-700 dark:text-amber-300 mt-0.5">
                      {slot.patientProcedure}
                    </div>
                  </div>
                )}

                {/* Equipment Highlights */}
                <div className="mt-3 text-xs text-neutral-500 dark:text-neutral-400 space-y-1">
                  <div className="line-clamp-1 font-mono text-[11px] text-neutral-600 dark:text-neutral-300">
                    {slot.equipment.join(' · ')}
                  </div>
                </div>

                {/* Features Badges */}
                <div className="mt-3.5 flex flex-wrap gap-2 text-[11px] text-neutral-600 dark:text-neutral-300">
                  {slot.assistantIncluded && (
                    <span className="px-2 py-0.5 rounded-md bg-neutral-100 dark:bg-white/5 border border-neutral-200 dark:border-white/5">
                      {strings.assistantBadge}
                    </span>
                  )}
                  {slot.autoclaveReady && (
                    <span className="px-2 py-0.5 rounded-md bg-neutral-100 dark:bg-white/5 border border-neutral-200 dark:border-white/5">
                      {strings.autoclaveBadge}
                    </span>
                  )}
                  <span className="px-2 py-0.5 rounded-md bg-neutral-100 dark:bg-white/5 border border-neutral-200 dark:border-white/5">
                    {strings.lastSanitized} {formatPersianNumber(slot.lastSanitizedMinutesAgo, lang)} {strings.minutesAgo}
                  </span>
                </div>
              </div>

              {/* Bottom Actions & Rates */}
              <div className="mt-5 pt-4 border-t border-neutral-100 dark:border-white/5 flex items-center justify-between gap-2">
                <div>
                  <div className="text-[10px] text-neutral-400 uppercase tracking-wider">
                    {strings.hourlyRate}
                  </div>
                  <div className="text-sm font-bold text-neutral-900 dark:text-white tabular-nums">
                    {formatPrice(slot.pricePerHourToman, lang)}
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  {/* Instant Status Switcher for Owners */}
                  <button
                    onClick={() => onToggleSlotStatus(slot.id, getNextStatus(slot.status))}
                    className="p-2 rounded-xl bg-neutral-100 hover:bg-neutral-200 dark:bg-white/10 dark:hover:bg-white/15 text-neutral-700 dark:text-neutral-200 text-xs font-semibold transition-colors"
                    title={isFa ? 'تغییر وضعیت این یونیت (مخصوص مدیر)' : 'Cycle status (Owner control)'}
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                  </button>

                  {/* Doctor Book Button */}
                  <button
                    onClick={() => onBookSlot(slot)}
                    disabled={!isAvailable}
                    className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition-all ${
                      isAvailable
                        ? 'bg-neutral-950 text-white hover:bg-neutral-800 dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 shadow-sm'
                        : 'bg-neutral-200 dark:bg-white/5 text-neutral-400 dark:text-neutral-600 cursor-not-allowed'
                    }`}
                  >
                    {isAvailable ? strings.bookThisSlot : strings.statusReserved}
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
