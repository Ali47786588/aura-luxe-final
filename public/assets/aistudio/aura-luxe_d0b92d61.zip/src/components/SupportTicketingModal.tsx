import React, { useState } from 'react';
import { X, MessageSquare, Send, ShieldCheck, Clock, CheckCircle2, AlertTriangle, Plus, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';
import { SupportTicket, Language } from '../types';
import { INITIAL_TICKETS } from '../data/mockData';
import { t } from '../data/translations';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const SupportTicketingModal: React.FC<Props> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const [tickets, setTickets] = useState<SupportTicket[]>(INITIAL_TICKETS);
  const [selectedTicketId, setSelectedTicketId] = useState<string>(INITIAL_TICKETS[0].id);
  const [replyMessage, setReplyMessage] = useState<string>('');
  const [isCreatingNew, setIsCreatingNew] = useState<boolean>(false);

  // New ticket state
  const [newSubject, setNewSubject] = useState<string>('');
  const [newCategory, setNewCategory] = useState<'escrow' | 'slot' | 'technical' | 'verification'>('escrow');
  const [newPriority, setNewPriority] = useState<'urgent' | 'high' | 'normal'>('high');
  const [newContent, setNewContent] = useState<string>('');

  const strings = t(lang);
  const isFa = lang === 'fa';
  const ChevronIcon = isFa ? ChevronLeft : ChevronRight;

  if (!isOpen) return null;

  const activeTicket = tickets.find((t) => t.id === selectedTicketId) ?? tickets[0];

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyMessage.trim()) return;

    setTickets((prev) =>
      prev.map((t) => {
        if (t.id !== selectedTicketId) return t;
        return {
          ...t,
          status: 'open',
          messages: [
            ...t.messages,
            {
              id: `msg_${Date.now()}`,
              senderName: isFa ? 'مدیر کلینیک' : 'Clinic Director',
              isStaff: false,
              content: replyMessage,
              timestamp: isFa ? 'هم‌اکنون' : 'Just now',
            },
          ],
        };
      })
    );
    setReplyMessage('');
  };

  const handleCreateTicket = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSubject.trim() || !newContent.trim()) return;

    const newTicket: SupportTicket = {
      id: `t_${Date.now()}`,
      ticketNumber: `TKT-${Math.floor(1000 + Math.random() * 9000)}`,
      senderName: isFa ? 'دکتر آرش رادمنش (مسئول فنی)' : 'Dr. Arash Radmanesh',
      senderRole: 'clinic_owner',
      venueName: isFa ? 'پنت‌هاوس زیبایی لورا (سعادت‌آباد)' : 'L’Aura Aesthetics Penthouse',
      subject: newSubject,
      category: newCategory,
      priority: newPriority,
      status: 'open',
      createdAt: isFa ? 'هم‌اکنون' : 'Just now',
      messages: [
        {
          id: `msg_${Date.now()}`,
          senderName: isFa ? 'دکتر آرش رادمنش' : 'Dr. Arash Radmanesh',
          isStaff: false,
          content: newContent,
          timestamp: isFa ? 'هم‌اکنون' : 'Just now',
        },
      ],
    };

    setTickets([newTicket, ...tickets]);
    setSelectedTicketId(newTicket.id);
    setIsCreatingNew(false);
    setNewSubject('');
    setNewContent('');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-4xl rounded-3xl apple-glass border border-neutral-700/60 p-6 sm:p-8 shadow-2xl text-neutral-100 z-10 my-8 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 left-6 rtl:left-auto rtl:right-6 p-2 rounded-full bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center justify-between pb-6 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-300 mb-1">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>{isFa ? 'ارتباط امن تجاری و پشتیبانی اختصاصی' : 'CONFIDENTIAL B2B SUPPORT'}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
              {isFa ? 'سیستم تیکتینگ و پشتیبانی مراکز با مدیریت' : 'B2B Partner Support & Ticketing'}
            </h2>
          </div>

          <button
            onClick={() => setIsCreatingNew((prev) => !prev)}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 hover:opacity-95 transition-all shadow-md flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4 text-neutral-950" />
            <span>{isFa ? 'ثبت تیکت جدید' : 'Open Ticket'}</span>
          </button>
        </div>

        {/* Create New Ticket Form */}
        {isCreatingNew ? (
          <form onSubmit={handleCreateTicket} className="py-6 space-y-4 animate-fadeIn">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>{isFa ? 'ثبت درخواست پشتیبانی و مکاتبه با مدیریت' : 'New Support Request'}</span>
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {isFa ? 'موضوع تیکت:' : 'Ticket Subject:'}
                </label>
                <input
                  type="text"
                  value={newSubject}
                  onChange={(e) => setNewSubject(e.target.value)}
                  placeholder={isFa ? 'مثال: تسویه حساب امانی یا کالیبراسیون لیزر' : 'e.g. Escrow disbursement inquiry'}
                  className="w-full p-3 rounded-xl bg-white/5 border border-white/10 text-white text-xs sm:text-sm focus:outline-none focus:border-amber-300/50"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isFa ? 'دسته‌بندی:' : 'Category:'}
                  </label>
                  <select
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value as any)}
                    className="w-full p-3 rounded-xl bg-white/5 border border-white/10 text-white text-xs sm:text-sm focus:outline-none"
                  >
                    <option value="escrow" className="bg-neutral-900 text-white">{isFa ? 'مالی و حساب امانی' : 'Escrow & Finance'}</option>
                    <option value="technical" className="bg-neutral-900 text-white">{isFa ? 'فنی و تجهیزات' : 'Technical & Laser'}</option>
                    <option value="slot" className="bg-neutral-900 text-white">{isFa ? 'زمان‌بندی و تخت‌ها' : 'Slot Scheduling'}</option>
                    <option value="verification" className="bg-neutral-900 text-white">{isFa ? 'احراز هویت و مجوز' : 'Licensing & KYC'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isFa ? 'اولویت:' : 'Priority:'}
                  </label>
                  <select
                    value={newPriority}
                    onChange={(e) => setNewPriority(e.target.value as any)}
                    className="w-full p-3 rounded-xl bg-white/5 border border-white/10 text-white text-xs sm:text-sm focus:outline-none"
                  >
                    <option value="urgent" className="bg-neutral-900 text-white">{isFa ? 'فوری (حین جراحی)' : 'Urgent'}</option>
                    <option value="high" className="bg-neutral-900 text-white">{isFa ? 'بالا' : 'High'}</option>
                    <option value="normal" className="bg-neutral-900 text-white">{isFa ? 'عادی' : 'Normal'}</option>
                  </select>
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-neutral-300 mb-1">
                {isFa ? 'متن پیام و توضیحات کامل:' : 'Message Details:'}
              </label>
              <textarea
                rows={4}
                value={newContent}
                onChange={(e) => setNewContent(e.target.value)}
                placeholder={isFa ? 'جزئیات درخواست یا مشکل خود را به دقت شرح دهید...' : 'Describe the details...'}
                className="w-full p-3 rounded-xl bg-white/5 border border-white/10 text-white text-xs sm:text-sm focus:outline-none focus:border-amber-300/50"
                required
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsCreatingNew(false)}
                className="px-4 py-2.5 rounded-xl text-xs font-semibold text-neutral-400 hover:text-white"
              >
                {isFa ? 'انصراف' : 'Cancel'}
              </button>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-2xl text-xs font-bold bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 shadow-md"
              >
                {isFa ? 'ثبت و ارسال پیام به مدیریت' : 'Submit Ticket'}
              </button>
            </div>
          </form>
        ) : (
          /* Main 2-Column Split: Ticket List Left, Message Thread Right */
          <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-6 pt-6 overflow-hidden min-h-[380px]">
            {/* Left: Ticket List (5 cols) */}
            <div className="md:col-span-5 space-y-2.5 overflow-y-auto pr-1">
              {tickets.map((tkt) => {
                const isSelected = tkt.id === selectedTicketId;

                return (
                  <div
                    key={tkt.id}
                    onClick={() => setSelectedTicketId(tkt.id)}
                    className={`p-3.5 rounded-2xl border transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-neutral-800/90 border-amber-300/50 ring-1 ring-amber-300/30'
                        : 'bg-white/5 border-white/5 hover:bg-white/10'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px] mb-1">
                      <span className="font-mono text-amber-300 font-semibold">{tkt.ticketNumber}</span>
                      <span className="text-neutral-400">{tkt.createdAt}</span>
                    </div>

                    <h4 className="text-xs font-bold text-white line-clamp-1 mb-1">
                      {tkt.subject}
                    </h4>

                    <div className="flex items-center justify-between text-[10px]">
                      <span className="text-neutral-400 line-clamp-1">{tkt.senderName}</span>
                      <span
                        className={`px-2 py-0.5 rounded-full font-semibold ${
                          tkt.status === 'answered'
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : tkt.status === 'open'
                            ? 'bg-amber-500/20 text-amber-300'
                            : 'bg-neutral-800 text-neutral-400'
                        }`}
                      >
                        {tkt.status === 'answered' ? (isFa ? 'پاسخ داده شد' : 'Answered') : tkt.status === 'open' ? (isFa ? 'در حال بررسی' : 'Open') : (isFa ? 'حل شده' : 'Resolved')}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Right: Message Thread (7 cols) */}
            <div className="md:col-span-7 flex flex-col justify-between border-t md:border-t-0 md:border-l rtl:md:border-l-0 rtl:md:border-r border-white/10 pl-0 md:pl-6 rtl:md:pl-0 rtl:md:pr-6 overflow-hidden">
              {/* Thread Header */}
              <div className="pb-3 border-b border-white/10">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-amber-300">{activeTicket.ticketNumber}</span>
                  <span className="text-[11px] px-2 py-0.5 rounded-md bg-white/10 text-neutral-300">
                    {activeTicket.category === 'escrow' ? (isFa ? 'امور مالی و امانی' : 'Escrow') : (isFa ? 'فنی و عملیاتی' : 'Operations')}
                  </span>
                </div>
                <h3 className="text-sm sm:text-base font-bold text-white mt-1">
                  {activeTicket.subject}
                </h3>
                <div className="text-[11px] text-neutral-400 mt-0.5">
                  {activeTicket.venueName}
                </div>
              </div>

              {/* Messages Bubble List */}
              <div className="flex-1 overflow-y-auto py-4 space-y-3.5 pr-1">
                {activeTicket.messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`p-3.5 rounded-2xl text-xs space-y-1 ${
                      msg.isStaff
                        ? 'bg-neutral-800/90 border border-amber-300/30 text-neutral-200 ml-4 rtl:ml-0 rtl:mr-4'
                        : 'bg-white/5 border border-white/10 text-neutral-300 mr-4 rtl:mr-0 rtl:ml-4'
                    }`}
                  >
                    <div className="flex items-center justify-between text-[11px] font-semibold text-white mb-1">
                      <span className={msg.isStaff ? 'text-amber-300 font-bold' : 'text-neutral-200'}>
                        {msg.senderName}
                      </span>
                      <span className="text-neutral-400 font-normal font-mono text-[10px]">
                        {msg.timestamp}
                      </span>
                    </div>
                    <p className="leading-relaxed whitespace-pre-wrap">{msg.content}</p>
                  </div>
                ))}
              </div>

              {/* Reply Form */}
              <form onSubmit={handleSendReply} className="pt-3 border-t border-white/10 flex items-center gap-2">
                <input
                  type="text"
                  value={replyMessage}
                  onChange={(e) => setReplyMessage(e.target.value)}
                  placeholder={isFa ? 'پاسخ خود را بنویسید...' : 'Write your response...'}
                  className="flex-1 p-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-xs focus:outline-none focus:border-amber-300/50"
                />
                <button
                  type="submit"
                  className="p-2.5 rounded-xl bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 font-bold hover:opacity-95 transition-opacity"
                  title="Send Reply"
                >
                  <Send className="w-4 h-4 rtl:-scale-x-100" />
                </button>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
