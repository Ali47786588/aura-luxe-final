import React from 'react';
import { MapPin, Globe, ShieldCheck, Sun, Moon, Lock, LogOut, ChevronDown, UserPlus, Headphones, Sparkles, ShieldAlert } from 'lucide-react';
import { Language, ThemeMode, District, UserRole } from '../types';
import { t } from '../data/translations';

interface Props {
  lang: Language;
  onToggleLang: () => void;
  theme: ThemeMode;
  onToggleTheme: () => void;
  selectedDistrict: District;
  onOpenLocationModal: () => void;
  activeSection: string;
  onNavigateSection: (sectionId: string) => void;
  onOpenBookingModal: () => void;
  userRole: UserRole;
  onOpenAdminLoginModal: () => void;
  onSwitchToPublic: () => void;
  onOpenOnboardingModal: () => void;
  onOpenSupportModal: () => void;
}

export const Navbar: React.FC<Props> = ({
  lang,
  onToggleLang,
  theme,
  onToggleTheme,
  selectedDistrict,
  onOpenLocationModal,
  activeSection,
  onNavigateSection,
  onOpenBookingModal,
  userRole,
  onOpenAdminLoginModal,
  onSwitchToPublic,
  onOpenOnboardingModal,
  onOpenSupportModal,
}) => {
  const strings = t(lang);
  const isFa = lang === 'fa';

  return (
    <header className="sticky top-0 z-40 w-full border-b border-neutral-800/80 bg-neutral-950/80 backdrop-blur-2xl transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-4 lg:gap-8">
        {/* Zone 1: Brand Wordmark */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={() => onNavigateSection('hero')}
            className="group flex items-center gap-2.5 text-left focus-visible:outline-none"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-amber-200 via-amber-400 to-amber-600 text-neutral-950 flex items-center justify-center font-bold text-base shadow-sm group-hover:scale-105 transition-transform duration-200">
              A
            </div>
            <div className="flex flex-col">
              <span className="text-lg font-bold tracking-tight text-white leading-none whitespace-nowrap">
                {lang === 'fa' ? 'آورا لوکس' : 'AURA LUXE'}
              </span>
              <span className="text-[10px] tracking-wider uppercase text-amber-300 font-mono mt-0.5 whitespace-nowrap">
                {userRole === 'super_admin'
                  ? 'SUPERADMIN MASTER'
                  : userRole === 'clinic_admin'
                  ? (isFa ? 'پنل مدیر کلینیک' : 'EXECUTIVE PORTAL')
                  : (isFa ? 'مارکت‌پلیس سلامت و زیبایی' : 'CLINICAL MARKETPLACE')}
              </span>
            </div>
          </button>
        </div>

        {/* Zone 2: Public Navigation Links */}
        {userRole === 'public' ? (
          <nav className="hidden xl:flex items-center gap-6 text-sm font-medium text-neutral-300">
            <button
              onClick={() => onNavigateSection('aesthetics')}
              className={`whitespace-nowrap transition-colors hover:text-white ${
                activeSection === 'aesthetics' ? 'text-amber-300 font-semibold' : ''
              }`}
            >
              {strings.navAesthetics}
            </button>
            <button
              onClick={() => onNavigateSection('salons')}
              className={`whitespace-nowrap transition-colors hover:text-white ${
                activeSection === 'salons' ? 'text-amber-300 font-semibold' : ''
              }`}
            >
              {strings.navSalons}
            </button>
            <button
              onClick={() => onNavigateSection('dental')}
              className={`whitespace-nowrap transition-colors hover:text-white ${
                activeSection === 'dental' ? 'text-amber-300 font-semibold' : ''
              }`}
            >
              {strings.navDental}
            </button>
            <button
              onClick={() => onNavigateSection('stories_gallery')}
              className={`whitespace-nowrap transition-colors hover:text-white ${
                activeSection === 'stories_gallery' ? 'text-amber-300 font-semibold' : ''
              }`}
            >
              {isFa ? 'استوری و هایلایت‌ها' : 'Highlights'}
            </button>
            <button
              onClick={() => onNavigateSection('realtime_slots')}
              className={`whitespace-nowrap transition-colors hover:text-white ${
                activeSection === 'realtime_slots' ? 'text-amber-300 font-semibold' : ''
              }`}
            >
              {strings.navSlots}
            </button>
          </nav>
        ) : (
          <div className="hidden lg:flex items-center gap-3 text-xs text-neutral-400">
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            <span className="text-amber-200 font-medium">
              {userRole === 'super_admin'
                ? (isFa ? 'کنسول مدیریت کلان و نظارت رگولاتوری' : 'Platform Master Governance Console')
                : (isFa ? 'داشبورد اختصاصی مدیریت و امور مالی کلینیک' : 'Private Financial & Operations Dashboard')}
            </span>
          </div>
        )}

        {/* Zone 3: Actions & Quick Modals */}
        <div className="flex items-center gap-2 sm:gap-2.5 shrink-0">
          {/* Location Trigger (public mode) */}
          {userRole === 'public' && (
            <button
              onClick={onOpenLocationModal}
              className="flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-2 rounded-xl text-xs sm:text-sm font-medium bg-white/5 hover:bg-white/10 text-neutral-200 border border-white/10 transition-colors whitespace-nowrap"
              title="Switch location"
            >
              <MapPin className="w-3.5 h-3.5 text-amber-300" />
              <span className="font-semibold hidden sm:inline">
                {lang === 'fa' ? selectedDistrict.nameFa : selectedDistrict.nameEn}
              </span>
              <ChevronDown className="w-3 h-3 text-neutral-400" />
            </button>
          )}

          {/* Onboarding Register Button (Clinic / Doctor / Salon registration) */}
          {userRole === 'public' && (
            <button
              onClick={onOpenOnboardingModal}
              className="flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-2 rounded-xl text-xs font-semibold bg-amber-400/10 hover:bg-amber-400/15 text-amber-300 border border-amber-400/30 hover:border-amber-400/50 transition-all shadow-sm whitespace-nowrap cursor-pointer"
              title={isFa ? 'ثبت‌نام مرکز یا پزشک' : 'Register Center or Doctor'}
            >
              <UserPlus className="w-3.5 h-3.5 text-amber-300 shrink-0" />
              <span className="hidden sm:inline">{isFa ? 'ثبت‌نام مرکز یا پزشک' : 'Register Center/Doctor'}</span>
              <span className="sm:hidden">{isFa ? 'ثبت‌نام مرکز' : 'Register'}</span>
            </button>
          )}

          {/* Support & Ticketing Button */}
          <button
            onClick={onOpenSupportModal}
            className="p-2 sm:px-3 sm:py-2 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-neutral-300 hover:text-white border border-white/10 transition-colors flex items-center gap-1.5"
            title={isFa ? 'سیستم پشتیبانی و تیکتینگ' : 'Support & Ticketing'}
          >
            <Headphones className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden md:inline">{isFa ? 'پشتیبانی' : 'Support'}</span>
          </button>

          {/* Management Login */}
          {userRole === 'public' ? (
            <button
              onClick={onOpenAdminLoginModal}
              className="flex items-center gap-1.5 px-2.5 py-1.5 sm:px-3 sm:py-2 rounded-xl text-xs font-semibold text-neutral-200 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition-colors whitespace-nowrap"
              title={strings.loginAsManagerBtn}
            >
              <Lock className="w-3.5 h-3.5 text-amber-300" />
              <span>{strings.loginAsManagerBtn}</span>
            </button>
          ) : (
            <button
              onClick={onSwitchToPublic}
              className="flex items-center gap-1.5 px-3 py-1.5 sm:py-2 rounded-xl text-xs font-semibold bg-white/10 hover:bg-white/15 text-white border border-white/15 transition-all whitespace-nowrap"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>{strings.switchToPublicView}</span>
            </button>
          )}

          {/* Language Toggle */}
          <button
            onClick={onToggleLang}
            className="flex items-center gap-1 px-2.5 py-1.5 sm:py-2 rounded-xl text-xs font-semibold bg-white/5 hover:bg-white/10 text-neutral-300 border border-white/10 transition-colors whitespace-nowrap"
            title="Toggle Language"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{lang === 'fa' ? 'EN' : 'فا'}</span>
          </button>

          {/* Primary Action Button (public mode) */}
          {userRole === 'public' && (
            <button
              onClick={onOpenBookingModal}
              className="px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 hover:opacity-95 transition-all shadow-md whitespace-nowrap shrink-0"
            >
              {strings.bookSlotBtn}
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
