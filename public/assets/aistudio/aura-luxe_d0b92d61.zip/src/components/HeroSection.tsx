import React from 'react';
import { ArrowLeft, ArrowRight, ShieldCheck, MapPin, Building, Sparkles, CheckCircle2 } from 'lucide-react';
import { Language, District } from '../types';
import { t } from '../data/translations';

interface Props {
  lang: Language;
  selectedDistrict: District;
  onOpenLocationModal: () => void;
  onExploreClinics: () => void;
  onOpenSlotPanel: () => void;
  onOpenBookingModal: () => void;
}

export const HeroSection: React.FC<Props> = ({
  lang,
  selectedDistrict,
  onOpenLocationModal,
  onExploreClinics,
  onOpenSlotPanel,
  onOpenBookingModal,
}) => {
  const strings = t(lang);
  const isFa = lang === 'fa';
  const ArrowIcon = isFa ? ArrowLeft : ArrowRight;

  return (
    <section className="relative pt-12 pb-20 sm:pt-16 sm:pb-28 overflow-hidden">
      {/* Background radial gradient glow (subtle titanium/charcoal) */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[800px] h-[400px] bg-gradient-to-b from-neutral-500/10 via-neutral-500/5 to-transparent blur-3xl pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Context Kicker (Anti-slop: clean unboxed metadata with bullet separators) */}
        <div className="flex items-center gap-2 text-xs font-medium text-neutral-500 dark:text-neutral-400 mb-6">
          <span className="text-neutral-900 dark:text-neutral-200 font-semibold tracking-wide">
            {strings.heroPill}
          </span>
          <span aria-hidden="true">·</span>
          <span>{isFa ? 'تهران و کرج' : 'Tehran & Karaj'}</span>
          <span aria-hidden="true">·</span>
          <button
            onClick={onOpenLocationModal}
            className="text-neutral-700 dark:text-neutral-300 hover:underline inline-flex items-center gap-1"
          >
            <MapPin className="w-3 h-3 text-neutral-400" />
            <span>{isFa ? selectedDistrict.nameFa : selectedDistrict.nameEn}</span>
          </button>
        </div>

        {/* 2-Column Split: Headline & Prose Left, Hero Operatory Card Right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-center">
          {/* Column 1: Typography & CTAs (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-neutral-950 dark:text-white leading-[1.12] text-balance">
              <span>{strings.heroTitlePart1}</span>
              <br />
              <span className="bg-gradient-to-r from-neutral-900 via-neutral-600 to-neutral-400 dark:from-white dark:via-neutral-200 dark:to-neutral-500 bg-clip-text text-transparent">
                {strings.heroTitlePart2}
              </span>
            </h1>

            <p className="text-base sm:text-lg text-neutral-600 dark:text-neutral-300 leading-relaxed max-w-2xl">
              {strings.heroDescription}
            </p>

            {/* Action buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onExploreClinics}
                className="px-6 py-3.5 rounded-2xl text-sm font-semibold bg-neutral-950 text-white hover:bg-neutral-800 dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 transition-all shadow-md inline-flex items-center gap-2.5 group"
              >
                <span>{strings.exploreClinics}</span>
                <ArrowIcon className="w-4 h-4 group-hover:translate-x-1 transition-transform rtl:group-hover:-translate-x-1" />
              </button>

              <button
                onClick={onOpenSlotPanel}
                className="px-6 py-3.5 rounded-2xl text-sm font-semibold bg-neutral-100 hover:bg-neutral-200/80 dark:bg-white/10 dark:hover:bg-white/15 text-neutral-900 dark:text-white border border-neutral-300/80 dark:border-white/15 transition-all inline-flex items-center gap-2"
              >
                <Building className="w-4 h-4 text-neutral-500 dark:text-neutral-400" />
                <span>{strings.openSlotPanel}</span>
              </button>
            </div>

            {/* Trust points */}
            <div className="pt-4 flex flex-wrap items-center gap-y-2 gap-x-6 text-xs text-neutral-500 dark:text-neutral-400">
              <div className="flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>
                  {isFa ? 'تجهیزات برند ۲۰۲۵ (کندلا، کاستلینی، تریوس ۵)' : 'Brand-Name Operatories (Candela, Castellini, Trios 5)'}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
                <span>
                  {isFa ? 'تضمین رسمی کیفیت خدمات و سلامت مراجعین' : 'Verified Quality & Patient Satisfaction Guarantee'}
                </span>
              </div>
            </div>
          </div>

          {/* Column 2: Architectural Hero Visual Card (5 cols) */}
          <div className="lg:col-span-5">
            <div className="relative rounded-3xl overflow-hidden border border-neutral-200 dark:border-white/10 shadow-2xl bg-neutral-900 group">
              <img
                src="/src/assets/images/clinic_skin_aesthetic_hero_1793732832048.jpg"
                alt="AURA LUXE Penthouse Aesthetic Clinic Operatory"
                className="w-full h-[380px] sm:h-[440px] object-cover group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />

              {/* Scrim Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/90 via-neutral-950/30 to-transparent" />

              {/* Floating Frosted Glass Info Badge */}
              <div className="absolute bottom-4 left-4 right-4 p-4 sm:p-5 rounded-2xl apple-glass border border-white/15 text-white">
                <div className="flex items-center justify-between gap-2 text-xs text-neutral-300 mb-1">
                  <div className="flex items-center gap-1.5">
                    <span className="font-semibold text-white">
                      {isFa ? 'پنت‌هاوس لورا · سعادت‌آباد' : 'L’Aura Penthouse · Saadat Abad'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{isFa ? 'طبقه ۱۴ برج کاج' : 'Floor 14, Kaj Tower'}</span>
                  </div>
                  <span className="text-emerald-400 font-medium tabular-nums">
                    {isFa ? '۳ یونیت خالی' : '3 Slots Open'}
                  </span>
                </div>
                <div className="text-sm font-medium text-neutral-200">
                  {isFa
                    ? 'سوئیت‌های جراحی پوست مجهز به لیزر کندلا و فیلتراسیون فشار منفی'
                    : 'Aesthetic laser suites equipped with Candela GentleMax Pro & negative pressure'}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4-Column Proof & KPI Strip (Tabular discipline, single-elevation depth) */}
        <div className="mt-16 pt-10 border-t border-neutral-200 dark:border-white/10 grid grid-cols-2 md:grid-cols-4 gap-6 sm:gap-8">
          <div>
            <div className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-950 dark:text-white tabular-nums">
              {strings.stat1Value}
            </div>
            <div className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
              {strings.stat1Label}
            </div>
          </div>

          <div>
            <div className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-950 dark:text-white tabular-nums">
              {strings.stat2Value}
            </div>
            <div className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
              {strings.stat2Label}
            </div>
          </div>

          <div>
            <div className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-950 dark:text-white tabular-nums">
              {strings.stat3Value}
            </div>
            <div className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
              {strings.stat3Label}
            </div>
          </div>

          <div>
            <div className="text-2xl sm:text-3xl font-bold tracking-tight text-neutral-950 dark:text-white tabular-nums">
              {strings.stat4Value}
            </div>
            <div className="text-xs sm:text-sm text-neutral-500 dark:text-neutral-400 mt-1">
              {strings.stat4Label}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
