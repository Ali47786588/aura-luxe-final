import React from 'react';
import { Sparkles, Scissors, Smile, LayoutGrid } from 'lucide-react';
import { CategoryId, Language } from '../types';
import { t } from '../data/translations';

interface Props {
  selectedCategory: CategoryId;
  onSelectCategory: (cat: CategoryId) => void;
  lang: Language;
}

export const CategoryFilter: React.FC<Props> = ({
  selectedCategory,
  onSelectCategory,
  lang,
}) => {
  const strings = t(lang);

  const categories: { id: CategoryId; label: string; icon: React.ReactNode }[] = [
    {
      id: 'all',
      label: strings.catAll,
      icon: <LayoutGrid className="w-4 h-4" />,
    },
    {
      id: 'aesthetics',
      label: strings.navAesthetics,
      icon: <Sparkles className="w-4 h-4" />,
    },
    {
      id: 'salons',
      label: strings.navSalons,
      icon: <Scissors className="w-4 h-4" />,
    },
    {
      id: 'dental',
      label: strings.navDental,
      icon: <Smile className="w-4 h-4" />,
    },
  ];

  return (
    <div className="flex items-center justify-start overflow-x-auto py-2 no-scrollbar">
      <div className="inline-flex p-1.5 rounded-2xl bg-neutral-100 dark:bg-white/5 border border-neutral-200 dark:border-white/10 gap-1.5">
        {categories.map((cat) => {
          const isActive = selectedCategory === cat.id;

          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all duration-200 whitespace-nowrap shrink-0 ${
                isActive
                  ? 'bg-white text-neutral-950 dark:bg-neutral-800 dark:text-white shadow-sm border border-neutral-200 dark:border-white/15'
                  : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-200/50 dark:hover:bg-white/5'
              }`}
            >
              <span className={isActive ? 'text-neutral-950 dark:text-white' : 'text-neutral-400'}>
                {cat.icon}
              </span>
              <span>{cat.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
