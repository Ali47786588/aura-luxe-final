import React, { useState, useEffect, useRef, useCallback } from 'react';
import { 
  X, 
  Play, 
  Pause, 
  ChevronRight, 
  ChevronLeft, 
  Sparkles, 
  Stethoscope, 
  ArrowLeftRight, 
  CheckCircle2, 
  ShieldCheck, 
  Heart, 
  Volume2, 
  VolumeX, 
  Send, 
  SlidersHorizontal,
  Maximize2,
  Minimize2,
  Info
} from 'lucide-react';
import { StoryHighlight, StorySlide, Language } from '../types';
import { INITIAL_STORIES } from '../data/mockData';
import { t } from '../data/translations';

interface Props {
  lang: Language;
  onBookProcedure: (slide: StorySlide) => void;
  onSendStoryReply?: (doctorName: string, text: string) => void;
}

export const InstagramStoryGallery: React.FC<Props> = ({
  lang,
  onBookProcedure,
  onSendStoryReply,
}) => {
  const [highlights] = useState<StoryHighlight[]>(INITIAL_STORIES);
  const [activeHighlightIndex, setActiveHighlightIndex] = useState<number | null>(null);
  const [activeSlideIndex, setActiveSlideIndex] = useState<number>(0);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [sliderPosition, setSliderPosition] = useState<number>(50); // Split percentage: 0 to 100
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [replyText, setReplyText] = useState<string>('');
  const [isLiked, setIsLiked] = useState<boolean>(false);
  const [replySentNotice, setReplySentNotice] = useState<boolean>(false);
  const [hasInteracted, setHasInteracted] = useState<boolean>(false);
  const [containerWidth, setContainerWidth] = useState<number>(1000);

  const containerRef = useRef<HTMLDivElement>(null);
  const strings = t(lang);
  const isFa = lang === 'fa';

  const isStoryOpen = activeHighlightIndex !== null;
  const currentHighlight = isStoryOpen ? highlights[activeHighlightIndex] : null;
  const currentSlide: StorySlide | null =
    currentHighlight && currentHighlight.slides[activeSlideIndex]
      ? currentHighlight.slides[activeSlideIndex]
      : null;

  // Measure container width for accurate clipped image positioning
  useEffect(() => {
    if (!containerRef.current) return;
    const updateWidth = () => {
      if (containerRef.current) {
        setContainerWidth(containerRef.current.clientWidth);
      }
    };
    updateWidth();
    window.addEventListener('resize', updateWidth);
    return () => window.removeEventListener('resize', updateWidth);
  }, [isStoryOpen, activeSlideIndex]);

  // Auto-advancing timer for story slides with smooth 25ms steps
  useEffect(() => {
    if (!isStoryOpen || !currentSlide || isPaused || isDragging) return;

    const duration = (currentSlide.durationSeconds || 6) * 1000;
    const intervalMs = 25;
    const step = (intervalMs / duration) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          handleNextSlide();
          return 0;
        }
        return prev + step;
      });
    }, intervalMs);

    return () => clearInterval(timer);
  }, [isStoryOpen, activeSlideIndex, activeHighlightIndex, isPaused, isDragging, currentSlide]);

  const handleOpenHighlight = (index: number) => {
    setActiveHighlightIndex(index);
    setActiveSlideIndex(0);
    setProgress(0);
    setSliderPosition(50);
    setIsPaused(false);
    setIsLiked(false);
    setReplyText('');
    setReplySentNotice(false);
    setHasInteracted(false);
  };

  const handleCloseStory = () => {
    setActiveHighlightIndex(null);
    setProgress(0);
    setIsPaused(false);
    setIsLiked(false);
    setIsDragging(false);
  };

  const handleNextSlide = () => {
    if (!currentHighlight) return;
    if (activeSlideIndex < currentHighlight.slides.length - 1) {
      setActiveSlideIndex((prev) => prev + 1);
      setProgress(0);
      setSliderPosition(50);
      setIsLiked(false);
    } else {
      // Go to next highlight if available
      if (activeHighlightIndex !== null && activeHighlightIndex < highlights.length - 1) {
        setActiveHighlightIndex((prev) => (prev !== null ? prev + 1 : 0));
        setActiveSlideIndex(0);
        setProgress(0);
        setSliderPosition(50);
        setIsLiked(false);
      } else {
        handleCloseStory();
      }
    }
  };

  const handlePrevSlide = () => {
    if (!currentHighlight) return;
    if (activeSlideIndex > 0) {
      setActiveSlideIndex((prev) => prev - 1);
      setProgress(0);
      setSliderPosition(50);
      setIsLiked(false);
    } else if (activeHighlightIndex !== null && activeHighlightIndex > 0) {
      setActiveHighlightIndex((prev) => (prev !== null ? prev - 1 : 0));
      const prevHighlight = highlights[activeHighlightIndex - 1];
      setActiveSlideIndex(prevHighlight.slides.length - 1);
      setProgress(0);
      setSliderPosition(50);
      setIsLiked(false);
    }
  };

  // Draggable handle position calculation
  const updateSliderPosition = useCallback((clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    let percentage = (x / rect.width) * 100;
    if (percentage < 0) percentage = 0;
    if (percentage > 100) percentage = 100;
    setSliderPosition(percentage);
  }, []);

  const handlePointerDown = (e: React.PointerEvent) => {
    setIsDragging(true);
    setIsPaused(true);
    setHasInteracted(true);
    updateSliderPosition(e.clientX);
    (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId);
  };

  const handlePointerMove = (e: React.PointerEvent) => {
    if (!isDragging) return;
    updateSliderPosition(e.clientX);
  };

  const handlePointerUp = (e: React.PointerEvent) => {
    setIsDragging(false);
    try {
      (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId);
    } catch (err) {}
  };

  // Keyboard navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (!isStoryOpen) return;
      if (e.key === 'Escape') handleCloseStory();
      if (e.key === 'ArrowRight') isFa ? handlePrevSlide() : handleNextSlide();
      if (e.key === 'ArrowLeft') isFa ? handleNextSlide() : handlePrevSlide();
      if (e.key === ' ') {
        e.preventDefault();
        setIsPaused((p) => !p);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isStoryOpen, activeHighlightIndex, activeSlideIndex, isFa]);

  const handleSendReply = (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim() || !currentSlide) return;
    if (onSendStoryReply) {
      onSendStoryReply(isFa ? currentSlide.doctorNameFa : currentSlide.doctorNameEn, replyText);
    }
    setReplyText('');
    setReplySentNotice(true);
    setTimeout(() => setReplySentNotice(false), 2500);
  };

  // Determine fallback before filter if slide has 'none'
  const effectiveBeforeFilter = currentSlide && currentSlide.beforeFilter !== 'none'
    ? currentSlide.beforeFilter
    : 'contrast(0.9) brightness(0.88) sepia(0.25) saturate(0.85)';

  return (
    <div className="space-y-6">
      {/* Section Sub-header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-[#E5C378] mb-1">
            <Sparkles className="w-3.5 h-3.5 text-[#E5C378]" />
            <span>{isFa ? 'هایلایت‌های استوری اینستاگرام و نمونه‌کارهای بالینی' : 'CLINICAL CASE STORY HIGHLIGHTS'}</span>
          </div>
          <h3 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
            {isFa ? 'استوری نمونه‌کارها و اسلایدر قبل و بعد' : 'Instagram-Style Stories & Before/After Showcase'}
          </h3>
        </div>
        <span className="text-xs text-[#E5C378] bg-[#E5C378]/10 border border-[#E5C378]/25 px-3 py-1 rounded-full self-start sm:self-auto font-medium">
          {isFa ? 'روی دایره‌ها کلیک کنید تا اسلایدر تمام‌صفحه باز شود' : 'Tap highlights to open fullscreen comparison'}
        </span>
      </div>

      {/* INSTAGRAM-STYLE STORY HIGHLIGHT CIRCLES */}
      <div className="flex items-center gap-5 sm:gap-8 overflow-x-auto py-3 no-scrollbar scroll-smooth">
        {highlights.map((highlight, idx) => (
          <button
            key={highlight.id}
            onClick={() => handleOpenHighlight(idx)}
            className="flex flex-col items-center gap-2.5 shrink-0 group focus:outline-none cursor-pointer"
          >
            {/* Glowing Champagne Gold Story Ring */}
            <div className="relative p-[3px] rounded-full bg-gradient-to-tr from-[#E5C378] via-[#FFE58F] to-[#B8860B] shadow-lg shadow-amber-500/20 group-hover:shadow-amber-500/40 group-hover:scale-105 transition-all duration-300">
              {/* Inner Dark Separation Border */}
              <div className="p-0.5 rounded-full bg-[#0A0A0C]">
                <div className="w-18 h-18 sm:w-22 sm:h-22 rounded-full overflow-hidden bg-neutral-900">
                  <img
                    src={highlight.coverImage}
                    alt={isFa ? highlight.titleFa : highlight.titleEn}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                </div>
              </div>

              {/* Unread Active Story Indicator Dot */}
              <span className="absolute bottom-1 right-1 rtl:right-auto rtl:left-1 w-3.5 h-3.5 rounded-full bg-[#E5C378] border-2 border-[#0A0A0C] shadow-md flex items-center justify-center">
                <span className="w-1.5 h-1.5 rounded-full bg-neutral-950" />
              </span>
            </div>

            {/* Title & Slide Count */}
            <div className="text-center">
              <span className="text-xs font-bold text-neutral-200 group-hover:text-[#E5C378] transition-colors block">
                {isFa ? highlight.titleFa : highlight.titleEn}
              </span>
              <span className="text-[10px] font-mono text-neutral-400">
                {isFa ? `${highlight.slides.length} استوری` : `${highlight.slides.length} slides`}
              </span>
            </div>
          </button>
        ))}
      </div>

      {/* FULLSCREEN IMMERSIVE STORY VIEWER MODAL WITH BEFORE & AFTER DRAGGABLE HANDLE */}
      {isStoryOpen && currentHighlight && currentSlide && (
        <div className="fixed inset-0 z-50 flex flex-col justify-between bg-black/95 backdrop-blur-2xl p-0 sm:p-4 animate-in fade-in duration-200 overflow-hidden select-none">
          
          {/* Top Bar: Progress Segments, Doctor Info & Controls */}
          <div className="relative z-30 max-w-5xl w-full mx-auto p-4 sm:p-5 flex flex-col gap-3">
            
            {/* 1. Instagram Story Progress Bars */}
            <div className="flex items-center gap-1.5 w-full">
              {currentHighlight.slides.map((slide, sIdx) => {
                let barWidth = '0%';
                if (sIdx < activeSlideIndex) barWidth = '100%';
                else if (sIdx === activeSlideIndex) barWidth = `${progress}%`;

                return (
                  <button
                    key={slide.id}
                    onClick={() => {
                      setActiveSlideIndex(sIdx);
                      setProgress(0);
                      setSliderPosition(50);
                    }}
                    className="flex-1 h-1.5 bg-white/20 hover:bg-white/30 rounded-full overflow-hidden transition-all cursor-pointer"
                  >
                    <div
                      className="h-full bg-gradient-to-r from-[#E5C378] to-[#FFE58F] transition-all duration-75"
                      style={{ width: barWidth }}
                    />
                  </button>
                );
              })}
            </div>

            {/* 2. Doctor / Clinic Metadata Bar & Controls */}
            <div className="flex items-center justify-between text-white">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full overflow-hidden border border-[#E5C378] p-0.5 bg-neutral-900 shrink-0">
                  <img
                    src={currentHighlight.coverImage}
                    alt=""
                    className="w-full h-full object-cover rounded-full"
                  />
                </div>
                <div>
                  <div className="text-sm font-bold flex items-center gap-1.5 text-white">
                    <span>{isFa ? currentSlide.doctorNameFa : currentSlide.doctorNameEn}</span>
                    <ShieldCheck className="w-4 h-4 text-[#E5C378]" />
                  </div>
                  <div className="text-xs text-neutral-400">
                    {isFa ? currentSlide.clinicNameFa : currentSlide.clinicNameEn}
                  </div>
                </div>
              </div>

              {/* Right Controls: Play/Pause and Close Button */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsPaused((p) => !p)}
                  className="p-2 rounded-full bg-neutral-900/80 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-white/10 transition-colors"
                  title={isPaused ? 'Play' : 'Pause'}
                >
                  {isPaused ? <Play className="w-4 h-4 fill-white text-white" /> : <Pause className="w-4 h-4 fill-white text-white" />}
                </button>

                <button
                  onClick={handleCloseStory}
                  className="p-2 rounded-full bg-neutral-900/80 hover:bg-neutral-800 text-neutral-300 hover:text-white border border-white/10 transition-colors cursor-pointer"
                  aria-label="Close Story"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          {/* MAIN FULLSCREEN COMPARISON CANVAS WITH DRAGGABLE HANDLE */}
          <div className="relative flex-1 max-w-5xl w-full mx-auto px-2 sm:px-4 flex items-center justify-center overflow-hidden">
            
            {/* The Before & After Interactive Container */}
            <div
              ref={containerRef}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              className="relative w-full h-[58vh] sm:h-[68vh] rounded-3xl overflow-hidden bg-neutral-950 border border-[#E5C378]/30 shadow-2xl cursor-ew-resize select-none touch-none"
            >
              {/* Layer 1: AFTER IMAGE (Full background) */}
              <img
                src={currentSlide.image}
                alt="After Transformation"
                className="absolute inset-0 w-full h-full object-cover pointer-events-none"
                referrerPolicy="no-referrer"
              />

              {/* Layer 2: BEFORE IMAGE (Clipped with percentage width & clinical filter) */}
              <div
                className="absolute inset-0 overflow-hidden pointer-events-none transition-none"
                style={{ width: `${sliderPosition}%` }}
              >
                <img
                  src={currentSlide.image}
                  alt="Before Transformation"
                  className="absolute inset-0 w-full h-full object-cover max-w-none pointer-events-none"
                  style={{
                    width: `${containerWidth}px`,
                    height: '100%',
                    filter: effectiveBeforeFilter,
                  }}
                  referrerPolicy="no-referrer"
                />
              </div>

              {/* FLOATING LABELS: BEFORE & AFTER */}
              <div className="absolute top-4 left-4 z-20 px-3 py-1 rounded-xl bg-black/75 backdrop-blur-md text-[11px] font-bold text-neutral-300 border border-white/20 pointer-events-none shadow-lg tracking-wider">
                {isFa ? 'قبل از درمان (BEFORE)' : 'BEFORE'}
              </div>
              <div className="absolute top-4 right-4 z-20 px-3 py-1 rounded-xl bg-[#14161F]/85 backdrop-blur-md text-[11px] font-bold text-[#E5C378] border border-[#E5C378]/40 pointer-events-none shadow-lg tracking-wider">
                {isFa ? 'نتیجه نهایی (AFTER)' : 'AFTER'}
              </div>

              {/* VERTICAL DIVIDER LINE & DRAGGABLE HANDLE (دستگیره کشیدنی) */}
              <div
                className="absolute top-0 bottom-0 w-1 bg-gradient-to-b from-[#E5C378] via-[#FFE58F] to-[#C5A059] shadow-[0_0_20px_rgba(229,195,120,0.8)] pointer-events-none flex items-center justify-center z-20"
                style={{ left: `${sliderPosition}%` }}
              >
                {/* Tactical Draggable Thumb */}
                <div className="w-12 h-12 rounded-full bg-[#11131A] border-2 border-[#E5C378] shadow-2xl flex flex-col items-center justify-center text-[#E5C378] -translate-x-1/2 pointer-events-auto cursor-ew-resize active:scale-110 hover:scale-105 transition-transform duration-150">
                  <ArrowLeftRight className="w-5 h-5 text-[#E5C378]" />
                  <span className="text-[8px] font-mono font-bold text-neutral-300 mt-0.5">
                    {Math.round(sliderPosition)}%
                  </span>
                </div>
              </div>

              {/* Floating Drag Hint Prompt (Auto-fades after user starts dragging) */}
              {!hasInteracted && (
                <div className="absolute bottom-5 inset-x-0 mx-auto w-fit z-20 px-4 py-1.5 rounded-full bg-black/80 backdrop-blur-md text-xs text-amber-200 border border-amber-400/30 flex items-center gap-2 pointer-events-none animate-pulse">
                  <ArrowLeftRight className="w-4 h-4 text-[#E5C378]" />
                  <span>{isFa ? 'دستگیره را به چپ و راست بکشید تا مقایسه کنید' : 'Drag the handle left/right to compare'}</span>
                </div>
              )}

              {/* Left & Right Slide Navigation Arrows */}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handlePrevSlide();
                }}
                className="absolute top-1/2 -translate-y-1/2 left-3 z-30 p-2.5 rounded-full bg-black/60 hover:bg-black/90 text-white border border-white/20 transition-all opacity-70 hover:opacity-100 cursor-pointer"
                title={isFa ? 'اسلاید قبلی' : 'Previous slide'}
              >
                <ChevronLeft className="w-5 h-5" />
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  handleNextSlide();
                }}
                className="absolute top-1/2 -translate-y-1/2 right-3 z-30 p-2.5 rounded-full bg-black/60 hover:bg-black/90 text-white border border-white/20 transition-all opacity-70 hover:opacity-100 cursor-pointer"
                title={isFa ? 'اسلاید بعدی' : 'Next slide'}
              >
                <ChevronRight className="w-5 h-5" />
              </button>

            </div>
          </div>

          {/* Bottom Bar: Case Description, Reply Field & Booking CTA */}
          <div className="relative z-30 max-w-5xl w-full mx-auto p-4 sm:p-5 bg-gradient-to-t from-black via-black/90 to-transparent space-y-3">
            
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
              <div>
                <span className="inline-block px-3 py-0.5 rounded-full text-[11px] font-semibold bg-[#E5C378]/15 text-[#E5C378] border border-[#E5C378]/30 mb-1">
                  {isFa ? currentSlide.clinicalTagFa : currentSlide.clinicalTagEn}
                </span>
                <h4 className="text-base sm:text-lg font-bold text-white leading-snug">
                  {isFa ? currentSlide.titleFa : currentSlide.titleEn}
                </h4>
                <p className="text-xs text-neutral-300 mt-1 max-w-2xl leading-relaxed">
                  {isFa ? currentSlide.treatmentDetailsFa : currentSlide.treatmentDetailsEn}
                </p>
              </div>

              {/* Action Button: Book this procedure */}
              <button
                onClick={() => {
                  handleCloseStory();
                  onBookProcedure(currentSlide);
                }}
                className="py-3 px-6 rounded-2xl text-xs sm:text-sm font-bold bg-gradient-to-r from-[#E5C378] via-[#FFE58F] to-[#C5A059] text-neutral-950 hover:opacity-95 transition-all shadow-lg shadow-amber-500/20 flex items-center justify-center gap-2 cursor-pointer self-start sm:self-center shrink-0"
              >
                <Sparkles className="w-4 h-4 text-neutral-950" />
                <span>{isFa ? 'رزرو یونیت برای این پروسیجر' : 'Book Operatory for Procedure'}</span>
              </button>
            </div>

            {/* Doctor Direct Inquiry Bar & Heart Reaction */}
            <form onSubmit={handleSendReply} className="flex items-center gap-2.5 pt-1">
              <input
                type="text"
                value={replyText}
                onChange={(e) => setReplyText(e.target.value)}
                placeholder={isFa ? 'ارسال پیام مستقیم به پزشک معالج...' : 'Send inquiry to doctor...'}
                className="flex-1 py-2.5 px-4 rounded-full bg-white/10 border border-white/15 text-white placeholder-neutral-400 text-xs focus:outline-none focus:border-[#E5C378]"
              />
              <button
                type="submit"
                disabled={!replyText.trim()}
                className="p-2.5 rounded-full bg-[#E5C378] hover:bg-[#FFE58F] text-neutral-950 disabled:opacity-40 transition-colors cursor-pointer"
              >
                <Send className="w-4 h-4 rtl:rotate-180" />
              </button>
              <button
                type="button"
                onClick={() => setIsLiked((l) => !l)}
                className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 transition-colors cursor-pointer"
              >
                <Heart className={`w-4 h-4 ${isLiked ? 'fill-red-500 text-red-500' : 'text-white'}`} />
              </button>
            </form>

            {replySentNotice && (
              <div className="text-xs text-[#E5C378] text-center font-medium animate-fadeIn">
                {isFa ? 'پیام شما به کادر پزشک ارسال گردید' : 'Inquiry delivered to clinical team'}
              </div>
            )}

          </div>

        </div>
      )}
    </div>
  );
};
