import React, { useState } from 'react';
import { X, CheckCircle2, Building2, Stethoscope, Scissors, Sparkles, UserCheck, MapPin, Phone, Hash, FileText, Check } from 'lucide-react';
import { Language, OnboardingApplication, PartnerActivityType } from '../types';
import { t, formatPersianNumber } from '../data/translations';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  onSubmitApplication: (app: OnboardingApplication) => void;
}

export const OnboardingModal: React.FC<Props> = ({
  isOpen,
  onClose,
  lang,
  onSubmitApplication,
}) => {
  const strings = t(lang);
  const isFa = lang === 'fa';

  const [activityType, setActivityType] = useState<PartnerActivityType>('skin_clinic');
  const [businessOrDoctorName, setBusinessOrDoctorName] = useState<string>('');
  const [cityAndDistrict, setCityAndDistrict] = useState<string>('تهران - سعادت‌آباد');
  const [phoneNumber, setPhoneNumber] = useState<string>('');
  const [availableChairsCount, setAvailableChairsCount] = useState<number>(2);
  const [shortDescription, setShortDescription] = useState<string>('');
  const [isSuccess, setIsSuccess] = useState<boolean>(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  if (!isOpen) return null;

  const activityOptions: { id: PartnerActivityType; labelFa: string; labelEn: string; subFa: string; subEn: string; icon: React.FC<{ className?: string }> }[] = [
    {
      id: 'skin_clinic',
      labelFa: 'کلینیک پوست',
      labelEn: 'Skin Clinic',
      subFa: 'لیزر، جوانسازی و تزریقات',
      subEn: 'Aesthetics & Laser',
      icon: Sparkles,
    },
    {
      id: 'dental',
      labelFa: 'دندان',
      labelEn: 'Dental',
      subFa: 'طراحی لبخند و جراحی',
      subEn: 'Smile Design & Surgery',
      icon: Stethoscope,
    },
    {
      id: 'salon',
      labelFa: 'سالن زیبایی',
      labelEn: 'Beauty Salon',
      subFa: 'مستر استایلینگ و رنگ',
      subEn: 'Master Hair & Beauty',
      icon: Scissors,
    },
    {
      id: 'independent_doctor',
      labelFa: 'پزشک مستقل',
      labelEn: 'Independent Doctor',
      subFa: 'اجاره ساعتی و پذیرش بیمار',
      subEn: 'Specialist Practitioner',
      icon: UserCheck,
    },
  ];

  const quickDistricts = [
    'تهران - سعادت‌آباد',
    'تهران - الهیه / فرشته',
    'تهران - زعفرانیه',
    'تهران - ونک',
    'کرج - گوهردشت',
    'کرج - فردیس',
  ];

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!businessOrDoctorName.trim()) {
      errs.name = isFa ? 'نام مرکز یا پزشک الزامی است' : 'Facility or Doctor name is required';
    }
    if (!cityAndDistrict.trim()) {
      errs.cityAndDistrict = isFa ? 'شهر و منطقه الزامی است' : 'City and district are required';
    }
    if (!phoneNumber.trim() || phoneNumber.length < 10) {
      errs.phone = isFa ? 'شماره تماس معتبر (۱۱ رقم) الزامی است' : 'Valid phone number is required';
    }
    if (availableChairsCount < 1) {
      errs.chairs = isFa ? 'حداقل ۱ صندلی یا تخت الزامی است' : 'At least 1 chair/bed is required';
    }
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const selectedOption = activityOptions.find((o) => o.id === activityType);

    const newApp: OnboardingApplication = {
      id: `app_${Date.now()}`,
      applicantType: activityType === 'independent_doctor' ? 'doctor' : activityType === 'salon' ? 'salon' : 'clinic',
      activityType,
      activityTypeFa: selectedOption?.labelFa,
      businessName: businessOrDoctorName.trim(),
      businessOrDoctorName: businessOrDoctorName.trim(),
      applicantName: businessOrDoctorName.trim(),
      cityAndDistrict: cityAndDistrict.trim(),
      district: cityAndDistrict.trim(),
      phoneNumber: phoneNumber.trim(),
      chairsOrBedsCount: availableChairsCount,
      availableChairsCount,
      shortDescription: shortDescription.trim(),
      primaryEquipment: shortDescription.trim() || 'تجهیزات استاندارد بهداشتی',
      status: 'pending',
      submittedAt: isFa ? 'هم‌اکنون' : 'Just now',
    };

    onSubmitApplication(newApp);
    setIsSuccess(true);
  };

  const handleResetAndClose = () => {
    setIsSuccess(false);
    setBusinessOrDoctorName('');
    setPhoneNumber('');
    setShortDescription('');
    setErrors({});
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity"
        onClick={() => {
          if (!isSuccess) onClose();
        }}
      />

      {/* Modal Dialog */}
      <div className="relative w-full max-w-xl rounded-3xl bg-neutral-900/95 border border-neutral-700/60 p-6 sm:p-8 shadow-2xl text-neutral-100 z-10 my-6 overflow-hidden">
        {/* Subtle Ambient Gold Glow */}
        <div className="absolute top-0 right-1/4 w-48 h-48 bg-amber-400/10 rounded-full blur-3xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={handleResetAndClose}
          className="absolute top-5 left-5 rtl:left-auto rtl:right-5 p-2 rounded-full bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {!isSuccess ? (
          <div>
            {/* Header */}
            <div className="mb-6 pb-4 border-b border-neutral-800">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-300 text-[11px] font-mono uppercase tracking-wider mb-2">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>{isFa ? 'عضویت همکاران و کلینیک‌ها' : 'PARTNER ONBOARDING'}</span>
              </div>
              <h2 className="text-xl sm:text-2xl font-bold tracking-tight text-white">
                {isFa ? 'ثبت‌نام مرکز یا پزشک' : 'Register Center or Doctor'}
              </h2>
              <p className="text-xs sm:text-sm text-neutral-400 mt-1 leading-relaxed">
                {isFa
                  ? 'اطلاعات مجموعه یا مطب خود را وارد کنید تا پس از بررسی اولیه، پنل مدیریت برای شما فعال گردد.'
                  : 'Submit your clinical facility or private practice details to join the luxury operatory network.'}
              </p>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} className="space-y-4 sm:space-y-5">
              {/* Field 1: نوع فعالیت */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-2">
                  {isFa ? 'نوع فعالیت:' : 'Activity Type:'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {activityOptions.map((opt) => {
                    const Icon = opt.icon;
                    const isSelected = activityType === opt.id;
                    return (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setActivityType(opt.id)}
                        className={`p-3 rounded-2xl border text-center transition-all flex flex-col items-center justify-center gap-1.5 ${
                          isSelected
                            ? 'bg-neutral-800 border-amber-400 text-white shadow-md ring-1 ring-amber-400/50'
                            : 'bg-white/5 border-neutral-800 hover:bg-white/10 text-neutral-400 hover:text-neutral-200'
                        }`}
                      >
                        <Icon className={`w-4 h-4 ${isSelected ? 'text-amber-300' : 'text-neutral-400'}`} />
                        <span className="text-xs font-bold leading-tight">
                          {isFa ? opt.labelFa : opt.labelEn}
                        </span>
                        <span className="text-[10px] text-neutral-500 leading-tight">
                          {isFa ? opt.subFa : opt.subEn}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Field 2: نام مرکز یا پزشک */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {isFa ? 'نام مرکز یا پزشک:' : 'Facility or Doctor Name:'}
                </label>
                <div className="relative">
                  <Building2 className="w-4 h-4 absolute top-3.5 right-3.5 rtl:right-3.5 rtl:left-auto text-neutral-500 pointer-events-none" />
                  <input
                    type="text"
                    value={businessOrDoctorName}
                    onChange={(e) => setBusinessOrDoctorName(e.target.value)}
                    placeholder={
                      activityType === 'independent_doctor'
                        ? (isFa ? 'مثال: دکتر آرش نامدار (متخصص پوست و مو)' : 'e.g. Dr. Arash Namdar')
                        : activityType === 'dental'
                        ? (isFa ? 'مثال: کلینیک تخصصی دندانپزشکی رویال' : 'e.g. Royal Dental Studio')
                        : activityType === 'salon'
                        ? (isFa ? 'مثال: سالن زیبایی و مستر استایلینگ پرستیژ' : 'e.g. Prestige Hair Lounge')
                        : (isFa ? 'مثال: کلینیک تخصصی پوست و لیزر سعادت‌آباد' : 'e.g. Saadat Abad Aesthetic Clinic')
                    }
                    className="w-full pr-10 pl-3 py-2.5 sm:py-3 rounded-xl bg-neutral-950/70 border border-neutral-800 text-white text-xs sm:text-sm placeholder:text-neutral-600 focus:outline-none focus:border-amber-400/70 focus:ring-1 focus:ring-amber-400/40 transition-colors"
                  />
                </div>
                {errors.name && <p className="text-[11px] text-red-400 mt-1">{errors.name}</p>}
              </div>

              {/* Field 3: شهر و منطقه */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {isFa ? 'شهر و منطقه:' : 'City & District:'}
                </label>
                <div className="relative">
                  <MapPin className="w-4 h-4 absolute top-3.5 right-3.5 text-neutral-500 pointer-events-none" />
                  <input
                    type="text"
                    value={cityAndDistrict}
                    onChange={(e) => setCityAndDistrict(e.target.value)}
                    placeholder={isFa ? 'مثال: تهران - سعادت‌آباد، خیابان علامه' : 'e.g. Tehran - Saadat Abad'}
                    className="w-full pr-10 pl-3 py-2.5 sm:py-3 rounded-xl bg-neutral-950/70 border border-neutral-800 text-white text-xs sm:text-sm placeholder:text-neutral-600 focus:outline-none focus:border-amber-400/70 focus:ring-1 focus:ring-amber-400/40 transition-colors"
                  />
                </div>
                {/* Quick District suggestions */}
                <div className="flex flex-wrap items-center gap-1.5 mt-2">
                  <span className="text-[10px] text-neutral-500">{isFa ? 'پیشنهاد:' : 'Quick:'}</span>
                  {quickDistricts.map((d) => (
                    <button
                      key={d}
                      type="button"
                      onClick={() => setCityAndDistrict(d)}
                      className={`text-[10px] px-2 py-0.5 rounded-lg border transition-colors ${
                        cityAndDistrict === d
                          ? 'bg-amber-400/20 text-amber-300 border-amber-400/40'
                          : 'bg-white/5 text-neutral-400 border-neutral-800 hover:text-neutral-200'
                      }`}
                    >
                      {d}
                    </button>
                  ))}
                </div>
                {errors.cityAndDistrict && <p className="text-[11px] text-red-400 mt-1">{errors.cityAndDistrict}</p>}
              </div>

              {/* Grid: Field 4 (شماره تماس) & Field 5 (تعداد تخت یا صندلی خالی) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Field 4: شماره تماس */}
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isFa ? 'شماره تماس:' : 'Contact Phone Number:'}
                  </label>
                  <div className="relative">
                    <Phone className="w-4 h-4 absolute top-3.5 right-3.5 text-neutral-500 pointer-events-none" />
                    <input
                      type="tel"
                      dir="ltr"
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="09121234567"
                      className="w-full pr-10 pl-3 py-2.5 sm:py-3 rounded-xl bg-neutral-950/70 border border-neutral-800 text-white font-mono text-xs sm:text-sm placeholder:text-neutral-600 focus:outline-none focus:border-amber-400/70 focus:ring-1 focus:ring-amber-400/40 transition-colors text-right"
                    />
                  </div>
                  {errors.phone && <p className="text-[11px] text-red-400 mt-1">{errors.phone}</p>}
                </div>

                {/* Field 5: تعداد تخت یا صندلی خالی */}
                <div>
                  <label className="block text-xs font-semibold text-neutral-300 mb-1">
                    {isFa ? 'تعداد تخت یا صندلی خالی:' : 'Available Chairs / Beds:'}
                  </label>
                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => setAvailableChairsCount((prev) => Math.max(1, prev - 1))}
                      className="w-11 h-11 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-lg flex items-center justify-center transition-colors"
                    >
                      -
                    </button>
                    <div className="flex-1 py-2.5 px-3 rounded-xl bg-neutral-950/70 border border-neutral-800 text-center text-white font-bold text-base tabular-nums flex items-center justify-center gap-1.5">
                      <Hash className="w-4 h-4 text-amber-400" />
                      <span>{formatPersianNumber(availableChairsCount, lang)}</span>
                      <span className="text-xs text-neutral-400 font-normal">{isFa ? 'تخت / یونیت' : 'units'}</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => setAvailableChairsCount((prev) => Math.min(25, prev + 1))}
                      className="w-11 h-11 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold text-lg flex items-center justify-center transition-colors"
                    >
                      +
                    </button>
                  </div>
                  {errors.chairs && <p className="text-[11px] text-red-400 mt-1">{errors.chairs}</p>}
                </div>
              </div>

              {/* Field 6: توضیحات کوتاه */}
              <div>
                <label className="block text-xs font-semibold text-neutral-300 mb-1">
                  {isFa ? 'توضیحات کوتاه:' : 'Short Description:'}
                </label>
                <div className="relative">
                  <FileText className="w-4 h-4 absolute top-3.5 right-3.5 text-neutral-500 pointer-events-none" />
                  <textarea
                    rows={3}
                    value={shortDescription}
                    onChange={(e) => setShortDescription(e.target.value)}
                    placeholder={
                      isFa
                        ? 'توضیح کوتاه درباره تجهیزات کلیدی (دستگاه لیزر، یونیت، اتوکلاو)، شیفت‌های مورد نظر یا شرایط همکاری...'
                        : 'Brief info about key equipment, available shifts, sterilizers or collaboration terms...'
                    }
                    className="w-full pr-10 pl-3 py-2.5 rounded-xl bg-neutral-950/70 border border-neutral-800 text-white text-xs sm:text-sm placeholder:text-neutral-600 focus:outline-none focus:border-amber-400/70 focus:ring-1 focus:ring-amber-400/40 transition-colors leading-relaxed"
                  />
                </div>
              </div>

              {/* Submit CTA */}
              <div className="pt-2">
                <button
                  type="submit"
                  className="w-full py-3.5 rounded-2xl text-xs sm:text-sm font-bold bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 hover:opacity-95 transition-all shadow-lg flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Sparkles className="w-4 h-4 text-neutral-900" />
                  <span>{isFa ? 'ارسال درخواست ثبت‌نام' : 'Submit Registration Application'}</span>
                </button>
              </div>
            </form>
          </div>
        ) : (
          /* Submission Success Screen */
          <div className="text-center py-6 sm:py-8 space-y-5 animate-fadeIn">
            {/* Elegant Checkmark Badge */}
            <div className="w-18 h-18 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 mx-auto flex items-center justify-center shadow-lg ring-8 ring-emerald-500/5">
              <CheckCircle2 className="w-10 h-10" />
            </div>

            {/* Exactly the requested message */}
            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-300 text-xs font-semibold">
                <Check className="w-3.5 h-3.5 text-amber-300" />
                <span>{isFa ? 'ثبت اولیه موفقیت‌آمیز' : 'Application Received'}</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
                {isFa ? 'درخواست شما ثبت شد و در حال بررسی است' : 'Your request has been registered and is under review'}
              </h3>
              <p className="text-xs sm:text-sm text-neutral-400 max-w-md mx-auto leading-relaxed pt-1">
                {isFa
                  ? `کارشناسان فنی اورا لوکس حداکثر ظرف ۲ ساعت کاری با شماره «${phoneNumber}» تماس حاصل خواهند کرد تا پس از احراز اولیه، پنل مدیریت برای شما فعال گردد.`
                  : `Our team will review your application for "${businessOrDoctorName}" and reach out to "${phoneNumber}" to activate your management portal.`}
              </p>
            </div>

            {/* Application Summary Card */}
            <div className="p-4 rounded-2xl bg-neutral-950/80 border border-neutral-800/80 text-right text-xs space-y-2 max-w-md mx-auto">
              <div className="flex justify-between items-center text-neutral-400 border-b border-neutral-800 pb-2">
                <span>{isFa ? 'نوع فعالیت:' : 'Activity Type:'}</span>
                <span className="font-bold text-white">
                  {activityOptions.find((o) => o.id === activityType)?.labelFa}
                </span>
              </div>
              <div className="flex justify-between items-center text-neutral-400 border-b border-neutral-800 pb-2">
                <span>{isFa ? 'نام مرکز / پزشک:' : 'Name:'}</span>
                <span className="font-bold text-amber-300">{businessOrDoctorName}</span>
              </div>
              <div className="flex justify-between items-center text-neutral-400 border-b border-neutral-800 pb-2">
                <span>{isFa ? 'شهر و منطقه:' : 'Location:'}</span>
                <span className="text-neutral-200">{cityAndDistrict}</span>
              </div>
              <div className="flex justify-between items-center text-neutral-400 border-b border-neutral-800 pb-2">
                <span>{isFa ? 'شماره تماس:' : 'Contact:'}</span>
                <span className="font-mono text-neutral-200">{phoneNumber}</span>
              </div>
              <div className="flex justify-between items-center text-neutral-400">
                <span>{isFa ? 'ظرفیت صندلی/تخت:' : 'Available Units:'}</span>
                <span className="font-bold text-emerald-400">
                  {formatPersianNumber(availableChairsCount, lang)} {isFa ? 'تخت / صندلی' : 'units'}
                </span>
              </div>
            </div>

            <div className="pt-2">
              <button
                type="button"
                onClick={handleResetAndClose}
                className="px-8 py-3 rounded-2xl text-xs sm:text-sm font-bold bg-neutral-100 hover:bg-white text-neutral-950 transition-colors shadow-md"
              >
                {isFa ? 'بستن پنجره' : 'Close'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
