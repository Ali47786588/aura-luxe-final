import React from 'react';
import { ShieldCheck, MapPin, Star, Clock, Check, ChevronRight, ChevronLeft } from 'lucide-react';
import { Venue, Language } from '../types';
import { t, formatPrice, formatPersianNumber } from '../data/translations';

interface Props {
  venue: Venue;
  lang: Language;
  onViewDetails: (venue: Venue) => void;
  onBookVenue: (venue: Venue) => void;
}

export const VenueCard: React.FC<Props> = ({
  venue,
  lang,
  onViewDetails,
  onBookVenue,
}) => {
  const strings = t(lang);
  const isFa = lang === 'fa';
  const ChevronIcon = isFa ? ChevronLeft : ChevronRight;

  const categoryLabel =
    venue.category === 'aesthetics'
      ? strings.navAesthetics
      : venue.category === 'dental'
      ? strings.navDental
      : strings.navSalons;

  return (
    <div className="group rounded-3xl overflow-hidden border border-neutral-200 dark:border-white/10 bg-white dark:bg-neutral-900/60 transition-all duration-300 hover:shadow-xl hover:border-neutral-300 dark:hover:border-white/20 flex flex-col">
      {/* Visual Header */}
      <div className="relative aspect-[16/10] overflow-hidden bg-neutral-900">
        <img
          src={venue.image}
          alt={isFa ? venue.nameFa : venue.nameEn}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />

        {/* Top Floating Badges (Subtle frosted glass) */}
        <div className="absolute top-3 inset-x-3 flex items-center justify-between text-xs">
          <div className="apple-glass px-2.5 py-1 rounded-xl text-neutral-100 font-medium border border-white/15">
            {isFa ? venue.districtNameFa : venue.districtNameEn}
          </div>

          <div className="apple-glass px-2.5 py-1 rounded-xl text-emerald-300 font-medium border border-white/15 flex items-center gap-1 tabular-nums">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            <span>
              {formatPersianNumber(venue.activeSlots, lang)} {strings.availableNow}
            </span>
          </div>
        </div>

        {/* Scrim Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-neutral-950/70 via-transparent to-transparent pointer-events-none" />

        {/* Category & Rating on Image base */}
        <div className="absolute bottom-3 inset-x-3 flex items-center justify-between text-xs text-white">
          <span className="font-semibold tracking-wider uppercase text-[11px] text-neutral-300">
            {categoryLabel}
          </span>
          <div className="flex items-center gap-1 text-white font-semibold">
            <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
            <span className="tabular-nums">{venue.rating}</span>
            <span className="text-neutral-400 text-[11px]">
              ({formatPersianNumber(venue.reviewCount, lang)})
            </span>
          </div>
        </div>
      </div>

      {/* Body Content */}
      <div className="p-5 sm:p-6 flex-1 flex flex-col justify-between space-y-4">
        <div>
          <div className="flex items-start justify-between gap-2">
            <h3 className="text-lg font-bold text-neutral-900 dark:text-white group-hover:text-neutral-600 dark:group-hover:text-neutral-300 transition-colors">
              {isFa ? venue.nameFa : venue.nameEn}
            </h3>
            {venue.escrowVerified && (
              <span
                className="shrink-0 text-emerald-600 dark:text-emerald-400"
                title={isFa ? 'تایید شده با ضمانت امانی' : 'Escrow Verified'}
              >
                <ShieldCheck className="w-4 h-4" />
              </span>
            )}
          </div>

          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1 line-clamp-2 leading-relaxed">
            {isFa ? venue.taglineFa : venue.taglineEn}
          </p>

          {/* Clean unboxed equipment list with bullet separators */}
          <div className="mt-4 pt-3 border-t border-neutral-100 dark:border-white/5">
            <div className="text-[11px] text-neutral-400 dark:text-neutral-500 font-medium mb-1.5 uppercase tracking-wider">
              {isFa ? 'تجهیزات تخصصی مستقر:' : 'Featured Clinical Tech:'}
            </div>
            <div className="text-xs text-neutral-600 dark:text-neutral-300 line-clamp-1">
              {venue.equipmentList.slice(0, 2).join(' · ')}
            </div>
          </div>
        </div>

        {/* Footer: Price & Actions */}
        <div className="pt-3 border-t border-neutral-100 dark:border-white/5 flex items-center justify-between gap-3">
          <div>
            <div className="text-[11px] text-neutral-400">{strings.hourlyRate}</div>
            <div className="text-sm sm:text-base font-bold text-neutral-900 dark:text-white tabular-nums">
              {formatPrice(venue.baseHourlyToman, lang)}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onViewDetails(venue)}
              className="px-3 py-2 rounded-xl text-xs font-semibold bg-neutral-100 dark:bg-white/10 text-neutral-700 dark:text-neutral-200 hover:bg-neutral-200 dark:hover:bg-white/15 transition-colors"
            >
              {isFa ? 'جزئیات مرکز' : 'Details'}
            </button>

            <button
              onClick={() => onBookVenue(venue)}
              className="px-3.5 py-2 rounded-xl text-xs font-semibold bg-neutral-950 text-white hover:bg-neutral-800 dark:bg-white dark:text-neutral-950 dark:hover:bg-neutral-100 transition-colors inline-flex items-center gap-1 shadow-sm"
            >
              <span>{isFa ? 'رزرو یونیت' : 'Reserve'}</span>
              <ChevronIcon className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
