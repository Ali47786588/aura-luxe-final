import React from 'react';
import { X, Printer, ShieldCheck, CheckCircle2, Download, Building2, QrCode } from 'lucide-react';
import { Language, EscrowTransaction } from '../types';
import { formatPrice, formatPersianNumber, t } from '../data/translations';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
  transaction: EscrowTransaction;
}

export const InvoiceModal: React.FC<Props> = ({
  isOpen,
  onClose,
  lang,
  transaction,
}) => {
  const isFa = lang === 'fa';
  const strings = t(lang);

  if (!isOpen) return null;

  const handlePrint = () => {
    window.print();
  };

  const vatToman = Math.round(transaction.platformFeeToman * 0.09);
  const netPayable = transaction.clinicPayoutToman;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-xl transition-opacity"
        onClick={onClose}
      />

      {/* Invoice Container */}
      <div className="relative w-full max-w-2xl rounded-3xl bg-neutral-900 border border-neutral-700/80 p-5 sm:p-8 shadow-2xl text-neutral-100 z-10 my-6 overflow-hidden print:p-0 print:border-none print:bg-white print:text-black">
        {/* Close Button (Hidden on Print) */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 rtl:left-auto rtl:right-5 p-2 rounded-full bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors print:hidden"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Invoice Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-neutral-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl font-bold tracking-tight text-white font-serif">AURA LUXE</span>
              <span className="text-[11px] text-amber-300 font-mono border border-amber-400/30 px-2 py-0.5 rounded-md">
                B2B ESCROW CLEARING
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-1">
              {isFa
                ? 'صورت‌حساب رسمی الکترونیکی خدمات کلینیکال و تسویه حساب امانی'
                : 'Official B2B Clinical Service & Escrow Settlement Tax Invoice'}
            </p>
          </div>

          <div className="text-left rtl:text-right sm:rtl:text-left text-xs font-mono text-neutral-400 space-y-0.5">
            <div>
              <span className="text-neutral-500">{isFa ? 'شماره فاکتور: ' : 'Invoice #: '}</span>
              <span className="text-white font-bold">{transaction.contractCode}</span>
            </div>
            <div>
              <span className="text-neutral-500">{isFa ? 'تاریخ صدور: ' : 'Issue Date: '}</span>
              <span>{transaction.date}</span>
            </div>
            <div>
              <span className="text-neutral-500">{isFa ? 'کد رهگیری شاپرک: ' : 'Shaparak RRN: '}</span>
              <span className="text-amber-300 font-bold">{transaction.paymentRefId || '908213847291'}</span>
            </div>
          </div>
        </div>

        {/* Parties Grid: Platform vs Beneficiary Clinic */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 my-5 p-4 rounded-2xl bg-neutral-950/70 border border-neutral-800/80 text-xs">
          <div>
            <span className="text-[10px] uppercase font-mono text-amber-400/90 tracking-wider">
              {isFa ? 'طرف اول: مجری پلتفرم و امین وجوه' : 'Party 1: Platform & Escrow Agent'}
            </span>
            <h5 className="font-bold text-white text-sm mt-1">اورا لوکس (شرکت نوآوران پرواز سلامت)</h5>
            <p className="text-neutral-400 text-[11px] mt-0.5">شناسه ملی: ۱۰۱۰۳۹۴۸۲۹۱ · کد اقتصادی: ۴۱۱۵-۸۹۲۱-۳۴</p>
            <p className="text-neutral-400 text-[11px]">تهران، سعادت‌آباد، سرو غربی، برج پزشکان اورا</p>
          </div>

          <div className="border-t sm:border-t-0 sm:border-r rtl:sm:border-r-0 rtl:sm:border-l border-neutral-800 pt-3 sm:pt-0 sm:pr-4 rtl:sm:pr-0 rtl:sm:pl-4">
            <span className="text-[10px] uppercase font-mono text-amber-400/90 tracking-wider">
              {isFa ? 'طرف دوم: کلینیک معتمد / پزشک' : 'Party 2: Beneficiary Clinic / Doctor'}
            </span>
            <h5 className="font-bold text-white text-sm mt-1">{transaction.venueName}</h5>
            <p className="text-neutral-400 text-[11px] mt-0.5">
              {isFa ? 'پزشک مسئول: ' : 'Attending: '}{transaction.practitionerName} ({isFa ? 'نظام پزشکی: ' : 'License: '}{transaction.licenseId})
            </p>
            <p className="text-neutral-400 text-[11px] font-mono">
              {isFa ? 'شماره شبا مقصد: ' : 'Sheba IBAN: '}IR820120...4192
            </p>
          </div>
        </div>

        {/* Itemized Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-right rtl:text-right ltr:text-left">
            <thead>
              <tr className="border-b border-neutral-800 text-neutral-400 text-[11px] font-medium pb-2">
                <th className="py-2">{isFa ? 'شرح خدمت / یونیت' : 'Description'}</th>
                <th className="py-2 text-center">{isFa ? 'مدت (ساعت)' : 'Hours'}</th>
                <th className="py-2 text-left rtl:text-left">{isFa ? 'مبلغ ناخالص (تومان)' : 'Gross (Toman)'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-850">
              <tr>
                <td className="py-3">
                  <div className="font-semibold text-white">{transaction.slotName}</div>
                  <div className="text-[11px] text-neutral-400">
                    {isFa ? 'اجاره عملیاتی یونیت استریل و کادر دستیاری تخصصی' : 'Sterile operatory reservation with dedicated assistant'}
                  </div>
                </td>
                <td className="py-3 text-center font-mono text-neutral-300">
                  {formatPersianNumber(transaction.hours, lang)}
                </td>
                <td className="py-3 text-left rtl:text-left font-mono font-bold text-white">
                  {formatPrice(transaction.grossAmountToman, lang)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Double-Entry Ledger Summary */}
        <div className="mt-4 pt-4 border-t border-neutral-800 space-y-2 text-xs">
          <div className="flex justify-between text-neutral-400">
            <span>{isFa ? 'کل مبلغ پرداخت‌شده بیمار (تضمین امانی):' : 'Gross Patient Payment (Held):'}</span>
            <span className="font-mono text-white">{formatPrice(transaction.grossAmountToman, lang)}</span>
          </div>

          <div className="flex justify-between text-neutral-400">
            <span>{isFa ? 'کارمزد زیرساخت پلتفرم (۸٪):' : 'Platform Escrow Fee (8%):'}</span>
            <span className="font-mono text-red-400">-{formatPrice(transaction.platformFeeToman, lang)}</span>
          </div>

          <div className="flex justify-between text-neutral-400">
            <span>{isFa ? 'مالیات بر ارزش افزوده کارمزد (۹٪):' : 'VAT on Platform Fee (9%):'}</span>
            <span className="font-mono text-neutral-300">{formatPrice(vatToman, lang)}</span>
          </div>

          <div className="flex justify-between text-base font-bold text-amber-300 pt-3 border-t border-neutral-800">
            <span>{isFa ? 'خالص واریزی به شبای کلینیک:' : 'Net Disbursement to Sheba:'}</span>
            <span className="font-mono text-lg">{formatPrice(netPayable, lang)}</span>
          </div>
        </div>

        {/* Security Seals & Legal Clearance */}
        <div className="mt-6 pt-4 border-t border-neutral-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-400">
          <div className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl bg-amber-400/10 text-amber-300 flex items-center justify-center border border-amber-400/20">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="font-semibold text-white">
                {isFa ? 'تاییدیه قطعی سامانه تسویه شاپرک / ساتنا' : 'Shaparak & SATNA Verified Clearance'}
              </p>
              <p className="text-[10px] text-neutral-500 font-mono">
                {isFa ? 'مبتنی بر قانون تجارت الکترونیکی و مهلت تضمین بالینی ۲ ساعته' : 'Guaranteed by 120-min clinical assurance escrow'}
              </p>
            </div>
          </div>

          {/* Print & Action Buttons (Hidden on Print) */}
          <div className="flex items-center gap-2 print:hidden w-full sm:w-auto">
            <button
              onClick={handlePrint}
              className="flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold bg-neutral-800 hover:bg-neutral-700 text-white border border-neutral-700 transition-colors flex items-center justify-center gap-2"
            >
              <Printer className="w-4 h-4 text-amber-300" />
              <span>{isFa ? 'چاپ فاکتور رسمی' : 'Print Invoice'}</span>
            </button>
            <button
              onClick={onClose}
              className="flex-1 sm:flex-none px-4 py-2 rounded-xl text-xs font-bold bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 hover:opacity-95 transition-opacity"
            >
              {isFa ? 'بستن' : 'Done'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
