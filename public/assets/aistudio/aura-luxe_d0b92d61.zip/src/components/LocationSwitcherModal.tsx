import React, { useState } from 'react';
import { MapPin, X, Check, Building2, Clock, Sparkles } from 'lucide-react';
import { District, Language } from '../types';
import { DISTRICTS } from '../data/mockData';
import { t, formatPrice, formatPersianNumber } from '../data/translations';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  selectedDistrict: District;
  onSelectDistrict: (district: District) => void;
  lang: Language;
}

export const LocationSwitcherModal: React.FC<Props> = ({
  isOpen,
  onClose,
  selectedDistrict,
  onSelectDistrict,
  lang,
}) => {
  const [activeTab, setActiveTab] = useState<'tehran' | 'karaj'>(selectedDistrict.cityId);
  const strings = t(lang);

  if (!isOpen) return null;

  const filteredDistricts = DISTRICTS.filter((d) => d.cityId === activeTab);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/60 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      {/* Modal Surface */}
      <div className="relative w-full max-w-2xl rounded-3xl apple-glass border border-white/10 p-6 sm:p-8 shadow-2xl text-neutral-100 z-10 overflow-hidden">
        {/* Header */}
        <div className="flex items-start justify-between gap-4 pb-6 border-b border-white/10">
          <div>
            <div className="flex items-center gap-2 text-xs text-neutral-400 mb-1">
              <MapPin className="w-3.5 h-3.5 text-neutral-300" />
              <span>{strings.brandBadge}</span>
              <span aria-hidden="true">·</span>
              <span>{strings.locationSelector}</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-semibold tracking-tight text-white">
              {strings.locationModalTitle}
            </h3>
            <p className="text-sm text-neutral-400 mt-1 max-w-lg">
              {strings.locationModalSubtitle}
            </p>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* City Segmented Control */}
        <div className="mt-6 flex p-1 rounded-2xl bg-white/5 border border-white/10">
          <button
            onClick={() => setActiveTab('tehran')}
            className={`flex-1 py-2.5 px-4 rounded-xl text-sm font-medium transition-all duration-200 ${
              activeTab === 'tehran'
                ? 'bg-neutral-800 text-white shadow-lg border border-white/15'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            {strings.tehranTab}
          </button>
          <button
            onClick={() => setActiveTab('karaj')}
            className={`flex-1 py-2.5 px-4 rounded-xl text-sm font-medium transition-all duration-200 ${
              activeTab === 'karaj'
                ? 'bg-neutral-800 text-white shadow-lg border border-white/15'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            {strings.karajTab}
          </button>
        </div>

        {/* Districts Grid */}
        <div className="mt-6 space-y-2.5 max-h-[50vh] overflow-y-auto pr-1">
          {filteredDistricts.map((district) => {
            const isSelected = selectedDistrict.id === district.id;

            return (
              <div
                key={district.id}
                onClick={() => {
                  onSelectDistrict(district);
                  onClose();
                }}
                className={`group flex items-center justify-between p-4 rounded-2xl border transition-all duration-200 cursor-pointer ${
                  isSelected
                    ? 'bg-neutral-800/90 border-white/30 shadow-md ring-1 ring-white/20'
                    : 'bg-white/5 border-white/5 hover:bg-white/10 hover:border-white/15'
                }`}
              >
                <div className="flex items-center gap-4">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
                      isSelected
                        ? 'bg-white text-neutral-950 shadow'
                        : 'bg-white/10 text-white group-hover:bg-white/20'
                    }`}
                  >
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="text-base font-medium text-white">
                        {lang === 'fa' ? district.nameFa : district.nameEn}
                      </h4>
                      {isSelected && (
                        <span className="text-[11px] font-medium text-neutral-300 bg-white/10 px-2 py-0.5 rounded-full">
                          {strings.selected}
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-neutral-400 mt-1">
                      <span>{district.popularRoad}</span>
                      <span aria-hidden="true">·</span>
                      <span>
                        {formatPersianNumber(district.activeClinicsCount, lang)} {strings.activeClinics}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-4 text-right">
                  <div className="hidden sm:block">
                    <div className="text-xs text-neutral-400">{strings.avgRate}</div>
                    <div className="text-sm font-semibold text-neutral-200 tabular-nums">
                      {formatPrice(district.averageHourlyToman, lang)}
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-emerald-400 font-medium tabular-nums">
                      {formatPersianNumber(district.availableSlotsNow, lang)} {strings.availableNow}
                    </span>
                    <div
                      className={`w-6 h-6 rounded-full flex items-center justify-center transition-all ${
                        isSelected
                          ? 'bg-white text-neutral-950'
                          : 'border border-white/20 group-hover:border-white/50 text-transparent'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer info note */}
        <div className="mt-6 pt-4 border-t border-white/10 flex items-center justify-between text-xs text-neutral-400">
          <div className="flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-neutral-300" />
            <span>
              {lang === 'fa'
                ? 'پوشش کامل مناطق برتر سعادت‌آباد، فرشته، فردیس و گوهردشت'
                : 'Covering premier clinical hubs across Saadat Abad, Fereshteh, Fardis & Gohardasht'}
            </span>
          </div>
          <button
            onClick={onClose}
            className="text-neutral-300 hover:text-white transition-colors"
          >
            {strings.closeModal}
          </button>
        </div>
      </div>
    </div>
  );
};
