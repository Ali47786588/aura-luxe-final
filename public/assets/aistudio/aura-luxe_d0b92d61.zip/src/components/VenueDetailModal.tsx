import React from 'react';
import { X, ShieldCheck, MapPin, CheckCircle, Award, Stethoscope, Sparkles } from 'lucide-react';
import { Venue, Language } from '../types';
import { t, formatPrice, formatPersianNumber } from '../data/translations';

interface Props {
  venue: Venue | null;
  onClose: () => void;
  lang: Language;
  onBookVenue: (venue: Venue) => void;
}

export const VenueDetailModal: React.FC<Props> = ({
  venue,
  onClose,
  lang,
  onBookVenue,
}) => {
  if (!venue) return null;

  const strings = t(lang);
  const isFa = lang === 'fa';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 overflow-y-auto">
      <div
        className="fixed inset-0 bg-black/70 backdrop-blur-md transition-opacity"
        onClick={onClose}
      />

      <div className="relative w-full max-w-3xl rounded-3xl apple-glass border border-white/15 p-6 sm:p-8 shadow-2xl text-neutral-100 z-10 my-8 overflow-hidden">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-6 left-6 rtl:left-auto rtl:right-6 p-2 rounded-full bg-black/40 hover:bg-black/60 text-white transition-colors z-20 border border-white/10"
          aria-label="Close"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Hero Image */}
        <div className="relative -mx-6 -mt-6 sm:-mx-8 sm:-mt-8 aspect-[16/9] overflow-hidden bg-neutral-900 border-b border-white/10">
          <img
            src={venue.image}
            alt={isFa ? venue.nameFa : venue.nameEn}
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/40 to-transparent" />

          <div className="absolute bottom-5 inset-x-6 sm:inset-x-8">
            <div className="flex items-center gap-2 text-xs text-neutral-300 mb-1.5">
              <MapPin className="w-3.5 h-3.5 text-neutral-300" />
              <span>{isFa ? venue.districtNameFa : venue.districtNameEn}</span>
              <span aria-hidden="true">·</span>
              <span>{isFa ? venue.addressFa : venue.addressEn}</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
              {isFa ? venue.nameFa : venue.nameEn}
            </h2>
          </div>
        </div>

        {/* Content Body */}
        <div className="mt-6 space-y-6">
          <p className="text-sm sm:text-base text-neutral-300 leading-relaxed">
            {isFa ? venue.descriptionFa : venue.descriptionEn}
          </p>

          {/* Medical Director & Accreditation Banner */}
          <div className="p-4 rounded-2xl bg-white/5 border border-white/10 flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center text-white">
                <Stethoscope className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs text-neutral-400">{strings.directorTitle}</div>
                <div className="text-sm font-semibold text-white">
                  {isFa ? venue.medicalDirectorFa : venue.medicalDirectorEn}
                </div>
              </div>
            </div>

            <div className="text-xs text-neutral-400 font-mono">
              <span className="text-neutral-500">{isFa ? 'شماره نظام / مجوز:' : 'License ID:'}</span>{' '}
              <span className="text-white font-semibold">{venue.medicalLicenseNumber}</span>
            </div>
          </div>

          {/* Grid of Equipment & Certifications */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
            <div>
              <h4 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-neutral-300" />
                <span>{strings.equipmentTitle}</span>
              </h4>
              <ul className="space-y-2 text-xs text-neutral-200">
                {venue.equipmentList.map((item, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <h4 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Award className="w-3.5 h-3.5 text-neutral-300" />
                <span>{strings.certificationsTitle}</span>
              </h4>
              <ul className="space-y-2 text-xs text-neutral-200">
                {venue.certifications.map((item, idx) => (
                  <li key={idx} className="flex items-center gap-2">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Amenities */}
          <div className="pt-2">
            <h4 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2.5">
              {strings.amenitiesTitle}
            </h4>
            <div className="flex flex-wrap gap-2 text-xs text-neutral-300">
              {venue.amenities.map((amenity, idx) => (
                <span
                  key={idx}
                  className="px-3 py-1.5 rounded-xl bg-white/5 border border-white/10 text-neutral-200"
                >
                  {amenity}
                </span>
              ))}
            </div>
          </div>

          {/* Bottom booking bar */}
          <div className="mt-8 pt-6 border-t border-white/10 flex items-center justify-between gap-4">
            <div>
              <div className="text-xs text-neutral-400">{strings.hourlyRate}</div>
              <div className="text-xl font-bold text-white tabular-nums">
                {formatPrice(venue.baseHourlyToman, lang)}
              </div>
            </div>

            <button
              onClick={() => {
                onClose();
                onBookVenue(venue);
              }}
              className="px-6 py-3 rounded-2xl text-sm font-semibold bg-white text-neutral-950 hover:bg-neutral-100 transition-colors shadow-lg"
            >
              {strings.bookThisSlot}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
