import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { CategoryFilter } from './components/CategoryFilter';
import { VenueCard } from './components/VenueCard';
import { VenueDetailModal } from './components/VenueDetailModal';
import { RealtimeSlotPanel } from './components/RealtimeSlotPanel';
import { BeforeAfterSlider } from './components/BeforeAfterSlider';
import { BookingModal } from './components/BookingModal';
import { LocationSwitcherModal } from './components/LocationSwitcherModal';
import { AdminLoginModal } from './components/AdminLoginModal';
import { ClinicAdminPortal } from './components/ClinicAdminPortal';
import { SuperAdminPanel } from './components/SuperAdminPanel';
import { OnboardingModal } from './components/OnboardingModal';
import { SupportTicketingModal } from './components/SupportTicketingModal';
import { InstagramStoryGallery } from './components/InstagramStoryGallery';
import { ToastNotificationContainer } from './components/ToastNotification';
import {
  District,
  CategoryId,
  Language,
  ThemeMode,
  Venue,
  RealtimeSlot,
  SlotStatus,
  BeforeAfterCase,
  UserRole,
  OnboardingApplication,
  StorySlide,
  BookingRequest,
  EscrowTransaction,
  ToastAlert,
} from './types';
import { DISTRICTS, VENUES, INITIAL_SLOTS, INITIAL_APPLICATIONS, INITIAL_ESCROW_TRANSACTIONS, INITIAL_BOOKING_REQUESTS } from './data/mockData';
import { t, formatPrice } from './data/translations';
import { MapPin, Shield, Building, Lock, ArrowLeft, ArrowRight, Sparkles, UserPlus, Headphones, ShieldAlert } from 'lucide-react';

type ModalType =
  | 'none'
  | 'location'
  | 'booking'
  | 'venue_details'
  | 'admin_login'
  | 'onboarding'
  | 'support';

export default function App() {
  const [lang, setLang] = useState<Language>('fa');
  const [theme, setTheme] = useState<ThemeMode>('dark');
  const [userRole, setUserRole] = useState<UserRole>('public');
  const [sessionToken, setSessionToken] = useState<string | null>(null);
  const [managedVenue, setManagedVenue] = useState<Venue>(VENUES[0]);
  const [selectedDistrict, setSelectedDistrict] = useState<District>(DISTRICTS[0]); // Saadat Abad
  const [selectedCategory, setSelectedCategory] = useState<CategoryId>('all');
  const [slots, setSlots] = useState<RealtimeSlot[]>(INITIAL_SLOTS);
  const [applications, setApplications] = useState<OnboardingApplication[]>(INITIAL_APPLICATIONS);
  const [transactions, setTransactions] = useState<EscrowTransaction[]>(INITIAL_ESCROW_TRANSACTIONS);
  const [bookingRequests, setBookingRequests] = useState<BookingRequest[]>(INITIAL_BOOKING_REQUESTS);
  const [activeSection, setActiveSection] = useState<string>('hero');

  // Unified Modal Manager (guarantees NO overlapping stacked modals)
  const [activeModal, setActiveModal] = useState<ModalType>('none');
  const [submittedBookingRequest, setSubmittedBookingRequest] = useState<BookingRequest | null>(null);
  const [selectedVenueForDetails, setSelectedVenueForDetails] = useState<Venue | null>(null);
  const [preselectedBookingVenue, setPreselectedBookingVenue] = useState<Venue | null>(null);
  const [preselectedBookingSlot, setPreselectedBookingSlot] = useState<RealtimeSlot | null>(null);

  // Global Toast Notifications
  const [toasts, setToasts] = useState<ToastAlert[]>([]);

  const strings = t(lang);
  const isFa = lang === 'fa';
  const ArrowIcon = isFa ? ArrowLeft : ArrowRight;

  const addToast = (type: 'success' | 'warning' | 'error' | 'info', title: string, message: string) => {
    const newToast: ToastAlert = {
      id: 'toast-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      type,
      title,
      message,
      timestamp: Date.now(),
    };
    setToasts((prev) => [newToast, ...prev.slice(0, 3)]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== newToast.id));
    }, 4500);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Synchronize document dir and theme on root element
  useEffect(() => {
    document.documentElement.setAttribute('dir', isFa ? 'rtl' : 'ltr');
    document.documentElement.setAttribute('lang', lang);
  }, [lang, isFa]);

  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
      document.documentElement.classList.remove('light');
    } else {
      document.documentElement.classList.remove('dark');
      document.documentElement.classList.add('light');
    }
  }, [theme]);

  // Sync initial live slots from backend
  useEffect(() => {
    fetch('/api/slots')
      .then((res) => res.json())
      .then((data) => {
        if (data.slots && data.slots.length > 0) {
          // Merge with initial slots
          setSlots((prev) =>
            prev.map((s) => {
              const remote = data.slots.find((rs: any) => rs.id === s.id);
              if (remote) {
                return {
                  ...s,
                  status: remote.status,
                  lastSanitizedMinutesAgo: remote.lastSanitizedMinutesAgo ?? s.lastSanitizedMinutesAgo,
                };
              }
              return s;
            })
          );
        }
      })
      .catch(() => {});

    // Sync booking requests from backend
    fetch('/api/booking-requests')
      .then((res) => res.json())
      .then((data) => {
        if (data.requests && data.requests.length > 0) {
          setBookingRequests(data.requests);
        }
      })
      .catch(() => {});
  }, []);

  // Handle slot status toggle with backend persistence
  const handleToggleSlotStatus = async (slotId: string, nextStatus: SlotStatus) => {
    setSlots((prev) =>
      prev.map((slot) => {
        if (slot.id !== slotId) return slot;
        return {
          ...slot,
          status: nextStatus,
          lastSanitizedMinutesAgo: nextStatus === 'sanitizing' ? 0 : slot.lastSanitizedMinutesAgo,
        };
      })
    );

    try {
      await fetch(`/api/slots/${slotId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus }),
      });
    } catch (e) {
      console.log('Slot state saved');
    }

    addToast(
      'info',
      isFa ? 'بروزرسانی وضعیت یونیت' : 'Operatory Status Altered',
      isFa ? `وضعیت به ${nextStatus} تغییر یافت و در شبکه همگام‌سازی شد.` : `Slot marked as ${nextStatus}.`
    );
  };

  // Filter venues by selected district and category
  const filteredVenues = VENUES.filter((venue) => {
    if (selectedCategory !== 'all' && venue.category !== selectedCategory) {
      return false;
    }
    if (venue.cityId !== selectedDistrict.cityId) {
      return false;
    }
    return true;
  });

  const handleOpenBookingWithVenue = (venue: Venue) => {
    setPreselectedBookingVenue(venue);
    setPreselectedBookingSlot(null);
    setSubmittedBookingRequest(null);
    setActiveModal('booking');
  };

  const handleOpenBookingWithSlot = (slot: RealtimeSlot) => {
    const venue = VENUES.find((v) => v.id === slot.venueId) ?? null;
    setPreselectedBookingVenue(venue);
    setPreselectedBookingSlot(slot);
    setSubmittedBookingRequest(null);
    setActiveModal('booking');
  };

  const handleBookFromBeforeAfter = (caseItem: BeforeAfterCase) => {
    const targetCat = caseItem.category === 'dental' ? 'dental' : 'aesthetics';
    const venue = VENUES.find((v) => v.category === targetCat) ?? VENUES[0];
    setPreselectedBookingVenue(venue);
    setSubmittedBookingRequest(null);
    setActiveModal('booking');
  };

  const handleBookFromStorySlide = (slide: StorySlide) => {
    const venue = VENUES[0];
    setPreselectedBookingVenue(venue);
    setSubmittedBookingRequest(null);
    setActiveModal('booking');
  };

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    if (sectionId === 'aesthetics') setSelectedCategory('aesthetics');
    else if (sectionId === 'salons') setSelectedCategory('salons');
    else if (sectionId === 'dental') setSelectedCategory('dental');

    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleAdminLoginSuccess = (venue: Venue, token: string) => {
    setManagedVenue(venue);
    setSessionToken(token);
    setUserRole('clinic_admin');
    setActiveModal('none');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSuperAdminLoginSuccess = (token: string) => {
    setSessionToken(token);
    setUserRole('super_admin');
    setActiveModal('none');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLogout = async () => {
    if (sessionToken) {
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: { Authorization: `Bearer ${sessionToken}` },
        });
      } catch (e) {}
    }
    setSessionToken(null);
    setUserRole('public');
    addToast('info', isFa ? 'خروج امن' : 'Logged Out', isFa ? 'نشست امنیتی با موفقیت بسته شد.' : 'Session closed.');
  };

  const handleUpdateAppStatus = async (appId: string, status: 'approved' | 'rejected') => {
    setApplications((prev) =>
      prev.map((app) => (app.id === appId ? { ...app, status } : app))
    );
    try {
      await fetch(`/api/onboarding/${appId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
    } catch (e) {}

    addToast(
      status === 'approved' ? 'success' : 'warning',
      isFa ? 'بروزرسانی وضعیت همکار' : 'Application Status Updated',
      isFa ? `درخواست همکار به وضعیت ${status === 'approved' ? 'تایید شده' : 'رد شده'} تغییر یافت.` : `Application ${status}.`
    );
  };

  const handleNewOnboardingApplication = async (newApp: OnboardingApplication) => {
    setApplications((prev) => [newApp, ...prev]);
    try {
      await fetch('/api/onboarding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          brandNameFa: newApp.businessName,
          brandNameEn: newApp.businessName,
          type: newApp.applicantType,
          licenseId: newApp.medicalCouncilOrGuildId || 'PENDING',
          contactPerson: newApp.applicantName || newApp.businessName,
          phone: newApp.phoneNumber,
          sheba: newApp.shebaNumber || 'IR000000000000000000000000',
          chairCount: newApp.chairsOrBedsCount,
          primaryEquipment: [newApp.shortDescription || newApp.primaryEquipment || 'تجهیزات اعلامی'],
          districtNameFa: newApp.cityAndDistrict || newApp.district,
        }),
      });
    } catch (e) {}

    addToast(
      'success',
      isFa ? 'درخواست شما ثبت شد و در حال بررسی است' : 'Application Received and Under Review',
      isFa ? 'اطلاعات مجموعه جهت بررسی اولیه به سامانه ارسال گردید.' : 'Your application details have been queued for audit.'
    );
  };

  // Submit new booking request (Replaces online payment)
  const handleNewBookingRequest = async (requestData: Omit<BookingRequest, 'id' | 'trackingCode' | 'createdAt' | 'status'>) => {
    const trackingCode = `REQ-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const newReq: BookingRequest = {
      id: `req-${Date.now()}`,
      trackingCode,
      status: 'pending_confirmation',
      createdAt: isFa 
        ? 'امروز ' + new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' })
        : 'Today ' + new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      ...requestData,
    };

    setBookingRequests((prev) => [newReq, ...prev]);
    setSubmittedBookingRequest(newReq);

    try {
      await fetch('/api/booking-requests', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(requestData),
      });
    } catch (e) {}

    addToast(
      'info',
      isFa ? 'درخواست نوبت ثبت شد' : 'Request Submitted',
      isFa
        ? `درخواست با کد ${trackingCode} ثبت شد و در انتظار تأیید کلینیک قرار گرفت.`
        : `Request ${trackingCode} is pending clinic confirmation.`
    );
  };

  // Clinic Manager approve or reject booking request
  const handleUpdateBookingRequestStatus = async (requestId: string, nextStatus: 'confirmed' | 'rejected') => {
    setBookingRequests((prev) =>
      prev.map((r) => (r.id === requestId ? { ...r, status: nextStatus } : r))
    );

    // If approved and has slot, lock slot as reserved
    const targetReq = bookingRequests.find((r) => r.id === requestId);
    if (nextStatus === 'confirmed' && targetReq?.slotId) {
      handleToggleSlotStatus(targetReq.slotId, 'reserved');
    }

    try {
      await fetch(`/api/booking-requests/${requestId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus, reviewedBy: 'مدیر کلینیک' }),
      });
    } catch (e) {}

    addToast(
      nextStatus === 'confirmed' ? 'success' : 'warning',
      nextStatus === 'confirmed'
        ? (isFa ? 'نوبت تأیید شد' : 'Booking Confirmed')
        : (isFa ? 'درخواست نوبت رد شد' : 'Booking Rejected'),
      nextStatus === 'confirmed'
        ? (isFa ? `درخواست ${targetReq?.fullName || ''} تأیید و صندلی رزرو شد.` : `Booking confirmed.`)
        : (isFa ? `درخواست ${targetReq?.fullName || ''} رد گردید.` : `Booking rejected.`)
    );
  };

  return (
    <div className="min-h-screen bg-[#0A0A0C] text-neutral-100 transition-colors duration-300">
      {/* Real-time Notification Toast System */}
      <ToastNotificationContainer toasts={toasts} onDismiss={dismissToast} />

      {/* Top Bar Navigation with Role Switcher, Onboarding, and Support */}
      <Navbar
        lang={lang}
        onToggleLang={() => setLang((prev) => (prev === 'fa' ? 'en' : 'fa'))}
        theme={theme}
        onToggleTheme={() => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'))}
        selectedDistrict={selectedDistrict}
        onOpenLocationModal={() => setActiveModal('location')}
        activeSection={activeSection}
        onNavigateSection={scrollToSection}
        onOpenBookingModal={() => {
          setPreselectedBookingVenue(null);
          setPreselectedBookingSlot(null);
          setSubmittedBookingRequest(null);
          setActiveModal('booking');
        }}
        userRole={userRole}
        onOpenAdminLoginModal={() => setActiveModal('admin_login')}
        onSwitchToPublic={handleLogout}
        onOpenOnboardingModal={() => setActiveModal('onboarding')}
        onOpenSupportModal={() => setActiveModal('support')}
      />

      {/* VIEW 1: SUPER ADMIN MASTER GOVERNANCE PANEL (Restricted & Authenticated) */}
      {userRole === 'super_admin' ? (
        <SuperAdminPanel
          lang={lang}
          onExitSuperAdmin={handleLogout}
          applications={applications}
          onUpdateAppStatus={handleUpdateAppStatus}
          onTriggerToast={addToast}
        />
      ) : userRole === 'clinic_admin' ? (
        /* VIEW 2: DEDICATED CLINIC ADMIN PORTAL (Request Verification, Seat Management & Revenue) */
        <ClinicAdminPortal
          lang={lang}
          managedVenue={managedVenue}
          onSwitchVenue={setManagedVenue}
          onExitPortal={handleLogout}
          slots={slots}
          onToggleSlotStatus={handleToggleSlotStatus}
          onBookSlot={handleOpenBookingWithSlot}
          onTriggerToast={addToast}
          bookingRequests={bookingRequests}
          onUpdateBookingRequestStatus={handleUpdateBookingRequestStatus}
        />
      ) : (
        /* VIEW 3: PUBLIC MARKETPLACE (Clean Doctor & Client Experience, Completely Hidden Financials) */
        <main className="space-y-16 sm:space-y-24">
          {/* Hero Section */}
          <div id="hero">
            <HeroSection
              lang={lang}
              selectedDistrict={selectedDistrict}
              onOpenLocationModal={() => setActiveModal('location')}
              onExploreClinics={() => scrollToSection('venues_catalog')}
              onOpenSlotPanel={() => scrollToSection('realtime_slots')}
              onOpenBookingModal={() => {
                setPreselectedBookingVenue(null);
                setSubmittedBookingRequest(null);
                setActiveModal('booking');
              }}
            />
          </div>

          {/* Interactive Instagram Stories & Highlights Showcase */}
          <section id="stories_gallery" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <InstagramStoryGallery
              lang={lang}
              onBookProcedure={handleBookFromStorySlide}
              onSendStoryReply={(doctorName, msg) => {
                addToast(
                  'success',
                  isFa ? 'پیام به پزشک ارسال شد' : 'Inquiry Sent',
                  isFa ? `پیام شما برای ${doctorName} ثبت شد.` : `Delivered to ${doctorName}.`
                );
              }}
            />
          </section>

          {/* Venues Catalog: Advanced Aesthetics, Salons, Dental */}
          <section id="venues_catalog" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 pb-2">
              <div>
                <div className="flex items-center gap-2 text-xs font-mono uppercase tracking-wider text-amber-300 mb-1">
                  <span>{isFa ? 'مراکز تایید شده و معتبر' : 'VERIFIED LUXURY SUITES'}</span>
                  <span aria-hidden="true" className="text-neutral-500">·</span>
                  <span className="text-neutral-300 font-sans">
                    {isFa ? selectedDistrict.nameFa : selectedDistrict.nameEn} (
                    {selectedDistrict.cityId === 'tehran' ? (isFa ? 'تهران' : 'Tehran') : (isFa ? 'کرج' : 'Karaj')})
                  </span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white">
                  {selectedCategory === 'all' && (isFa ? 'برترین کلینیک‌ها، سالن‌ها و استودیوهای لبخند' : 'Premier Aesthetic & Dental Centers')}
                  {selectedCategory === 'aesthetics' && strings.catAestheticsTitle}
                  {selectedCategory === 'salons' && strings.catSalonsTitle}
                  {selectedCategory === 'dental' && strings.catDentalTitle}
                </h2>
                <p className="text-sm text-neutral-400 mt-1 max-w-xl">
                  {selectedCategory === 'all' && (isFa ? 'سوئیت‌های جراحی، لیزر کندلا، یونیت‌های کاستلینی و استیشن‌های تخصصی با ضمانت امانی' : 'Curated medical spaces with Candela lasers, Italian dental chairs, and verified autoclaves.')}
                  {selectedCategory === 'aesthetics' && strings.catAestheticsSub}
                  {selectedCategory === 'salons' && strings.catSalonsSub}
                  {selectedCategory === 'dental' && strings.catDentalSub}
                </p>
              </div>

              {/* Category Segmented Control */}
              <CategoryFilter
                selectedCategory={selectedCategory}
                onSelectCategory={setSelectedCategory}
                lang={lang}
              />
            </div>

            {/* Cards Grid */}
            {filteredVenues.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
                {filteredVenues.map((venue) => (
                  <VenueCard
                    key={venue.id}
                    venue={venue}
                    lang={lang}
                    onViewDetails={(v) => {
                      setSelectedVenueForDetails(v);
                      setActiveModal('venue_details');
                    }}
                    onBookVenue={handleOpenBookingWithVenue}
                  />
                ))}
              </div>
            ) : (
              <div className="text-center py-16 rounded-3xl border border-dashed border-neutral-800 p-8 text-neutral-400">
                <Building className="w-10 h-10 mx-auto text-neutral-500 mb-3" />
                <p className="text-base font-medium">{strings.emptyNotice}</p>
                <button
                  onClick={() => setSelectedCategory('all')}
                  className="mt-3 text-xs font-semibold underline text-amber-300"
                >
                  {isFa ? 'نمایش همه دسته‌بندی‌ها' : 'Reset Category Filter'}
                </button>
              </div>
            )}
          </section>

          {/* Live Slot Availability Overview (Public View for Booking Doctors) */}
          <section id="realtime_slots" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <RealtimeSlotPanel
              slots={slots}
              onToggleSlotStatus={handleToggleSlotStatus}
              onBookSlot={handleOpenBookingWithSlot}
              lang={lang}
            />
          </section>

          {/* Cinematic Before/After Interactive Slider Showcase */}
          <section id="before_after" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <BeforeAfterSlider
              lang={lang}
              onBookSimilarSuite={handleBookFromBeforeAfter}
            />
          </section>
        </main>
      )}

      {/* Partner Registration Callout at the bottom of the page */}
      {userRole === 'public' && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-20">
          <div className="relative rounded-3xl p-6 sm:p-10 border border-amber-400/25 bg-gradient-to-b from-neutral-900/90 to-neutral-950/95 backdrop-blur-xl shadow-2xl overflow-hidden flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="absolute top-0 right-0 w-80 h-80 bg-amber-400/5 rounded-full blur-3xl pointer-events-none" />
            <div className="space-y-2 text-center md:text-right rtl:md:text-right ltr:md:text-left z-10">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400/10 border border-amber-400/20 text-amber-300 text-xs font-semibold">
                <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                <span>{isFa ? 'عضویت کلینیک‌ها و پزشکان' : 'Partner Network'}</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
                {isFa ? 'صاحب کلینیک، سالن زیبایی یا پزشک مستقل هستید؟' : 'Clinic Director, Salon Owner or Specialist?'}
              </h3>
              <p className="text-xs sm:text-sm text-neutral-400 max-w-xl leading-relaxed">
                {isFa
                  ? 'با ثبت تخت‌ها و صندلی‌های خالی خود در سامانه، به بزرگ‌ترین جامعه پزشکان و مراجعین متصل شده و ظرفیت‌های آزاد را تکمیل کنید.'
                  : 'Monetize vacant operatory suites and welcome esteemed visiting practitioners.'}
              </p>
            </div>
            <button
              onClick={() => setActiveModal('onboarding')}
              className="z-10 px-6 py-3.5 rounded-2xl text-xs sm:text-sm font-bold bg-gradient-to-r from-amber-200 via-amber-300 to-amber-500 text-neutral-950 hover:opacity-95 transition-all shadow-lg flex items-center gap-2 whitespace-nowrap cursor-pointer shrink-0"
            >
              <UserPlus className="w-4 h-4 text-neutral-900" />
              <span>{isFa ? 'ثبت‌نام مرکز یا پزشک' : 'Register Center or Doctor'}</span>
            </button>
          </div>
        </section>
      )}

      {/* Apple-style Minimalist Footer */}
      <footer className="mt-20 border-t border-neutral-800 py-12 text-xs text-neutral-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-amber-200 via-amber-400 to-amber-600 text-neutral-950 flex items-center justify-center font-bold text-xs">
              A
            </div>
            <div>
              <span className="font-semibold text-white">
                {isFa ? 'آورا لوکس' : 'AURA LUXE'}
              </span>
              <span className="mx-2 text-neutral-500">·</span>
              <span>
                {isFa
                  ? 'سامانه یکپارچه اشتراک زیرساخت بالینی و پزشکی تهران و کرج'
                  : 'B2B Clinical Infrastructure & Operatory Marketplace'}
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 sm:gap-5 text-neutral-400">
            <span>{isFa ? 'سعادت‌آباد · الهیه · گوهردشت · فردیس' : 'Saadat Abad · Elahieh · Gohardasht · Fardis'}</span>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setActiveModal('onboarding')}
              className="hover:text-amber-300 transition-colors flex items-center gap-1.5 text-amber-300/90 font-medium"
            >
              <UserPlus className="w-3.5 h-3.5 text-amber-300" />
              <span>{isFa ? 'ثبت‌نام مرکز یا پزشک' : 'Register Center/Doctor'}</span>
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setActiveModal('support')}
              className="hover:text-amber-300 transition-colors"
            >
              {isFa ? 'مرکز تیکتینگ و پشتیبانی' : 'Support Hub'}
            </button>
            <span aria-hidden="true">·</span>
            <button
              onClick={() => setActiveModal('admin_login')}
              className="hover:text-amber-300 transition-colors flex items-center gap-1"
            >
              <Lock className="w-3.5 h-3.5 text-amber-300" />
              <span>{isFa ? 'ورود مدیران' : 'Manager Sign-in'}</span>
            </button>
            <span aria-hidden="true">·</span>
            <span>© 2026 AURA LUXE</span>
          </div>
        </div>
      </footer>

      {/* Modals - Mutually Exclusive */}
      <LocationSwitcherModal
        isOpen={activeModal === 'location'}
        onClose={() => setActiveModal('none')}
        selectedDistrict={selectedDistrict}
        onSelectDistrict={(d) => {
          setSelectedDistrict(d);
          setActiveModal('none');
        }}
        lang={lang}
      />

      <VenueDetailModal
        venue={selectedVenueForDetails}
        onClose={() => {
          setSelectedVenueForDetails(null);
          setActiveModal('none');
        }}
        lang={lang}
        onBookVenue={(v) => {
          handleOpenBookingWithVenue(v);
        }}
      />

      <BookingModal
        isOpen={activeModal === 'booking'}
        onClose={() => {
          setActiveModal('none');
          setPreselectedBookingVenue(null);
          setPreselectedBookingSlot(null);
          setSubmittedBookingRequest(null);
        }}
        lang={lang}
        preselectedVenue={preselectedBookingVenue}
        preselectedSlot={preselectedBookingSlot}
        onSubmitBookingRequest={handleNewBookingRequest}
        submittedRequest={submittedBookingRequest}
      />

      <AdminLoginModal
        isOpen={activeModal === 'admin_login'}
        onClose={() => setActiveModal('none')}
        lang={lang}
        onSuccessLogin={handleAdminLoginSuccess}
        onSuccessSuperAdmin={handleSuperAdminLoginSuccess}
        onTriggerToast={addToast}
      />

      <OnboardingModal
        isOpen={activeModal === 'onboarding'}
        onClose={() => setActiveModal('none')}
        lang={lang}
        onSubmitApplication={handleNewOnboardingApplication}
      />

      <SupportTicketingModal
        isOpen={activeModal === 'support'}
        onClose={() => setActiveModal('none')}
        lang={lang}
      />
    </div>
  );
}
