export type Language = 'fa' | 'en';
export type ThemeMode = 'dark' | 'light';
export type UserRole = 'public' | 'clinic_admin' | 'super_admin';

export type CityId = 'tehran' | 'karaj';

export interface District {
  id: string;
  cityId: CityId;
  nameEn: string;
  nameFa: string;
  popularRoad: string;
  activeClinicsCount: number;
  availableSlotsNow: number;
  averageHourlyToman: number;
}

export type CategoryId = 'all' | 'aesthetics' | 'salons' | 'dental';

export type SlotStatus = 'available' | 'reserved' | 'in_procedure' | 'sanitizing';
export type SlotType = 'chair' | 'bed' | 'laser_suite' | 'operatory';

export interface RealtimeSlot {
  id: string;
  venueId: string;
  venueNameEn: string;
  venueNameFa: string;
  roomNameEn: string;
  roomNameFa: string;
  type: SlotType;
  status: SlotStatus;
  currentPractitioner?: string;
  patientProcedure?: string;
  pricePerHourToman: number;
  shiftMorningPriceToman: number;
  shiftEveningPriceToman: number;
  equipment: string[];
  assistantIncluded: boolean;
  consumablesIncluded: boolean;
  autoclaveReady: boolean;
  lastSanitizedMinutesAgo: number;
}

export interface Venue {
  id: string;
  nameEn: string;
  nameFa: string;
  category: CategoryId;
  cityId: CityId;
  districtId: string;
  districtNameEn: string;
  districtNameFa: string;
  addressEn: string;
  addressFa: string;
  rating: number;
  reviewCount: number;
  image: string;
  gallery: string[];
  taglineEn: string;
  taglineFa: string;
  descriptionEn: string;
  descriptionFa: string;
  totalChairs: number;
  activeSlots: number;
  baseHourlyToman: number;
  certifications: string[];
  equipmentList: string[];
  amenities: string[];
  escrowVerified: boolean;
  medicalDirectorEn: string;
  medicalDirectorFa: string;
  medicalLicenseNumber: string;
}

export interface EscrowTransaction {
  id: string;
  contractCode: string;
  practitionerName: string;
  licenseId: string;
  venueName: string;
  slotName: string;
  category: CategoryId;
  date: string;
  hours: number;
  grossAmountToman: number;
  commissionRatePercent: number;
  platformFeeToman: number;
  clinicPayoutToman: number;
  status: 'held_in_escrow' | 'patient_arrived' | 'procedure_done' | 'released';
  milestoneStep: 1 | 2 | 3 | 4; // 1: Escrow Held, 2: Patient Arrived, 3: Procedure Done, 4: Released
  createdAt: string;
  estimatedReleaseTime: string;
  paymentRefId?: string;
  trackingNumber?: string;
  cardMasked?: string;
  patientCheckInTimestamp?: string;
  patientNationalIdVerified?: boolean;
  procedureSignOffNotes?: string;
  doctorSignOffTimestamp?: string;
  guaranteeMinutesRemaining?: number; // 2-hour guarantee window (120 mins)
  procedureTitle?: string;
  bookingStatus?: 'confirmed';
  bookingStatusFa?: string;
  bookingStatusEn?: string;
  zarinpalTrackingCode?: string;
}

export type BookingRequestStatus = 'pending_confirmation' | 'confirmed' | 'rejected';

export interface BookingRequest {
  id: string;
  trackingCode: string;
  fullName: string;
  phoneNumber: string;
  desiredService: string;
  suggestedDate: string;
  suggestedTime: string;
  venueId: string;
  venueNameFa: string;
  venueNameEn: string;
  slotId?: string;
  slotNameFa?: string;
  slotNameEn?: string;
  notes?: string;
  status: BookingRequestStatus;
  createdAt: string;
  updatedAt?: string;
  reviewedBy?: string;
}

export interface PaymentSession {
  amountToman: number;
  merchantName: string;
  orderId: string;
  slotName: string;
  venueName: string;
  date: string;
  hours: number;
  practitionerName: string;
  medicalId: string;
  procedureDescription: string;
  venueId: string;
  slotId?: string;
}

export interface BeforeAfterCase {
  id: string;
  titleEn: string;
  titleFa: string;
  category: 'dental' | 'skin';
  clinicNameEn: string;
  clinicNameFa: string;
  doctorNameEn: string;
  doctorNameFa: string;
  locationEn: string;
  locationFa: string;
  treatmentEn: string;
  treatmentFa: string;
  afterImage: string;
  beforeFilter: string;
  metricsEn: { label: string; value: string }[];
  metricsFa: { label: string; value: string }[];
  notesEn: string;
  notesFa: string;
}

// 1. Onboarding & Registration Form Type
export type PartnerActivityType = 'skin_clinic' | 'dental' | 'salon' | 'independent_doctor';

export interface OnboardingApplication {
  id: string;
  applicantType: 'clinic' | 'salon' | 'doctor';
  activityType?: PartnerActivityType;
  activityTypeFa?: string;
  businessName: string; // نام مرکز یا پزشک
  businessOrDoctorName?: string;
  applicantName?: string;
  medicalCouncilOrGuildId?: string;
  phoneNumber: string; // شماره تماس
  email?: string;
  cityId?: CityId;
  district?: string;
  cityAndDistrict?: string; // شهر و منطقه
  address?: string;
  chairsOrBedsCount: number; // تعداد تخت یا صندلی خالی
  availableChairsCount?: number;
  primaryEquipment?: string;
  shortDescription?: string; // توضیحات کوتاه
  shebaNumber?: string;
  status: 'pending' | 'approved' | 'rejected';
  submittedAt: string;
}

// 2. Interactive Story Highlight Types
export interface StorySlide {
  id: string;
  titleFa: string;
  titleEn: string;
  doctorNameFa: string;
  doctorNameEn: string;
  clinicNameFa: string;
  clinicNameEn: string;
  image: string;
  beforeFilter: string;
  treatmentDetailsFa: string;
  treatmentDetailsEn: string;
  clinicalTagFa: string;
  clinicalTagEn: string;
  durationSeconds: number;
}

export interface StoryHighlight {
  id: string;
  category: 'skin' | 'dental' | 'salon' | 'fillers' | 'surgery';
  titleFa: string;
  titleEn: string;
  coverImage: string;
  hasUnseenStories: boolean;
  slides: StorySlide[];
}

// 3. Support & Ticketing Types
export interface TicketMessage {
  id: string;
  senderName: string;
  isStaff: boolean;
  content: string;
  timestamp: string;
}

export interface SupportTicket {
  id: string;
  ticketNumber: string;
  senderName: string;
  senderRole: 'clinic_owner' | 'doctor';
  venueName: string;
  subject: string;
  category: 'escrow' | 'slot' | 'technical' | 'verification';
  priority: 'urgent' | 'high' | 'normal';
  status: 'open' | 'answered' | 'resolved';
  createdAt: string;
  messages: TicketMessage[];
}

export interface DigitalSignatureData {
  signatureSvg: string;
  signedBy: string;
  role: 'doctor' | 'patient';
  timestamp: string;
  checksum: string;
}

export interface SecurityAuditRecord {
  id: string;
  timestamp: string;
  type: 'auth' | 'escrow' | 'security' | 'slot' | 'onboarding';
  severity: 'info' | 'warning' | 'critical';
  titleFa: string;
  titleEn: string;
  details: string;
  ip: string;
}

export interface ToastAlert {
  id: string;
  type: 'success' | 'warning' | 'info' | 'error';
  title: string;
  message: string;
  timestamp: number;
}

